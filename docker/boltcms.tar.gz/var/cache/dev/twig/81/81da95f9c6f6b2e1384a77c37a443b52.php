<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* helpers/page_404.html.twig */
class __TwigTemplate_0a92c87b269a7987112b61fc414e1cf4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "helpers/page_404.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "helpers/page_404.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 5, $this->source); })()), "statusCode", [], "any", false, false, false, 5), "html", null, true);
        yield " :: ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 5, $this->source); })()), "message", [], "any", false, false, false, 5), "html", null, true);
        yield "</title>
    <link rel=\"stylesheet\" href=\"https://unpkg.com/purecss@1.0.1/build/pure-min.css\" integrity=\"sha384-oAOxQR6DkCoMliIh8yFnu25d7Eq/PHS21PClpwjOTeU2jRSq11vu66rf90/cZr47\" crossorigin=\"anonymous\">
    <style>
        .warning {
            color: #721314;
            background-color: #f8d3d4;
            border-color: #f5c2c3;
            position: relative;
            padding: .75rem 1.25rem;
            margin-bottom: 1rem;
            border-radius: .15rem;
            max-width: 50rem;
            line-height: 1.5rem;
        }

        pre {
            border-left: 3px solid #666;
            padding: 0.5rem 1rem;
        }
    </style>
</head>

<body id=\"home\">

    <div style=\"padding: 2rem 4rem;\">

        <h1>";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 31, $this->source); })()), "statusCode", [], "any", false, false, false, 31), "html", null, true);
        yield " :: ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 31, $this->source); })()), "message", [], "any", false, false, false, 31), "html", null, true);
        yield " </h1>

        ";
        // line 35
        yield "        ";
        if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 35, $this->source); })()), "request", [], "any", false, false, false, 35), "requestUri", [], "any", false, false, false, 35) == "/")) {
            // line 36
            yield "        <div class=\"warning\">
            <p>
            <strong>Note:</strong> There seems to be no content in the database, which is why you're seeing this page instead of something that resembles a Homepage.
                To remedy this, please log in to the <a href=\"";
            // line 39
            yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_dashboard");
            yield "\">Bolt backend</a>, and
                <a class=\"btn btn-primary\" href=\"";
            // line 40
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_content_new", ["contentType" => Twig\Extension\CoreExtension::first($this->env->getCharset(), Twig\Extension\CoreExtension::keys(CoreExtension::getAttribute($this->env, $this->source,             // line 41
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 41, $this->source); })()), "get", ["contenttypes"], "method", false, false, false, 41))), "field-title" => "Homepage"]), "html", null, true);
            // line 42
            yield "\">
                   create the Homepage</a>.
            </p>

            <p>
            On the other hand, if you want to get started quickly, you can still add the fixtures (dummy content) now. To do so, run the following on the command line:
            </p>

            <pre><code>php bin/console doctrine:fixtures:load --append</code></pre>
        </div>
        ";
        }
        // line 53
        yield "
        <p>In <code>";
        // line 54
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::slice($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 54, $this->source); })()), "file", [], "any", false, false, false, 54), "/"),  -2), "/"), "html", null, true);
        yield "</code></p>

        ";
        // line 57
        yield "        ";
        yield $this->extensions['Symfony\Bridge\Twig\Extension\DumpExtension']->dump($this->env, $context, (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new RuntimeError('Variable "exception" does not exist.', 57, $this->source); })()));
        yield "

    </div>
</body>
</html>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "helpers/page_404.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  128 => 57,  123 => 54,  120 => 53,  107 => 42,  105 => 41,  104 => 40,  100 => 39,  95 => 36,  92 => 35,  85 => 31,  54 => 5,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>{{ exception.statusCode }} :: {{ exception.message }}</title>
    <link rel=\"stylesheet\" href=\"https://unpkg.com/purecss@1.0.1/build/pure-min.css\" integrity=\"sha384-oAOxQR6DkCoMliIh8yFnu25d7Eq/PHS21PClpwjOTeU2jRSq11vu66rf90/cZr47\" crossorigin=\"anonymous\">
    <style>
        .warning {
            color: #721314;
            background-color: #f8d3d4;
            border-color: #f5c2c3;
            position: relative;
            padding: .75rem 1.25rem;
            margin-bottom: 1rem;
            border-radius: .15rem;
            max-width: 50rem;
            line-height: 1.5rem;
        }

        pre {
            border-left: 3px solid #666;
            padding: 0.5rem 1rem;
        }
    </style>
</head>

<body id=\"home\">

    <div style=\"padding: 2rem 4rem;\">

        <h1>{{ exception.statusCode }} :: {{ exception.message }} </h1>

        {# Sepecial case: If the user is setting up a new site, we show this extra helpful notice
           to let them know that they're seeing this page because there's no content yet. #}
        {% if app.request.requestUri == '/' %}
        <div class=\"warning\">
            <p>
            <strong>Note:</strong> There seems to be no content in the database, which is why you're seeing this page instead of something that resembles a Homepage.
                To remedy this, please log in to the <a href=\"{{ path('bolt_dashboard') }}\">Bolt backend</a>, and
                <a class=\"btn btn-primary\" href=\"{{ path('bolt_content_new', {
                    'contentType': config.get('contenttypes')|keys|first,
                    'field-title': 'Homepage'}) }}\">
                   create the Homepage</a>.
            </p>

            <p>
            On the other hand, if you want to get started quickly, you can still add the fixtures (dummy content) now. To do so, run the following on the command line:
            </p>

            <pre><code>php bin/console doctrine:fixtures:load --append</code></pre>
        </div>
        {% endif %}

        <p>In <code>{{ exception.file|split('/')|slice(-2)|join('/') }}</code></p>

        {# will only be shown if debug is on. #}
        {{ dump(exception) }}

    </div>
</body>
</html>
", "helpers/page_404.html.twig", "/var/www/boltcms/vendor/bolt/core/templates/helpers/page_404.html.twig");
    }
}
