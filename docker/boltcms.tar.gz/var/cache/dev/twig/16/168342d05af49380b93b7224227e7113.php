<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/_content_listing.html.twig */
class __TwigTemplate_8dce75b515128fea2649daa5e92f5101 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/_content_listing.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/_content_listing.html.twig"));

        // line 1
        if ($this->extensions['Bolt\Twig\ArrayExtension']->length($this->env, (isset($context["records"]) || array_key_exists("records", $context) ? $context["records"] : (function () { throw new RuntimeError('Variable "records" does not exist.', 1, $this->source); })()))) {
            // line 2
            yield "
    <!-- listing records -->
    <listing-records
      type=\"";
            // line 5
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 5, $this->source); })()), "html", null, true);
            yield "\"
      :data=\"";
            // line 6
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Cache\ContentToArrayCacher']->jsonRecords((isset($context["records"]) || array_key_exists("records", $context) ? $context["records"] : (function () { throw new RuntimeError('Variable "records" does not exist.', 6, $this->source); })()), true, 0, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 6, $this->source); })()), "request", [], "any", false, false, false, 6), "getLocale", [], "method", false, false, false, 6)), "html", null, true);
            yield "\"
    >
    </listing-records>
    <!-- end listing records -->

    <!-- listing filter -->
    <listing-filter :labels=\"";
            // line 12
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(["button_compact" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_filter.button_compact"), "button_expanded" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_filter.button_expanded"), "select_all" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.select_all")]), "html", null, true);
            // line 16
            yield "\"></listing-filter>
    <!-- end listing filter -->

    <listing-table
    :labels=\"";
            // line 20
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(["actions" => ["view_on_site" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.view_on_site"), "status_to_publish" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.status_to_publish"), "status_to_held" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.status_to_held"), "status_to_draft" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.status_to_draft"), "status_to_publish" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.status_to_publish"), "duplicate" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.duplicate"), "delete" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.delete"), "slug" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.slug"), "created_on" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.created_on"), "published_on" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.published_on"), "last_modified_on" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.last_modified_on"), "button_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing_table.actions.button_edit")]]), "html", null, true);
            // line 36
            yield "\"
    ></listing-table>

    ";
            // line 39
            yield $this->extensions['Bolt\Twig\ContentExtension']->pager($this->env, (isset($context["records"]) || array_key_exists("records", $context) ? $context["records"] : (function () { throw new RuntimeError('Variable "records" does not exist.', 39, $this->source); })()), "@bolt/helpers/_pager_bootstrap.html.twig", "justify-content-center");
            yield "

";
        } else {
            // line 42
            yield "
    <div class=\"alert alert-warning\" role=\"alert\">
        ";
            // line 44
            yield $this->extensions['Bolt\Twig\LocaleExtension']->translate("listing_table.no_results");
            yield "
    </div>


";
        }
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/_content_listing.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  93 => 44,  89 => 42,  83 => 39,  78 => 36,  76 => 20,  70 => 16,  68 => 12,  59 => 6,  55 => 5,  50 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% if records|length %}

    <!-- listing records -->
    <listing-records
      type=\"{{ type }}\"
      :data=\"{{ records|json_records(true, 0, app.request.getLocale()) }}\"
    >
    </listing-records>
    <!-- end listing records -->

    <!-- listing filter -->
    <listing-filter :labels=\"{{ {
        'button_compact': 'listing_filter.button_compact'|trans,
        'button_expanded': 'listing_filter.button_expanded'|trans,
        'select_all': 'listing_table.actions.select_all'|trans,
    }|json_encode }}\"></listing-filter>
    <!-- end listing filter -->

    <listing-table
    :labels=\"{{
    { 'actions':
        {
            'view_on_site': 'listing_table.actions.view_on_site'|trans,
            'status_to_publish': 'listing_table.actions.status_to_publish'|trans,
            'status_to_held': 'listing_table.actions.status_to_held'|trans,
            'status_to_draft': 'listing_table.actions.status_to_draft'|trans,
            'status_to_publish': 'listing_table.actions.status_to_publish'|trans,
            'duplicate': 'listing_table.actions.duplicate'|trans,
            'delete': 'listing_table.actions.delete'|trans,
            'slug': 'listing_table.actions.slug'|trans,
            'created_on': 'listing_table.actions.created_on'|trans,
            'published_on': 'listing_table.actions.published_on'|trans,
            'last_modified_on': 'listing_table.actions.last_modified_on'|trans,
            'button_edit': 'listing_table.actions.button_edit'|trans,
        }
    }|json_encode }}\"
    ></listing-table>

    {{ pager(records, template = '@bolt/helpers/_pager_bootstrap.html.twig', class=\"justify-content-center\") }}

{% else %}

    <div class=\"alert alert-warning\" role=\"alert\">
        {{ __('listing_table.no_results') }}
    </div>


{% endif %}
", "@bolt/_partials/_content_listing.html.twig", "/var/www/boltcms/vendor/bolt/core/templates/_partials/_content_listing.html.twig");
    }
}
