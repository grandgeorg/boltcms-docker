<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* _macro/_macro.html.twig */
class __TwigTemplate_9c0b4ebca6baeab9f76ad129e0240b47 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_macro/_macro.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "_macro/_macro.html.twig"));

        // line 7
        yield "
";
        // line 23
        yield "
";
        // line 41
        yield "
";
        // line 94
        yield "

";
        // line 101
        yield "
";
        // line 112
        yield "
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 2
    public function macro_icon($__icon__ = "question-circle", ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "icon" => $__icon__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "icon"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "icon"));

            $___internal_parse_1_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 3
                yield "    ";
                $context["icon"] = Twig\Extension\CoreExtension::replace((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 3, $this->source); })()), ["fa-" => ""]);
                // line 4
                yield "
    <i class=\"fas fa-fw fa-";
                // line 5
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 5, $this->source); })()), "html", null, true);
                yield "\"></i>
";
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 2
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_1_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 8
    public function macro_button($__label__ = "Button", $__icon__ = "question-circle", $__class__ = "tertiary", $__attr__ = [], ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "label" => $__label__,
            "icon" => $__icon__,
            "class" => $__class__,
            "attr" => $__attr__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "button"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "button"));

            $___internal_parse_2_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 9
                yield "
    ";
                // line 10
                $context["label"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 10, $this->source); })()));
                // line 11
                yield "    ";
                $context["icon"] = Twig\Extension\CoreExtension::replace((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 11, $this->source); })()), ["fa-" => ""]);
                // line 12
                yield "    ";
                $context["class"] = Twig\Extension\CoreExtension::replace((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 12, $this->source); })()), ["btn-" => ""]);
                // line 13
                yield "    ";
                $context["mb"] = ((CoreExtension::inFilter("mb-", (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 13, $this->source); })()))) ? ("") : ("mb-3"));
                // line 14
                yield "    ";
                $context["attr"] = (isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 14, $this->source); })());
                // line 15
                yield "
    <button class=\"btn btn-";
                // line 16
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 16, $this->source); })()), "html", null, true);
                yield " ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["mb"]) || array_key_exists("mb", $context) ? $context["mb"] : (function () { throw new RuntimeError('Variable "mb" does not exist.', 16, $this->source); })()), "html", null, true);
                yield "\"
        ";
                // line 17
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 17, $this->source); })()));
                foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                    yield " ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                    yield "=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                    yield "\"";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                yield ">
        <i class=\"fas fa-fw fa-";
                // line 18
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 18, $this->source); })()), "html", null, true);
                yield " mr-2\"></i>";
                // line 19
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 19, $this->source); })()), "html", null, true);
                // line 20
                yield "</button>

";
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 8
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_2_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 24
    public function macro_buttonlink($__label__ = "Button", $__link__ = "", $__icon__ = "question-circle", $__class__ = "tertiary", $__attr__ = [], $__translate__ = true, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "label" => $__label__,
            "link" => $__link__,
            "icon" => $__icon__,
            "class" => $__class__,
            "attr" => $__attr__,
            "translate" => $__translate__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "buttonlink"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "buttonlink"));

            $___internal_parse_3_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 25
                yield "
    ";
                // line 26
                if ((isset($context["translate"]) || array_key_exists("translate", $context) ? $context["translate"] : (function () { throw new RuntimeError('Variable "translate" does not exist.', 26, $this->source); })())) {
                    // line 27
                    yield "        ";
                    $context["label"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 27, $this->source); })()));
                    // line 28
                    yield "    ";
                }
                // line 29
                yield "    ";
                $context["icon"] = Twig\Extension\CoreExtension::replace((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 29, $this->source); })()), ["fa-" => ""]);
                // line 30
                yield "    ";
                $context["class"] = Twig\Extension\CoreExtension::replace((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 30, $this->source); })()), ["btn-" => ""]);
                // line 31
                yield "    ";
                $context["mb"] = ((CoreExtension::inFilter("mb-", (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 31, $this->source); })()))) ? ("") : ("mb-3"));
                // line 32
                yield "    ";
                $context["attr"] = (isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 32, $this->source); })());
                // line 33
                yield "
    <a href=\"";
                // line 34
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["link"]) || array_key_exists("link", $context) ? $context["link"] : (function () { throw new RuntimeError('Variable "link" does not exist.', 34, $this->source); })()), "html", null, true);
                yield "\" class=\"btn btn-";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 34, $this->source); })()), " "), " btn-"), "html", null, true);
                yield " text-nowrap ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["mb"]) || array_key_exists("mb", $context) ? $context["mb"] : (function () { throw new RuntimeError('Variable "mb" does not exist.', 34, $this->source); })()), "html", null, true);
                yield "\"
        ";
                // line 35
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["attr"]) || array_key_exists("attr", $context) ? $context["attr"] : (function () { throw new RuntimeError('Variable "attr" does not exist.', 35, $this->source); })()));
                foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                    yield " ";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                    yield "=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                    yield "\"";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                yield ">
        <i class=\"fas fa-fw fa-";
                // line 36
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 36, $this->source); })()), "html", null, true);
                yield " mr-1\"></i>";
                // line 37
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 37, $this->source); })()), "html", null, true);
                // line 38
                yield "</a>

";
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 24
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_3_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 42
    public function macro_generate_collection_fields($__collectionField__ = null, $__fields__ = null, $__record__ = null, $__compileTemplates__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "collectionField" => $__collectionField__,
            "fields" => $__fields__,
            "record" => $__record__,
            "compileTemplates" => $__compileTemplates__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generate_collection_fields"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generate_collection_fields"));

            $___internal_parse_4_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 43
                yield "    ";
                $context["fieldsHtml"] = [];
                // line 44
                yield "    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new RuntimeError('Variable "fields" does not exist.', 44, $this->source); })()));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["item_field"]) {
                    // line 45
                    yield "        ";
                    $context["collectionItemName"] = (((("collections[" . CoreExtension::getAttribute($this->env, $this->source, (isset($context["collectionField"]) || array_key_exists("collectionField", $context) ? $context["collectionField"] : (function () { throw new RuntimeError('Variable "collectionField" does not exist.', 45, $this->source); })()), "name", [], "any", false, false, false, 45)) . "][") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "definition", [], "any", false, false, false, 45), "name", [], "any", false, false, false, 45)) . "]");
                    // line 46
                    yield "        ";
                    // line 47
                    yield "        ";
                    // line 48
                    yield "        ";
                    $context["hash"] = ((((isset($context["compileTemplates"]) || array_key_exists("compileTemplates", $context) ? $context["compileTemplates"] : (function () { throw new RuntimeError('Variable "compileTemplates" does not exist.', 48, $this->source); })()) == true)) ? ("{{ hash }}") : (CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 48)));
                    // line 49
                    yield "
        ";
                    // line 50
                    $context["collectionItemName"] = ((((isset($context["collectionItemName"]) || array_key_exists("collectionItemName", $context) ? $context["collectionItemName"] : (function () { throw new RuntimeError('Variable "collectionItemName" does not exist.', 50, $this->source); })()) . "[") . (isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 50, $this->source); })())) . "]");
                    // line 51
                    yield "        ";
                    $context["id"] = ((((("field-" . ((CoreExtension::getAttribute($this->env, $this->source, ($context["collectionField"] ?? null), "name", [], "any", true, true, false, 51)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["collectionField"] ?? null), "name", [], "any", false, false, false, 51), "unnamed")) : ("unnamed"))) . "-") . ((CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", true, true, false, 51)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", false, false, false, 51), "unnamed")) : ("unnamed"))) . "-") . (isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 51, $this->source); })()));
                    // line 52
                    yield "        ";
                    $context["new_field"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                        // line 53
                        yield "            ";
                        $context["context"] = ["field" =>                         // line 54
$context["item_field"], "id" =>                         // line 55
(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 55, $this->source); })()), "in_compound" => true, "is_first" => (CoreExtension::getAttribute($this->env, $this->source,                         // line 57
$context["loop"], "index0", [], "any", false, false, false, 57) == 0), "is_last" => (CoreExtension::getAttribute($this->env, $this->source,                         // line 58
$context["loop"], "index", [], "any", false, false, false, 58) == $this->extensions['Bolt\Twig\ArrayExtension']->length($this->env, (isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new RuntimeError('Variable "fields" does not exist.', 58, $this->source); })()))), "name" =>                         // line 59
(isset($context["collectionItemName"]) || array_key_exists("collectionItemName", $context) ? $context["collectionItemName"] : (function () { throw new RuntimeError('Variable "collectionItemName" does not exist.', 59, $this->source); })()), "compound_label" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,                         // line 60
(isset($context["collectionField"]) || array_key_exists("collectionField", $context) ? $context["collectionField"] : (function () { throw new RuntimeError('Variable "collectionField" does not exist.', 60, $this->source); })()), "definition", [], "any", false, false, false, 60), "label", [], "any", false, false, false, 60), "hash" =>                         // line 61
(isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 61, $this->source); })()), "record" =>                         // line 62
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 62, $this->source); })())];
                        // line 64
                        yield "
            ";
                        // line 65
                        if ((CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "type", [], "any", false, false, false, 65) != "set")) {
                            // line 66
                            yield "                ";
                            $context["context"] = Twig\Extension\CoreExtension::merge((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 66, $this->source); })()), ["include_id" => true]);
                            // line 67
                            yield "            ";
                        }
                        // line 68
                        yield "
            ";
                        // line 69
                        $context["includeLookup"] = [(("@bolt/_partials/fields/" . CoreExtension::getAttribute($this->env, $this->source,                         // line 70
$context["item_field"], "type", [], "any", false, false, false, 70)) . ".html.twig"), (((("@" . CoreExtension::getAttribute($this->env, $this->source,                         // line 71
$context["item_field"], "type", [], "any", false, false, false, 71)) . "/") . CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "type", [], "any", false, false, false, 71)) . ".html.twig"), "@bolt/_partials/fields/generic.html.twig"];
                        // line 74
                        yield "
            <div>
                ";
                        // line 76
                        yield from                         $this->loadTemplate((isset($context["includeLookup"]) || array_key_exists("includeLookup", $context) ? $context["includeLookup"] : (function () { throw new RuntimeError('Variable "includeLookup" does not exist.', 76, $this->source); })()), "_macro/_macro.html.twig", 76)->unwrap()->yield(CoreExtension::toArray((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 76, $this->source); })())));
                        // line 77
                        yield "                <input type=\"hidden\" name=\"collections[";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["collectionField"]) || array_key_exists("collectionField", $context) ? $context["collectionField"] : (function () { throw new RuntimeError('Variable "collectionField" does not exist.', 77, $this->source); })()), "name", [], "any", false, false, false, 77), "html", null, true);
                        yield "][order][]\" value=\"";
                        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 77, $this->source); })()), "html", null, true);
                        yield "\" />
            </div>
        ";
                        return; yield '';
                    })())) ? '' : new Markup($tmp, $this->env->getCharset());
                    // line 80
                    yield "
        ";
                    // line 82
                    yield "        ";
                    $context["buttons"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                        yield from                         $this->loadTemplate("@bolt/_partials/fields/_collection_buttons.html.twig", "_macro/_macro.html.twig", 82)->unwrap()->yield(CoreExtension::merge($context, ["in_compound" => true, "hash" => (isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 82, $this->source); })())]));
                        return; yield '';
                    })())) ? '' : new Markup($tmp, $this->env->getCharset());
                    // line 83
                    yield "
        ";
                    // line 85
                    yield "        ";
                    $context["icon"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "definition", [], "any", false, false, false, 85), "icon", [], "any", false, false, false, 85);
                    // line 86
                    yield "        ";
                    if (Twig\Extension\CoreExtension::testEmpty((isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 86, $this->source); })()))) {
                        $context["icon"] = "fa-plus";
                    }
                    // line 87
                    yield "
        ";
                    // line 89
                    yield "        ";
                    $context["label"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "definition", [], "any", false, true, false, 89), "label", [], "any", true, true, false, 89)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "definition", [], "any", false, true, false, 89), "label", [], "any", false, false, false, 89), $this->extensions['Bolt\Twig\TextExtension']->ucwords(((CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", true, true, false, 89)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", false, false, false, 89), "unnamed")) : ("unnamed"))))) : ($this->extensions['Bolt\Twig\TextExtension']->ucwords(((CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", true, true, false, 89)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["item_field"], "name", [], "any", false, false, false, 89), "unnamed")) : ("unnamed")))));
                    // line 90
                    yield "        ";
                    $context["fieldsHtml"] = Twig\Extension\CoreExtension::merge((isset($context["fieldsHtml"]) || array_key_exists("fieldsHtml", $context) ? $context["fieldsHtml"] : (function () { throw new RuntimeError('Variable "fieldsHtml" does not exist.', 90, $this->source); })()), [["content" => (isset($context["new_field"]) || array_key_exists("new_field", $context) ? $context["new_field"] : (function () { throw new RuntimeError('Variable "new_field" does not exist.', 90, $this->source); })()), "hash" => (isset($context["hash"]) || array_key_exists("hash", $context) ? $context["hash"] : (function () { throw new RuntimeError('Variable "hash" does not exist.', 90, $this->source); })()), "label" => (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 90, $this->source); })()), "buttons" => (isset($context["buttons"]) || array_key_exists("buttons", $context) ? $context["buttons"] : (function () { throw new RuntimeError('Variable "buttons" does not exist.', 90, $this->source); })()), "icon" => (isset($context["icon"]) || array_key_exists("icon", $context) ? $context["icon"] : (function () { throw new RuntimeError('Variable "icon" does not exist.', 90, $this->source); })())]]);
                    // line 91
                    yield "    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item_field'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 92
                yield "    ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["fieldsHtml"]) || array_key_exists("fieldsHtml", $context) ? $context["fieldsHtml"] : (function () { throw new RuntimeError('Variable "fieldsHtml" does not exist.', 92, $this->source); })())), "html", null, true);
                yield "
";
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 42
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_4_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 96
    public function macro_relative_datetime($__datetime__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "datetime" => $__datetime__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "relative_datetime"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "relative_datetime"));

            $___internal_parse_5_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 97
                yield "    <abbr class=\"datetime-relative\" title=\"";
                yield $this->extensions['Bolt\Twig\LocaleExtension']->localdate((isset($context["datetime"]) || array_key_exists("datetime", $context) ? $context["datetime"] : (function () { throw new RuntimeError('Variable "datetime" does not exist.', 97, $this->source); })()));
                yield "\">";
                // line 98
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Cache\SelectOptionsCacher']->getDate($this->env, (isset($context["datetime"]) || array_key_exists("datetime", $context) ? $context["datetime"] : (function () { throw new RuntimeError('Variable "datetime" does not exist.', 98, $this->source); })()), "c"), "html", null, true);
                // line 99
                yield "</abbr>
";
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 96
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_5_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 107
    public function macro_generatePrefix($__prefix__ = null, $__id__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "prefix" => $__prefix__,
            "id" => $__id__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generatePrefix"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generatePrefix"));

            $___internal_parse_6_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 108
                yield "    ";
                if (((isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 108, $this->source); })()) &&  !(((is_string($__internal_compile_0 = (isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 108, $this->source); })())) && is_string($__internal_compile_1 = "<p") && str_starts_with($__internal_compile_0, $__internal_compile_1)) || (is_string($__internal_compile_2 = (isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 108, $this->source); })())) && is_string($__internal_compile_3 = "<span") && str_starts_with($__internal_compile_2, $__internal_compile_3))) || (is_string($__internal_compile_4 = (isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 108, $this->source); })())) && is_string($__internal_compile_5 = "<div") && str_starts_with($__internal_compile_4, $__internal_compile_5))))) {
                    // line 109
                    yield "        <div id=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 109, $this->source); })()) . "_prefix"), "html", null, true);
                    yield "\" class=\"form--helper\">";
                    yield $this->extensions['Bolt\Twig\HtmlExtension']->markdown((isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 109, $this->source); })()));
                    yield "</div>
    ";
                }
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 107
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_6_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 118
    public function macro_generatePostfix($__postfix__ = null, $__id__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "postfix" => $__postfix__,
            "id" => $__id__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generatePostfix"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "generatePostfix"));

            $___internal_parse_7_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 119
                yield "    ";
                if (((isset($context["postfix"]) || array_key_exists("postfix", $context) ? $context["postfix"] : (function () { throw new RuntimeError('Variable "postfix" does not exist.', 119, $this->source); })()) &&  !(((is_string($__internal_compile_6 = (isset($context["postfix"]) || array_key_exists("postfix", $context) ? $context["postfix"] : (function () { throw new RuntimeError('Variable "postfix" does not exist.', 119, $this->source); })())) && is_string($__internal_compile_7 = "<p") && str_starts_with($__internal_compile_6, $__internal_compile_7)) || (is_string($__internal_compile_8 = (isset($context["postfix"]) || array_key_exists("postfix", $context) ? $context["postfix"] : (function () { throw new RuntimeError('Variable "postfix" does not exist.', 119, $this->source); })())) && is_string($__internal_compile_9 = "<span") && str_starts_with($__internal_compile_8, $__internal_compile_9))) || (is_string($__internal_compile_10 = (isset($context["postfix"]) || array_key_exists("postfix", $context) ? $context["postfix"] : (function () { throw new RuntimeError('Variable "postfix" does not exist.', 119, $this->source); })())) && is_string($__internal_compile_11 = "<div") && str_starts_with($__internal_compile_10, $__internal_compile_11))))) {
                    // line 120
                    yield "        <div id=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 120, $this->source); })()) . "_postfix"), "html", null, true);
                    yield "\" class=\"form--helper\">";
                    yield $this->extensions['Bolt\Twig\HtmlExtension']->markdown((isset($context["postfix"]) || array_key_exists("postfix", $context) ? $context["postfix"] : (function () { throw new RuntimeError('Variable "postfix" does not exist.', 120, $this->source); })()));
                    yield "</div>
    ";
                }
                return; yield '';
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 118
            yield Twig\Extension\CoreExtension::spaceless($___internal_parse_7_);
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "_macro/_macro.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  592 => 118,  582 => 120,  579 => 119,  559 => 118,  547 => 107,  537 => 109,  534 => 108,  514 => 107,  502 => 96,  497 => 99,  495 => 98,  491 => 97,  472 => 96,  460 => 42,  453 => 92,  439 => 91,  436 => 90,  433 => 89,  430 => 87,  425 => 86,  422 => 85,  419 => 83,  413 => 82,  410 => 80,  400 => 77,  398 => 76,  394 => 74,  392 => 71,  391 => 70,  390 => 69,  387 => 68,  384 => 67,  381 => 66,  379 => 65,  376 => 64,  374 => 62,  373 => 61,  372 => 60,  371 => 59,  370 => 58,  369 => 57,  368 => 55,  367 => 54,  365 => 53,  362 => 52,  359 => 51,  357 => 50,  354 => 49,  351 => 48,  349 => 47,  347 => 46,  344 => 45,  326 => 44,  323 => 43,  301 => 42,  289 => 24,  283 => 38,  281 => 37,  278 => 36,  263 => 35,  255 => 34,  252 => 33,  249 => 32,  246 => 31,  243 => 30,  240 => 29,  237 => 28,  234 => 27,  232 => 26,  229 => 25,  205 => 24,  193 => 8,  187 => 20,  185 => 19,  182 => 18,  167 => 17,  161 => 16,  158 => 15,  155 => 14,  152 => 13,  149 => 12,  146 => 11,  144 => 10,  141 => 9,  119 => 8,  107 => 2,  101 => 5,  98 => 4,  95 => 3,  76 => 2,  64 => 112,  61 => 101,  57 => 94,  54 => 41,  51 => 23,  48 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{# Button Macro with defaults #}
{% macro icon(icon = 'question-circle') %}{% apply spaceless %}
    {% set icon = icon|replace({'fa-': ''}) %}

    <i class=\"fas fa-fw fa-{{ icon }}\"></i>
{% endapply %}{% endmacro %}

{% macro button(label = 'Button', icon = 'question-circle', class = 'tertiary', attr = []) %}{% apply spaceless %}

    {% set label = label|trans %}
    {% set icon = icon|replace({'fa-': ''}) %}
    {% set class = class|replace({'btn-': ''}) %}
    {% set mb = 'mb-' in class ? '' : 'mb-3' %}
    {% set attr = attr %}

    <button class=\"btn btn-{{ class }} {{ mb }}\"
        {% for key,value in attr %} {{ key }}=\"{{value}}\"{% endfor %}>
        <i class=\"fas fa-fw fa-{{ icon }} mr-2\"></i>
        {{- label -}}
    </button>

{% endapply %}{% endmacro %}

{% macro buttonlink(label = 'Button', link = '', icon = 'question-circle', class = 'tertiary', attr = [], translate = true) %}{% apply spaceless %}

    {% if translate %}
        {% set label = label|trans %}
    {% endif %}
    {% set icon = icon|replace({'fa-': ''}) %}
    {% set class = class|replace({'btn-': ''}) %}
    {% set mb = 'mb-' in class ? '' : 'mb-3' %}
    {% set attr = attr %}

    <a href=\"{{ link }}\" class=\"btn btn-{{ class|split(' ')|join(' btn-') }} text-nowrap {{ mb }}\"
        {% for key,value in attr %} {{ key }}=\"{{value}}\"{% endfor %}>
        <i class=\"fas fa-fw fa-{{ icon }} mr-1\"></i>
        {{- label -}}
    </a>

{% endapply %}{% endmacro %}

{% macro generate_collection_fields(collectionField, fields, record, compileTemplates) %}{% apply spaceless %}
    {% set fieldsHtml = [] %}
    {% for item_field in fields %}
        {% set collectionItemName = 'collections[' ~ collectionField.name ~ '][' ~ item_field.definition.name ~ ']' %}
        {# we create a 'dummy' hash from the current loop index, which is used to instantiate copies of collection item templates. #}
        {# The order is also submitted in an order field, so that collection items may be stored in the given order in the database. #}
        {% set hash = compileTemplates == true ? \"{{ hash }}\" : loop.index %}

        {% set collectionItemName = collectionItemName ~ '[' ~ hash ~ ']' %}
        {% set id = 'field-' ~ collectionField.name|default('unnamed') ~ '-' ~ item_field.name|default('unnamed') ~ '-' ~ hash %}
        {% set new_field %}
            {% set context = {
                'field': item_field,
                'id': id,
                'in_compound': true,
                'is_first': loop.index0 == 0,
                'is_last': loop.index == fields|length,
                'name': collectionItemName,
                'compound_label': collectionField.definition.label,
                'hash': hash,
                'record': record
            } %}

            {% if item_field.type != 'set' %}
                {% set context = context|merge({'include_id': true}) %}
            {% endif %}

            {% set includeLookup = [
                '@bolt/_partials/fields/' ~ item_field.type ~ '.html.twig',
                '@' ~ item_field.type ~ '/' ~ item_field.type ~ '.html.twig',
                '@bolt/_partials/fields/generic.html.twig'
            ] %}

            <div>
                {% include includeLookup with context only %}
                <input type=\"hidden\" name=\"collections[{{ collectionField.name }}][order][]\" value=\"{{ hash }}\" />
            </div>
        {% endset %}

        {# Set the buttons #}
        {% set buttons %}{% include '@bolt/_partials/fields/_collection_buttons.html.twig' with { in_compound: true, 'hash': hash } %}{% endset %}

        {# Set the icon #}
        {% set icon = item_field.definition.icon %}
        {% if icon is empty%}{% set icon = 'fa-plus' %}{% endif %}

        {# set the label manually as set in _base.html.twig, to pass to Collection.vue for templates #}
        {% set label = item_field.definition.label|default(item_field.name|default('unnamed')|ucwords) %}
        {% set fieldsHtml = fieldsHtml|merge([{'content': new_field, 'hash': hash, 'label': label, 'buttons': buttons, 'icon': icon}]) %}
    {% endfor %}
    {{ fieldsHtml|json_encode }}
{% endapply %}{% endmacro %}


{% macro relative_datetime(datetime) %}{% apply spaceless %}
    <abbr class=\"datetime-relative\" title=\"{{ datetime|localdate }}\">
        {{- datetime|date('c') -}}
    </abbr>
{% endapply %}{% endmacro %}

{#
 Variables
    'prefix': Is the prefix string
    'id':     Is a string
#}
{% macro generatePrefix(prefix, id) %}{% apply spaceless %}
    {% if prefix and not (prefix starts with '<p' or prefix starts with '<span' or prefix starts with '<div') %}
        <div id=\"{{ id ~ '_prefix' }}\" class=\"form--helper\">{{ prefix|markdown }}</div>
    {% endif %}
{% endapply %}{% endmacro %}

{#
 Variables
    'postfix': Is the postfix string
    'id':      Is a string
#}
{% macro generatePostfix(postfix, id) %}{% apply spaceless %}
    {% if postfix and not (postfix starts with '<p' or postfix starts with '<span' or postfix starts with '<div') %}
        <div id=\"{{ id ~ '_postfix' }}\" class=\"form--helper\">{{ postfix|markdown }}</div>
    {% endif %}
{% endapply %}{% endmacro %}
", "_macro/_macro.html.twig", "/var/www/boltcms/vendor/bolt/core/templates/_macro/_macro.html.twig");
    }
}
