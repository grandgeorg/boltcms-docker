<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @configuration-notices-widget/configuration.html.twig */
class __TwigTemplate_7645ab27689aeb0021b79ab4292459bf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@configuration-notices-widget/configuration.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@configuration-notices-widget/configuration.html.twig"));

        // line 1
        yield "<!-- Generated at \"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Cache\SelectOptionsCacher']->getDate($this->env, "now", "Y-m-d H:i:s"), "html", null, true);
        yield "\" -->
<div class=\"card mb-4\">
    <div class=\"progress\" style=\"width: 100%; height: 10px; border-radius: 0;\">
        <div class=\"card-header progress-bar progress-bar-striped progress-bar-animated
            ";
        // line 5
        if ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 5, $this->source); })()), "severity", [], "any", false, false, false, 5) == 1)) {
            yield "bg-info";
        } elseif ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 5, $this->source); })()), "severity", [], "any", false, false, false, 5) == 2)) {
            yield "bg-warning";
        } else {
            yield "bg-danger";
        }
        yield "\" style=\"width: 100%;\">
        </div>
    </div>
    <div class=\"card-header\">
        <span  style=\"text-align: left;\"><i class=\"fas fa-lightbulb\" style=\"display: inline-block\"></i>  Bolt Configuration Notices</span>
    </div>
    <div class=\"card-body configuration-notices\">

        <p>Bolt has detected one or more configuration issues. You should resolve these, for optimum performance:</p>

        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, (isset($context["results"]) || array_key_exists("results", $context) ? $context["results"] : (function () { throw new RuntimeError('Variable "results" does not exist.', 15, $this->source); })()), "notices", [], "any", false, false, false, 15));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["result"]) {
            // line 16
            yield "            <p><span class=\"badge bg-";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["result"], "severity", [], "any", false, false, false, 16), "html", null, true);
            yield "\">";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\TextExtension']->ucwords(CoreExtension::getAttribute($this->env, $this->source, $context["result"], "severity", [], "any", false, false, false, 16)), "html", null, true);
            yield "</span> - ";
            yield CoreExtension::getAttribute($this->env, $this->source, $context["result"], "notice", [], "any", false, false, false, 16);
            yield "
            ";
            // line 17
            if (CoreExtension::getAttribute($this->env, $this->source, $context["result"], "info", [], "any", false, false, false, 17)) {
                yield "</p>
            <small style=\"padding-top: 0.5rem; display: block;\">";
                // line 18
                yield CoreExtension::getAttribute($this->env, $this->source, $context["result"], "info", [], "any", false, false, false, 18);
                yield "</small>
            ";
            }
            // line 20
            yield "            ";
            if ( !CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 20)) {
                yield "<hr>";
            }
            // line 21
            yield "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['result'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        yield "
    </div>
</div>

<style>
div.configuration-notices pre {
    overflow-x: scroll;
    max-width: 21em;
    border: 1px solid #EEE;
    background: #F8F8F8;
    padding: 0.5rem;
}
</style>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@configuration-notices-widget/configuration.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  129 => 22,  115 => 21,  110 => 20,  105 => 18,  101 => 17,  92 => 16,  75 => 15,  56 => 5,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!-- Generated at \"{{ \"now\"|date('Y-m-d H:i:s') }}\" -->
<div class=\"card mb-4\">
    <div class=\"progress\" style=\"width: 100%; height: 10px; border-radius: 0;\">
        <div class=\"card-header progress-bar progress-bar-striped progress-bar-animated
            {% if results.severity == 1 %}bg-info{% elseif results.severity == 2 %}bg-warning{% else %}bg-danger{% endif %}\" style=\"width: 100%;\">
        </div>
    </div>
    <div class=\"card-header\">
        <span  style=\"text-align: left;\"><i class=\"fas fa-lightbulb\" style=\"display: inline-block\"></i>  Bolt Configuration Notices</span>
    </div>
    <div class=\"card-body configuration-notices\">

        <p>Bolt has detected one or more configuration issues. You should resolve these, for optimum performance:</p>

        {% for result in results.notices %}
            <p><span class=\"badge bg-{{ result.severity }}\">{{ result.severity|ucwords }}</span> - {{ result.notice|raw }}
            {% if result.info %}</p>
            <small style=\"padding-top: 0.5rem; display: block;\">{{ result.info|raw }}</small>
            {% endif %}
            {% if not loop.last %}<hr>{% endif %}
        {% endfor %}

    </div>
</div>

<style>
div.configuration-notices pre {
    overflow-x: scroll;
    max-width: 21em;
    border: 1px solid #EEE;
    background: #F8F8F8;
    padding: 0.5rem;
}
</style>
", "@configuration-notices-widget/configuration.html.twig", "/var/www/boltcms/vendor/bobdenotter/configuration-notices/templates/configuration.html.twig");
    }
}
