<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/_label.html.twig */
class __TwigTemplate_3de3b9ff8ddc80420804fd8042950151 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/_label.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/_label.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/_partials/fields/_label.html.twig", 1)->unwrap();
        // line 3
        if ((((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 3, $this->source); })()))) : ("")) != "checkbox")) {
            // line 5
            if (((array_key_exists("localize", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["localize"]) || array_key_exists("localize", $context) ? $context["localize"] : (function () { throw new RuntimeError('Variable "localize" does not exist.', 5, $this->source); })()))) : (""))) {
                // line 6
                yield "<span style=\"color: #999; font-size: 140%; line-height: 0;\" class=\"";
                if ((((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 6, $this->source); })()))) : ("")) != "collection")) {
                    yield "float-right";
                }
                yield "\" title=\"";
                yield $this->extensions['Bolt\Twig\LocaleExtension']->translate("label.translatable");
                yield "\">";
                yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["language"], 6, $context, $this->getSourceContext());
                yield "</span>";
            }
            // line 9
            yield "<label for=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 9, $this->source); })()), "html", null, true);
            yield "\" class=\"editor--label";
            if ((((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 9, $this->source); })()))) : ("")) == "collection")) {
                yield " sr-only";
            }
            yield "\">";
            // line 11
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 11, $this->source); })()), "html", null, true);
            yield ":
        ";
            // line 12
            if ((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 12, $this->source); })())) {
                yield " <span class=\"required-label\"></span> ";
            }
            // line 13
            yield "
        ";
            // line 14
            if (((array_key_exists("info", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 14, $this->source); })()))) : (""))) {
                // line 15
                yield "            <i class=\"fa fa-info-circle\" data-toggle=\"popover\" data-trigger=\"hover\" title=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 15, $this->source); })()), "html", null, true);
                yield "\" data-html=\"true\" data-content=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 15, $this->source); })()), "html", null, true);
                yield "\"></i>
        ";
            }
            // line 17
            yield "    </label>";
        }
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/_label.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  94 => 17,  86 => 15,  84 => 14,  81 => 13,  77 => 12,  73 => 11,  65 => 9,  54 => 6,  52 => 5,  50 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '@bolt/_macro/_macro.html.twig' as macro %}

{%- if type|default() != 'checkbox' -%}

    {%- if localize|default() -%}
        <span style=\"color: #999; font-size: 140%; line-height: 0;\" class=\"{% if type|default() != 'collection' %}float-right{% endif %}\" title=\"{{ __('label.translatable') }}\">{{ macro.icon('language') }}</span>
    {%- endif -%}

    <label for=\"{{ id }}\" class=\"editor--label{% if type|default() == 'collection' %} sr-only{% endif %}\">

        {{- label -}}:
        {% if required %} <span class=\"required-label\"></span> {% endif %}

        {% if info|default() %}
            <i class=\"fa fa-info-circle\" data-toggle=\"popover\" data-trigger=\"hover\" title=\"{{ label }}\" data-html=\"true\" data-content=\"{{ info }}\"></i>
        {% endif %}
    </label>
{%- endif -%}
", "@bolt/_partials/fields/_label.html.twig", "/var/www/boltcms/vendor/bolt/core/templates/_partials/fields/_label.html.twig");
    }
}
