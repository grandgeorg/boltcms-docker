<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Translation/SymfonyProfiler/translation.html.twig */
class __TwigTemplate_833609e231dceb0593ba1ba2403fad6e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'panel' => [$this, 'block_panel'],
            'defined_messages' => [$this, 'block_defined_messages'],
            'fallback_messages' => [$this, 'block_fallback_messages'],
            'missing_messages' => [$this, 'block_missing_messages'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@WebProfiler/Collector/translation.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Translation/SymfonyProfiler/translation.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@Translation/SymfonyProfiler/translation.html.twig"));

        // line 7
        $macros["helper"] = $this->macros["helper"] = $this;
        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Collector/translation.html.twig", "@Translation/SymfonyProfiler/translation.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 9
    public function block_panel($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panel"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panel"));

        // line 10
        yield "    <h2>PHP Translation</h2>

    <div>
        <a class=\"btn\" href=\"javascript:void(0);\" onclick='syncAll()'>Synchronize all translations</a><br />
        <div id=\"top-result-area\"></div>
    </div>

    ";
        // line 17
        yield from $this->yieldParentBlock("panel", $context, $blocks);
        yield "

    <span class=\"hidden\">
        <img src=\"";
        // line 20
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\AssetsExtension']->getAssetUrl("bundles/translation/css/images/loader.svg"), "html", null, true);
        yield "\" width=\"60\" id=\"svg-loader\">
    </span>

    ";
        // line 23
        yield from         $this->loadTemplate("@Translation/SymfonyProfiler/javascripts.html.twig", "@Translation/SymfonyProfiler/translation.html.twig", 23)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 26
    public function block_defined_messages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "defined_messages"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "defined_messages"));

        // line 27
        yield "    ";
        $context["messages"] = [];
        // line 28
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, CoreExtension::getAttribute($this->env, $this->source, (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new RuntimeError('Variable "collector" does not exist.', 28, $this->source); })()), "messages", [], "any", false, false, false, 28), function ($__message__) use ($context, $macros) { $context["message"] = $__message__; return (CoreExtension::getAttribute($this->env, $this->source, $context["message"], "state", [], "any", false, false, false, 28) == Twig\Extension\CoreExtension::constant("Symfony\\Component\\Translation\\DataCollectorTranslator::MESSAGE_DEFINED")); }));
        foreach ($context['_seq'] as $context["key"] => $context["message"]) {
            // line 29
            yield "        ";
            $context["messages"] = Twig\Extension\CoreExtension::merge((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 29, $this->source); })()), [$context["key"] => $context["message"]]);
            // line 30
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['message'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        yield "
    ";
        // line 32
        yield CoreExtension::callMacro($macros["helper"], "macro_render_table", [(isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 32, $this->source); })())], 32, $context, $this->getSourceContext());
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 35
    public function block_fallback_messages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "fallback_messages"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "fallback_messages"));

        // line 36
        yield "    ";
        $context["messages"] = [];
        // line 37
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, CoreExtension::getAttribute($this->env, $this->source, (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new RuntimeError('Variable "collector" does not exist.', 37, $this->source); })()), "messages", [], "any", false, false, false, 37), function ($__message__) use ($context, $macros) { $context["message"] = $__message__; return (CoreExtension::getAttribute($this->env, $this->source, $context["message"], "state", [], "any", false, false, false, 37) == Twig\Extension\CoreExtension::constant("Symfony\\Component\\Translation\\DataCollectorTranslator::MESSAGE_EQUALS_FALLBACK")); }));
        foreach ($context['_seq'] as $context["key"] => $context["message"]) {
            // line 38
            yield "        ";
            $context["messages"] = Twig\Extension\CoreExtension::merge((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 38, $this->source); })()), [$context["key"] => $context["message"]]);
            // line 39
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['message'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        yield "
    ";
        // line 41
        yield CoreExtension::callMacro($macros["helper"], "macro_render_table", [(isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 41, $this->source); })())], 41, $context, $this->getSourceContext());
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 44
    public function block_missing_messages($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "missing_messages"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "missing_messages"));

        // line 45
        yield "    ";
        $context["messages"] = [];
        // line 46
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, CoreExtension::getAttribute($this->env, $this->source, (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new RuntimeError('Variable "collector" does not exist.', 46, $this->source); })()), "messages", [], "any", false, false, false, 46), function ($__message__) use ($context, $macros) { $context["message"] = $__message__; return (CoreExtension::getAttribute($this->env, $this->source, $context["message"], "state", [], "any", false, false, false, 46) == Twig\Extension\CoreExtension::constant("Symfony\\Component\\Translation\\DataCollectorTranslator::MESSAGE_MISSING")); }));
        foreach ($context['_seq'] as $context["key"] => $context["message"]) {
            // line 47
            yield "        ";
            $context["messages"] = Twig\Extension\CoreExtension::merge((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 47, $this->source); })()), [$context["key"] => $context["message"]]);
            // line 48
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['message'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        yield "
    <form action=\"";
        // line 50
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("php_translation_profiler_translation_create_assets", ["token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 50, $this->source); })())]), "html", null, true);
        yield "\" method=\"post\"
        id=\"translations-list\" onSubmit=\"return saveTranslations(this);\" >

            ";
        // line 53
        yield CoreExtension::callMacro($macros["helper"], "macro_render_table", [(isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 53, $this->source); })()), true], 53, $context, $this->getSourceContext());
        yield "

        <p class=\"full-width\" id=\"translationResult\"></p>

        <button type=\"submit\" class=\"btn\">
            Add selected messages
        </button>

    </form>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        return; yield '';
    }

    // line 64
    public function macro_render_table($__messages__ = null, $__withCheckbox__ = false, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "messages" => $__messages__,
            "withCheckbox" => $__withCheckbox__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "render_table"));

            $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "macro", "render_table"));

            // line 65
            yield "    <table>
        <thead>
        <tr>
            ";
            // line 68
            if ((isset($context["withCheckbox"]) || array_key_exists("withCheckbox", $context) ? $context["withCheckbox"] : (function () { throw new RuntimeError('Variable "withCheckbox" does not exist.', 68, $this->source); })())) {
                // line 69
                yield "                <th>
                    <input type=\"checkbox\" id=\"check-all-control\" onchange=\"toggleCheckAll(this)\" checked=\"checked\">
                </th>
            ";
            }
            // line 73
            yield "            <th>Locale</th>
            <th>Domain</th>
            <th>Times used</th>
            <th>Message ID</th>
            <th>Message Preview</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["messages"]) || array_key_exists("messages", $context) ? $context["messages"] : (function () { throw new RuntimeError('Variable "messages" does not exist.', 82, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["key"] => $context["message"]) {
                // line 83
                yield "            <tr id=\"";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                yield "\">
                <td>
                    ";
                // line 85
                if ((isset($context["withCheckbox"]) || array_key_exists("withCheckbox", $context) ? $context["withCheckbox"] : (function () { throw new RuntimeError('Variable "withCheckbox" does not exist.', 85, $this->source); })())) {
                    // line 86
                    yield "                        <input type=\"checkbox\" name=\"translationKey\" value=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                    yield "\" checked=\"checked\" class=\"translation-key-checkbox\">
                    ";
                }
                // line 88
                yield "                </td>
                <td class=\"font-normal text-small\">";
                // line 89
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "locale", [], "any", false, false, false, 89), "html", null, true);
                yield "</td>
                <td class=\"font-normal text-small text-bold nowrap\">";
                // line 90
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "domain", [], "any", false, false, false, 90), "html", null, true);
                yield "</td>
                <td class=\"font-normal text-small\">";
                // line 91
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "count", [], "any", false, false, false, 91), "html", null, true);
                yield "</td>
                <td>
                    ";
                // line 93
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "id", [], "any", false, false, false, 93), "html", null, true);
                yield "

                    ";
                // line 95
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["message"], "transChoiceNumber", [], "any", false, false, false, 95))) {
                    // line 96
                    yield "                        <small class=\"newline\">(pluralization is used)</small>
                    ";
                }
                // line 98
                yield "
                    ";
                // line 99
                if (($this->extensions['Bolt\Twig\ArrayExtension']->length($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["message"], "parameters", [], "any", false, false, false, 99)) > 0)) {
                    // line 100
                    yield "                        <button class=\"btn-link newline text-small sf-toggle\" data-toggle-selector=\"#parameters-";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 100), "html", null, true);
                    yield "\" data-toggle-alt-content=\"Hide parameters\">Show parameters</button>

                        <div id=\"parameters-";
                    // line 102
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 102), "html", null, true);
                    yield "\" class=\"hidden\">
                            ";
                    // line 103
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "parameters", [], "any", false, false, false, 103));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["parameters"]) {
                        // line 104
                        yield "                                ";
                        yield $this->extensions['Symfony\Bundle\WebProfilerBundle\Twig\WebProfilerExtension']->dumpData($this->env, $context["parameters"]);
                        yield "
                                ";
                        // line 105
                        if ( !CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 105)) {
                            yield "<br />";
                        }
                        // line 106
                        yield "                            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['parameters'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 107
                    yield "                        </div>
                    ";
                }
                // line 109
                yield "                </td>
                <td class=\"translation\">
                    ";
                // line 111
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["message"], "translation", [], "any", false, false, false, 111), "html", null, true);
                yield "
                </td>
                <td width=\"155px\">
                    ";
                // line 114
                $___internal_parse_2_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                    // line 115
                    yield "                    <a class=\"edit btn btn-sm\" href=\"javascript:void(0);\" onclick='getEditForm(\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                    yield "\")'>Edit</a>
                        |
                    <a class=\"sync btn btn-sm\" href=\"javascript:void(0);\" onclick='syncMessage(\"";
                    // line 117
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
                    yield "\")'>Sync</a>
                    ";
                    return; yield '';
                })())) ? '' : new Markup($tmp, $this->env->getCharset());
                // line 114
                yield Twig\Extension\CoreExtension::spaceless($___internal_parse_2_);
                // line 119
                yield "                </td>
            </tr>
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 122
            yield "        </tbody>
    </table>
";
            
            $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

            
            $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Translation/SymfonyProfiler/translation.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  456 => 122,  440 => 119,  438 => 114,  432 => 117,  426 => 115,  424 => 114,  418 => 111,  414 => 109,  410 => 107,  396 => 106,  392 => 105,  387 => 104,  370 => 103,  366 => 102,  360 => 100,  358 => 99,  355 => 98,  351 => 96,  349 => 95,  344 => 93,  339 => 91,  335 => 90,  331 => 89,  328 => 88,  322 => 86,  320 => 85,  314 => 83,  297 => 82,  286 => 73,  280 => 69,  278 => 68,  273 => 65,  254 => 64,  233 => 53,  227 => 50,  224 => 49,  218 => 48,  215 => 47,  210 => 46,  207 => 45,  197 => 44,  184 => 41,  181 => 40,  175 => 39,  172 => 38,  167 => 37,  164 => 36,  154 => 35,  141 => 32,  138 => 31,  132 => 30,  129 => 29,  124 => 28,  121 => 27,  111 => 26,  100 => 23,  94 => 20,  88 => 17,  79 => 10,  69 => 9,  58 => 1,  56 => 7,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@WebProfiler/Collector/translation.html.twig' %}

{#
 # Authors Tobias Nyholm, Damien Alexandre (damienalexandre), Damien Harper
 #}

{% import _self as helper %}

{% block panel %}
    <h2>PHP Translation</h2>

    <div>
        <a class=\"btn\" href=\"javascript:void(0);\" onclick='syncAll()'>Synchronize all translations</a><br />
        <div id=\"top-result-area\"></div>
    </div>

    {{ parent() }}

    <span class=\"hidden\">
        <img src=\"{{ asset(\"bundles/translation/css/images/loader.svg\") }}\" width=\"60\" id=\"svg-loader\">
    </span>

    {% include \"@Translation/SymfonyProfiler/javascripts.html.twig\" %}
{% endblock %}

{% block defined_messages %}
    {% set messages = [] %}
    {% for key, message in collector.messages|filter(message => message.state == constant('Symfony\\\\Component\\\\Translation\\\\DataCollectorTranslator::MESSAGE_DEFINED')) %}
        {% set messages = messages|merge({(key): message}) %}
    {% endfor %}

    {{ helper.render_table(messages) }}
{% endblock %}

{% block fallback_messages %}
    {% set messages = [] %}
    {% for key, message in collector.messages|filter(message => message.state == constant('Symfony\\\\Component\\\\Translation\\\\DataCollectorTranslator::MESSAGE_EQUALS_FALLBACK')) %}
        {% set messages = messages|merge({(key): message}) %}
    {% endfor %}

    {{ helper.render_table(messages) }}
{% endblock %}

{% block missing_messages %}
    {% set messages = [] %}
    {% for key, message in collector.messages|filter(message => message.state == constant('Symfony\\\\Component\\\\Translation\\\\DataCollectorTranslator::MESSAGE_MISSING')) %}
        {% set messages = messages|merge({(key): message}) %}
    {% endfor %}

    <form action=\"{{ path('php_translation_profiler_translation_create_assets', {'token': token}) }}\" method=\"post\"
        id=\"translations-list\" onSubmit=\"return saveTranslations(this);\" >

            {{ helper.render_table(messages, true) }}

        <p class=\"full-width\" id=\"translationResult\"></p>

        <button type=\"submit\" class=\"btn\">
            Add selected messages
        </button>

    </form>
{% endblock %}

{% macro render_table(messages, withCheckbox = false) %}
    <table>
        <thead>
        <tr>
            {% if withCheckbox %}
                <th>
                    <input type=\"checkbox\" id=\"check-all-control\" onchange=\"toggleCheckAll(this)\" checked=\"checked\">
                </th>
            {% endif %}
            <th>Locale</th>
            <th>Domain</th>
            <th>Times used</th>
            <th>Message ID</th>
            <th>Message Preview</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        {% for key, message in messages %}
            <tr id=\"{{ key }}\">
                <td>
                    {% if withCheckbox %}
                        <input type=\"checkbox\" name=\"translationKey\" value=\"{{ key }}\" checked=\"checked\" class=\"translation-key-checkbox\">
                    {% endif %}
                </td>
                <td class=\"font-normal text-small\">{{ message.locale }}</td>
                <td class=\"font-normal text-small text-bold nowrap\">{{ message.domain }}</td>
                <td class=\"font-normal text-small\">{{ message.count }}</td>
                <td>
                    {{ message.id }}

                    {% if message.transChoiceNumber is not null %}
                        <small class=\"newline\">(pluralization is used)</small>
                    {% endif %}

                    {% if message.parameters|length > 0 %}
                        <button class=\"btn-link newline text-small sf-toggle\" data-toggle-selector=\"#parameters-{{ loop.index }}\" data-toggle-alt-content=\"Hide parameters\">Show parameters</button>

                        <div id=\"parameters-{{ loop.index }}\" class=\"hidden\">
                            {% for parameters in message.parameters %}
                                {{ profiler_dump(parameters) }}
                                {% if not loop.last %}<br />{% endif %}
                            {% endfor %}
                        </div>
                    {% endif %}
                </td>
                <td class=\"translation\">
                    {{ message.translation }}
                </td>
                <td width=\"155px\">
                    {% apply spaceless %}
                    <a class=\"edit btn btn-sm\" href=\"javascript:void(0);\" onclick='getEditForm(\"{{ key }}\")'>Edit</a>
                        |
                    <a class=\"sync btn btn-sm\" href=\"javascript:void(0);\" onclick='syncMessage(\"{{ key }}\")'>Sync</a>
                    {% endapply %}
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
{% endmacro %}
", "@Translation/SymfonyProfiler/translation.html.twig", "/var/www/boltcms/vendor/php-translation/symfony-bundle/Resources/views/SymfonyProfiler/translation.html.twig");
    }
}
