<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/graphql' => [[['_route' => 'api_graphql_entrypoint', '_controller' => 'api_platform.graphql.action.entrypoint', '_graphql' => true], null, null, null, false, false, null]],
        '/api/graphql/graphql_playground' => [[['_route' => 'api_graphql_graphql_playground', '_controller' => 'api_platform.graphql.action.graphql_playground', '_graphql' => true], null, null, null, false, false, null]],
        '/bolt/api' => [[['_route' => 'api_entrypoint', '_controller' => 'api_platform.swagger.action.ui'], null, null, null, false, false, null]],
        '/bolt/login' => [[['_route' => 'bolt_login', '_controller' => 'Bolt\\Controller\\Backend\\AuthenticationController::login'], null, null, null, false, false, null]],
        '/bolt/logout' => [[['_route' => 'bolt_logout', '_controller' => 'Bolt\\Controller\\Backend\\AuthenticationController::logout'], null, null, null, false, false, null]],
        '/bolt/bulk/delete' => [[['_route' => 'bolt_bulk_delete', '_controller' => 'Bolt\\Controller\\Backend\\BulkOperationsController::delete'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/clearcache' => [[['_route' => 'bolt_clear_cache', '_controller' => 'Bolt\\Controller\\Backend\\ClearCacheController::index'], null, null, null, false, false, null]],
        '/bolt' => [[['_route' => 'bolt_dashboard', '_controller' => 'Bolt\\Controller\\Backend\\DashboardController::index'], null, ['GET' => 0], null, true, false, null]],
        '/bolt/extensions' => [[['_route' => 'bolt_extensions', '_controller' => 'Bolt\\Controller\\Backend\\ExtensionsController::index'], null, null, null, false, false, null]],
        '/bolt/file-delete' => [[['_route' => 'bolt_file_delete', '_controller' => 'Bolt\\Controller\\Backend\\FileEditController::handleDelete'], null, ['POST' => 0, 'GET' => 1], null, true, false, null]],
        '/bolt/file-duplicate' => [[['_route' => 'bolt_file_duplicate', '_controller' => 'Bolt\\Controller\\Backend\\FileEditController::handleDuplicate'], null, ['POST' => 0, 'GET' => 1], null, true, false, null]],
        '/bolt/filemanager-actions/delete' => [[['_route' => 'bolt_filemanager_delete', '_controller' => 'Bolt\\Controller\\Backend\\FilemanagerController::delete'], null, ['POST' => 0, 'GET' => 1], null, true, false, null]],
        '/bolt/filemanager-actions/create' => [[['_route' => 'bolt_filemanager_create', '_controller' => 'Bolt\\Controller\\Backend\\FilemanagerController::create'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/about' => [[['_route' => 'bolt_about', '_controller' => 'Bolt\\Controller\\Backend\\GeneralController::about'], null, null, null, false, false, null]],
        '/bolt/kitchensink' => [[['_route' => 'bolt_kitchensink', '_controller' => 'Bolt\\Controller\\Backend\\GeneralController::kitchensink'], null, null, null, false, false, null]],
        '/bolt/logviewer' => [[['_route' => 'bolt_logviewer', '_controller' => 'Bolt\\Controller\\Backend\\LogViewerController::index'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/media/new' => [[['_route' => 'bolt_media_new', '_controller' => 'Bolt\\Controller\\Backend\\MediaEditController::new'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/reset-password' => [[['_route' => 'bolt_forgot_password_request', '_controller' => 'Bolt\\Controller\\Backend\\ResetPasswordController::request'], null, null, null, false, false, null]],
        '/bolt/reset-password/check-email' => [[['_route' => 'bolt_check_email', '_controller' => 'Bolt\\Controller\\Backend\\ResetPasswordController::checkEmail'], null, null, null, false, false, null]],
        '/bolt/users' => [[['_route' => 'bolt_users', '_controller' => 'Bolt\\Controller\\Backend\\UserController::users'], null, null, null, false, false, null]],
        '/bolt/user-edit/add' => [[['_route' => 'bolt_user_add', '_controller' => 'Bolt\\Controller\\Backend\\UserEditController::add'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/bolt/profile-edit' => [[['_route' => 'bolt_profile_edit', '_controller' => 'Bolt\\Controller\\Backend\\UserEditController::editProfile'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/bolt/async/embed' => [[['_route' => 'bolt_async_embed', '_controller' => 'Bolt\\Controller\\Backend\\Async\\EmbedController::fetchEmbed'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/async/list_files' => [[['_route' => 'bolt_async_filelisting', '_controller' => 'Bolt\\Controller\\Backend\\Async\\FileListingController::index'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/async/upload-url' => [[['_route' => 'bolt_async_upload_url', '_controller' => 'Bolt\\Controller\\Backend\\Async\\UploadController::handleURLUpload'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/async/upload' => [[['_route' => 'bolt_async_upload', '_controller' => 'Bolt\\Controller\\Backend\\Async\\UploadController::handleUpload'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/async/article_images' => [[['_route' => 'bolt_article_images', '_controller' => 'Bolt\\Article\\Controller\\Images::getImagesList'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/async/article_files' => [[['_route' => 'bolt_article_files', '_controller' => 'Bolt\\Article\\Controller\\Images::getFilesList'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/async/bolt_article_image_upload' => [[['_route' => 'bolt_article_image_upload', '_controller' => 'Bolt\\Article\\Controller\\Upload::handleImageUpload'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/async/bolt_article_file_upload' => [[['_route' => 'bolt_article_file_upload', '_controller' => 'Bolt\\Article\\Controller\\Upload::handleFileUpload'], null, ['POST' => 0], null, false, false, null]],
        '/bolt/async/redactor_images' => [[['_route' => 'bolt_redactor_images', '_controller' => 'Bolt\\Redactor\\Controller\\Images::getImagesList'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/async/redactor_files' => [[['_route' => 'bolt_redactor_files', '_controller' => 'Bolt\\Redactor\\Controller\\Images::getFilesList'], null, ['GET' => 0], null, false, false, null]],
        '/bolt/async/redactor_upload' => [[['_route' => 'bolt_redactor_upload', '_controller' => 'Bolt\\Redactor\\Controller\\Upload::handleUpload'], null, ['POST' => 0], null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'homepage', '_controller' => 'Bolt\\Controller\\Frontend\\HomepageController::homepage'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/search' => [[['_route' => 'search', '_controller' => 'Bolt\\Controller\\Frontend\\SearchController::search'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/a(?'
                    .'|pi/(?'
                        .'|\\.well\\-known/genid/([^/]++)(*:46)'
                        .'|docs(?:\\.([^/]++))?(*:72)'
                        .'|conte(?'
                            .'|xts/([^.]+)(?:\\.(jsonld))?(*:113)'
                            .'|nts(?'
                                .'|(?:\\.([^/]++))?(?'
                                    .'|(*:145)'
                                .')'
                                .'|/(?'
                                    .'|([^/\\.]++)(?:\\.([^/]++))?(?'
                                        .'|(*:186)'
                                    .')'
                                    .'|([^/]++)/fields(?:\\.([^/]++))?(*:225)'
                                .')'
                            .')'
                        .')'
                        .'|fields(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:263)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:301)'
                            .')'
                        .')'
                        .'|relations(?'
                            .'|(?:\\.([^/]++))?(?'
                                .'|(*:341)'
                            .')'
                            .'|/([^/\\.]++)(?:\\.([^/]++))?(?'
                                .'|(*:379)'
                            .')'
                        .')'
                    .')'
                    .'|dmin/_trans(?'
                        .'|(?:/([^/]++))?(*:418)'
                        .'|/([^/]++)/([^/]++)/([^/]++)(?'
                            .'|(*:456)'
                            .'|/new(*:468)'
                            .'|(*:476)'
                        .')'
                    .')'
                .')'
                .'|/bolt/(?'
                    .'|bulk/status/([^/]++)(*:516)'
                    .'|new/([^/]++)(*:536)'
                    .'|e(?'
                        .'|dit(?'
                            .'|/(?'
                                .'|(\\d+)(*:563)'
                                .'|([^/]++)/([^/]++)(*:588)'
                                .'|(\\d+)(*:601)'
                            .')'
                            .'|_locales/([^/]++)(*:627)'
                        .')'
                        .'|xtensions/(.+)(*:650)'
                    .')'
                    .'|d(?'
                        .'|uplicate/(\\d+)(?'
                            .'|(*:680)'
                        .')'
                        .'|elete/(\\d+)(*:700)'
                    .')'
                    .'|status/(\\d+)(*:721)'
                    .'|file(?'
                        .'|\\-edit/([^/]++)(?'
                            .'|(*:754)'
                        .')'
                        .'|manager/([^/]++)(*:779)'
                    .')'
                    .'|content(?:/([^/]++))?(*:809)'
                    .'|me(?'
                        .'|dia/edit/([^/]++)(?'
                            .'|(*:842)'
                        .')'
                        .'|nu/([^/]++)(*:862)'
                    .')'
                    .'|reset\\-password/reset(?:/([^/]++))?(*:906)'
                    .'|user\\-(?'
                        .'|edit/(\\d+)(*:933)'
                        .'|status/(\\d+)(*:953)'
                        .'|delete/(\\d+)(*:973)'
                    .')'
                .')'
                .'|/thumbs/([^/]++)/(.+)(*:1004)'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:1041)'
                .'|/([^/]++)/translation/(?'
                    .'|edit(*:1079)'
                    .'|sync(?'
                        .'|(*:1095)'
                        .'|_all(*:1108)'
                    .')'
                    .'|create_assets(*:1131)'
                .')'
                .'|/_(?'
                    .'|wdt/([^/]++)(*:1158)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:1205)'
                            .'|router(*:1220)'
                            .'|exception(?'
                                .'|(*:1241)'
                                .'|\\.css(*:1255)'
                            .')'
                        .')'
                        .'|(*:1266)'
                    .')'
                .')'
                .'|/(homepage|pages|entries|people|blocks|products|page|entry|person|block|product)/([^/]++)(*:1366)'
                .'|/(en|nl|es|fr|de|pl|it|hu|pt_BR|ja|nb|nn|nl_NL|nl_BE|is|ru|cs|bg)/(homepage|pages|entries|people|blocks|products|page|entry|person|block|product)/([^/]++)(*:1529)'
                .'|/(en|nl|es|fr|de|pl|it|hu|pt_BR|ja|nb|nn|nl_NL|nl_BE|is|ru|cs|bg)(*:1603)'
                .'|/(homepage|pages|entries|people|blocks|products|page|entry|person|block|product)(*:1692)'
                .'|/(en|nl|es|fr|de|pl|it|hu|pt_BR|ja|nb|nn|nl_NL|nl_BE|is|ru|cs|bg)/(homepage|pages|entries|people|blocks|products|page|entry|person|block|product)(*:1846)'
                .'|/preview/(\\d+)(?'
                    .'|(*:1872)'
                .')'
                .'|/([^/]++)/search(*:1898)'
                .'|/(tags|groups|categories|tag|group|category)/([^/]++)(*:1960)'
                .'|/(en|nl|es|fr|de|pl|it|hu|pt_BR|ja|nb|nn|nl_NL|nl_BE|is|ru|cs|bg)/(tags|groups|categories|tag|group|category)/([^/]++)(*:2087)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        46 => [[['_route' => 'api_genid', '_controller' => 'api_platform.action.not_exposed', '_api_respond' => 'true'], ['id'], null, null, false, true, null]],
        72 => [[['_route' => 'api_doc', '_controller' => 'api_platform.action.documentation', '_format' => '', '_api_respond' => 'true'], ['_format'], null, null, false, true, null]],
        113 => [[['_route' => 'api_jsonld_context', '_controller' => 'api_platform.jsonld.action.context', '_format' => 'jsonld', '_api_respond' => 'true'], ['shortName', '_format'], null, null, false, true, null]],
        145 => [
            [['_route' => 'api_contents_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Content', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_contents_get_collection', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_contents_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Content', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_contents_post_collection', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        186 => [
            [['_route' => 'api_contents_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Content', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_contents_get_item', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_contents_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Content', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_contents_put_item', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_contents_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Content', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_contents_delete_item', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        225 => [[['_route' => 'api_contents_fields_get_subresource', '_controller' => 'api_platform.action.get_subresource', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id' => ['Bolt\\Entity\\Content', 'id', true]], '_api_has_composite_identifier' => false, '_api_subresource_operation_name' => 'api_contents_fields_get_subresource', '_api_subresource_context' => ['property' => 'fields', 'identifiers' => ['id' => ['Bolt\\Entity\\Content', 'id', true]], 'collection' => true, 'operationId' => 'api_contents_fields_get_subresource']], ['id', '_format'], ['GET' => 0], null, false, true, null]],
        263 => [
            [['_route' => 'api_fields_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_fields_get_collection', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_fields_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_fields_post_collection', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        301 => [
            [['_route' => 'api_fields_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_fields_get_item', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_fields_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_fields_put_item', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_fields_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Field', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_fields_delete_item', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        341 => [
            [['_route' => 'api_relations_get_collection', '_controller' => 'api_platform.action.get_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Relation', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_relations_get_collection', '_api_collection_operation_name' => 'get'], ['_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_relations_post_collection', '_controller' => 'api_platform.action.post_collection', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Relation', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_relations_post_collection', '_api_collection_operation_name' => 'post'], ['_format'], ['POST' => 0], null, false, true, null],
        ],
        379 => [
            [['_route' => 'api_relations_get_item', '_controller' => 'api_platform.action.get_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Relation', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_relations_get_item', '_api_item_operation_name' => 'get'], ['id', '_format'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_relations_put_item', '_controller' => 'api_platform.action.put_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Relation', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_relations_put_item', '_api_item_operation_name' => 'put'], ['id', '_format'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'api_relations_delete_item', '_controller' => 'api_platform.action.delete_item', '_format' => null, '_stateless' => null, '_api_resource_class' => 'Bolt\\Entity\\Relation', '_api_identifiers' => ['id'], '_api_has_composite_identifier' => false, '_api_exception_to_status' => [], '_api_operation_name' => 'api_relations_delete_item', '_api_item_operation_name' => 'delete'], ['id', '_format'], ['DELETE' => 0], null, false, true, null],
        ],
        418 => [[['_route' => 'translation_index', '_controller' => 'Translation\\Bundle\\Controller\\WebUIController::indexAction', 'configName' => null], ['configName'], ['GET' => 0], null, false, true, null]],
        456 => [[['_route' => 'translation_show', '_controller' => 'Translation\\Bundle\\Controller\\WebUIController::showAction'], ['configName', 'locale', 'domain'], ['GET' => 0], null, false, true, null]],
        468 => [[['_route' => 'translation_create', '_controller' => 'Translation\\Bundle\\Controller\\WebUIController::createAction'], ['configName', 'locale', 'domain'], ['POST' => 0], null, false, false, null]],
        476 => [
            [['_route' => 'translation_edit', '_controller' => 'Translation\\Bundle\\Controller\\WebUIController::editAction'], ['configName', 'locale', 'domain'], ['POST' => 0], null, false, true, null],
            [['_route' => 'translation_delete', '_controller' => 'Translation\\Bundle\\Controller\\WebUIController::deleteAction'], ['configName', 'locale', 'domain'], ['DELETE' => 0], null, false, true, null],
        ],
        516 => [[['_route' => 'bolt_bulk_status', '_controller' => 'Bolt\\Controller\\Backend\\BulkOperationsController::status'], ['status'], ['POST' => 0], null, false, true, null]],
        536 => [[['_route' => 'bolt_content_new', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::new'], ['contentType'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        563 => [[['_route' => 'bolt_content_edit', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::edit'], ['id'], ['GET' => 0], null, false, true, null]],
        588 => [[['_route' => 'bolt_edit_content_slug', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::editFromSlug'], ['_locale', 'slugOrId'], ['GET' => 0], null, false, true, null]],
        601 => [[['_route' => 'bolt_content_edit_post', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::save'], ['id'], ['POST' => 0], null, false, true, null]],
        627 => [[['_route' => 'bolt_content_edit_locales', '_controller' => 'Bolt\\Controller\\Backend\\ContentLocalizationController::locales'], ['id'], ['GET' => 0], null, false, true, null]],
        650 => [[['_route' => 'bolt_extensions_view', '_controller' => 'Bolt\\Controller\\Backend\\ExtensionsController::viewExtension'], ['name'], null, null, false, true, null]],
        680 => [
            [['_route' => 'bolt_content_duplicate', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::duplicate'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'bolt_content_duplicate_post', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::duplicateSave'], ['id'], ['POST' => 0], null, false, true, null],
        ],
        700 => [[['_route' => 'bolt_content_delete', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::delete'], ['id'], ['GET' => 0], null, false, true, null]],
        721 => [[['_route' => 'bolt_content_status', '_controller' => 'Bolt\\Controller\\Backend\\ContentEditController::status'], ['id'], ['GET' => 0], null, false, true, null]],
        754 => [
            [['_route' => 'bolt_file_edit', '_controller' => 'Bolt\\Controller\\Backend\\FileEditController::edit'], ['location'], ['GET' => 0], null, false, true, null],
            [['_route' => 'bolt_file-edit_post', '_controller' => 'Bolt\\Controller\\Backend\\FileEditController::save'], ['location'], ['POST' => 0], null, false, true, null],
        ],
        779 => [[['_route' => 'bolt_filemanager', '_controller' => 'Bolt\\Controller\\Backend\\FilemanagerController::filemanager'], ['location'], ['GET' => 0], null, false, true, null]],
        809 => [[['_route' => 'bolt_content_overview', 'contentType' => '', '_controller' => 'Bolt\\Controller\\Backend\\ListingController::overview'], ['contentType'], null, null, false, true, null]],
        842 => [
            [['_route' => 'bolt_media_edit', '_controller' => 'Bolt\\Controller\\Backend\\MediaEditController::edit'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'bolt_media_edit_post', '_controller' => 'Bolt\\Controller\\Backend\\MediaEditController::save'], ['id'], ['POST' => 0], null, false, true, null],
        ],
        862 => [[['_route' => 'bolt_menupage', '_controller' => 'Bolt\\Controller\\Backend\\MenuPageController::menuPage'], ['slug'], ['GET' => 0], null, false, true, null]],
        906 => [[['_route' => 'bolt_reset_password', 'token' => null, '_controller' => 'Bolt\\Controller\\Backend\\ResetPasswordController::reset'], ['token'], null, null, false, true, null]],
        933 => [[['_route' => 'bolt_user_edit', '_controller' => 'Bolt\\Controller\\Backend\\UserEditController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        953 => [[['_route' => 'bolt_user_update_status', '_controller' => 'Bolt\\Controller\\Backend\\UserEditController::status'], ['id'], ['POST' => 0, 'GET' => 1], null, false, true, null]],
        973 => [[['_route' => 'bolt_user_delete', '_controller' => 'Bolt\\Controller\\Backend\\UserEditController::delete'], ['id'], ['POST' => 0, 'GET' => 1], null, false, true, null]],
        1004 => [[['_route' => 'thumbnail', '_controller' => 'Bolt\\Controller\\ImageController::thumbnail'], ['paramString', 'filename'], ['GET' => 0], null, false, true, null]],
        1041 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        1079 => [[['_route' => 'php_translation_profiler_translation_edit', '_controller' => 'Translation\\Bundle\\Controller\\SymfonyProfilerController::editAction'], ['token'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1095 => [[['_route' => 'php_translation_profiler_translation_sync', '_controller' => 'Translation\\Bundle\\Controller\\SymfonyProfilerController::syncAction'], ['token'], ['POST' => 0], null, false, false, null]],
        1108 => [[['_route' => 'php_translation_profiler_translation_sync_all', '_controller' => 'Translation\\Bundle\\Controller\\SymfonyProfilerController::syncAllAction'], ['token'], ['POST' => 0], null, false, false, null]],
        1131 => [[['_route' => 'php_translation_profiler_translation_create_assets', '_controller' => 'Translation\\Bundle\\Controller\\SymfonyProfilerController::createAssetsAction'], ['token'], ['POST' => 0], null, false, false, null]],
        1158 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        1205 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        1220 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        1241 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        1255 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        1266 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        1366 => [[['_route' => 'record', 'contentTypeSlug' => null, '_controller' => 'Bolt\\Controller\\Frontend\\DetailController::record'], ['contentTypeSlug', 'slugOrId'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1529 => [[['_route' => 'record_locale', 'contentTypeSlug' => null, '_locale' => null, '_controller' => 'Bolt\\Controller\\Frontend\\DetailController::record'], ['_locale', 'contentTypeSlug', 'slugOrId'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1603 => [[['_route' => 'homepage_locale', '_controller' => 'Bolt\\Controller\\Frontend\\HomepageController::homepage'], ['_locale'], ['GET' => 0, 'POST' => 1], null, true, true, null]],
        1692 => [[['_route' => 'listing', '_controller' => 'Bolt\\Controller\\Frontend\\ListingController::listing'], ['contentTypeSlug'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1846 => [[['_route' => 'listing_locale', '_locale' => null, '_controller' => 'Bolt\\Controller\\Frontend\\ListingController::listing'], ['_locale', 'contentTypeSlug'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        1872 => [
            [['_route' => 'bolt_content_edit_preview', '_controller' => 'Bolt\\Controller\\Frontend\\PreviewController::preview'], ['id'], ['POST' => 0], null, false, true, null],
            [['_route' => 'bolt_content_edit_get', '_controller' => 'Bolt\\Controller\\Frontend\\PreviewController::previewThroughGet'], ['id'], ['GET' => 0], null, false, true, null],
        ],
        1898 => [[['_route' => 'search_locale', '_controller' => 'Bolt\\Controller\\Frontend\\SearchController::search'], ['_locale'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1960 => [[['_route' => 'taxonomy', '_controller' => 'Bolt\\Controller\\Frontend\\TaxonomyController::listing'], ['taxonomyslug', 'slug'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        2087 => [
            [['_route' => 'taxonomy_locale', '_controller' => 'Bolt\\Controller\\Frontend\\TaxonomyController::listing'], ['_locale', 'taxonomyslug', 'slug'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
