<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/image.html.twig */
class __TwigTemplate_c149e7ff96129060f0f317aaff6271b6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_partials/fields/_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/image.html.twig"));

        // line 3
        $context["extensions"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 3), "get", ["extensions"], "method", true, true, false, 3)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 3), "get", ["extensions"], "method", false, false, false, 3), [])) : ([]));
        // line 4
        $context["info"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 5
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("upload.allow_file_types"), "html", null, true);
            yield ": <code>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join((isset($context["extensions"]) || array_key_exists("extensions", $context) ? $context["extensions"] : (function () { throw new RuntimeError('Variable "extensions" does not exist.', 5, $this->source); })()), "</code>, <code>"), "html", null, true);
            yield "</code><br>
";
            // line 6
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("upload.max_size"), "html", null, true);
            yield ": ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\TextExtension']->formatBytes(CoreExtension::getAttribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 6, $this->source); })()), "maxupload", [], "any", false, false, false, 6)), "html", null, true);
            yield "
";
            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_partials/fields/_base.html.twig", "@bolt/_partials/fields/image.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 9
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 10
        yield "    ";
        if ( !array_key_exists("setPath", $context)) {
            // line 11
            yield "        ";
            $context["setPath"] = $this->extensions['Bolt\Twig\HtmlExtension']->placeholders(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 11, $this->source); })()), "definition", [], "any", false, false, false, 11), "get", ["upload"], "method", false, false, false, 11), ["contenttype" => CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 11, $this->source); })()), "contenttype", [], "any", false, false, false, 11)]);
            // line 12
            yield "    ";
        }
        // line 13
        yield "    ";
        $context["directory"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_async_upload", ["location" => ((array_key_exists("location", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new RuntimeError('Variable "location" does not exist.', 13, $this->source); })()), "files")) : ("files")), "path" => (isset($context["setPath"]) || array_key_exists("setPath", $context) ? $context["setPath"] : (function () { throw new RuntimeError('Variable "setPath" does not exist.', 13, $this->source); })())]);
        // line 14
        yield "    ";
        $context["directoryurl"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_async_upload_url", ["location" => ((array_key_exists("location", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new RuntimeError('Variable "location" does not exist.', 14, $this->source); })()), "files")) : ("files")), "path" => (isset($context["setPath"]) || array_key_exists("setPath", $context) ? $context["setPath"] : (function () { throw new RuntimeError('Variable "setPath" does not exist.', 14, $this->source); })())]);
        // line 15
        yield "    ";
        $context["filelist"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_async_filelisting", ["location" => ((array_key_exists("location", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new RuntimeError('Variable "location" does not exist.', 15, $this->source); })()), "files")) : ("files")), "type" => "images"]);
        // line 16
        yield "    ";
        $context["labels"] = json_encode(["button_upload" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_upload"), "button_upload_options" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_upload_options"), "button_from_library" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_from_library"), "button_remove" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_remove"), "placeholder_filename" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.placeholder_filename"), "placeholder_alt_text" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.placeholder_alt_text"), "button_edit_attributes" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_edit_attributes"), "button_from_url" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.button_from_url"), "image_preview" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("image.image_preview")]);
        // line 27
        yield "
    <editor-image
        :id='";
        // line 29
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 29, $this->source); })())), "html", null, true);
        yield "'
        :name='";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 30, $this->source); })())), "html", null, true);
        yield "'
        :filename='";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 31, $this->source); })()), "get", ["filename"], "method", false, false, false, 31)), "html", null, true);
        yield "'
        :media='";
        // line 32
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 32, $this->source); })()), "get", ["media"], "method", false, false, false, 32)), "html", null, true);
        yield "'
        :directory='";
        // line 33
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["directory"]) || array_key_exists("directory", $context) ? $context["directory"] : (function () { throw new RuntimeError('Variable "directory" does not exist.', 33, $this->source); })())), "html", null, true);
        yield "'
        :directoryurl='";
        // line 34
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["directoryurl"]) || array_key_exists("directoryurl", $context) ? $context["directoryurl"] : (function () { throw new RuntimeError('Variable "directoryurl" does not exist.', 34, $this->source); })())), "html", null, true);
        yield "'
        :filelist='";
        // line 35
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["filelist"]) || array_key_exists("filelist", $context) ? $context["filelist"] : (function () { throw new RuntimeError('Variable "filelist" does not exist.', 35, $this->source); })())), "html", null, true);
        yield "'
        :csrf-token='";
        // line 36
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("upload")), "html", null, true);
        yield "'
        :labels='";
        // line 37
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["labels"]) || array_key_exists("labels", $context) ? $context["labels"] : (function () { throw new RuntimeError('Variable "labels" does not exist.', 37, $this->source); })()), "html", null, true);
        yield "'
        :extensions='";
        // line 38
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["extensions"]) || array_key_exists("extensions", $context) ? $context["extensions"] : (function () { throw new RuntimeError('Variable "extensions" does not exist.', 38, $this->source); })())), "html", null, true);
        yield "'
        :attributes-link='";
        // line 39
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_media_new")), "html", null, true);
        yield "'
        :required='";
        // line 40
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 40, $this->source); })())), "html", null, true);
        yield "'
        :readonly='";
        // line 41
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 41, $this->source); })())), "html", null, true);
        yield "'
        :errormessage='";
        // line 42
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["errormessage"]) || array_key_exists("errormessage", $context) ? $context["errormessage"] : (function () { throw new RuntimeError('Variable "errormessage" does not exist.', 42, $this->source); })())), "html", null, true);
        yield "'
        :pattern='";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["pattern"]) || array_key_exists("pattern", $context) ? $context["pattern"] : (function () { throw new RuntimeError('Variable "pattern" does not exist.', 43, $this->source); })())), "html", null, true);
        yield "'
        :placeholder='";
        // line 44
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["placeholder"]) || array_key_exists("placeholder", $context) ? $context["placeholder"] : (function () { throw new RuntimeError('Variable "placeholder" does not exist.', 44, $this->source); })())), "html", null, true);
        yield "'
        :alt='";
        // line 45
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "get", ["alt"], "method", false, false, false, 45)), "html", null, true);
        yield "'
        :include-alt='";
        // line 46
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 46, $this->source); })()), "includeAlt", [], "any", false, false, false, 46)), "html", null, true);
        yield "'
    ></editor-image>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/image.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  176 => 46,  172 => 45,  168 => 44,  164 => 43,  160 => 42,  156 => 41,  152 => 40,  148 => 39,  144 => 38,  140 => 37,  136 => 36,  132 => 35,  128 => 34,  124 => 33,  120 => 32,  116 => 31,  112 => 30,  108 => 29,  104 => 27,  101 => 16,  98 => 15,  95 => 14,  92 => 13,  89 => 12,  86 => 11,  83 => 10,  76 => 9,  68 => 1,  60 => 6,  54 => 5,  52 => 4,  50 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_partials/fields/_base.html.twig' %}

{% set extensions = field.definition.get('extensions')|default([]) %}
{% set info %}
{{ 'upload.allow_file_types'|trans }}: <code>{{ extensions|join('</code>, <code>') }}</code><br>
{{ 'upload.max_size'|trans }}: {{ config.maxupload|format_bytes }}
{% endset %}

{% block field %}
    {% if setPath is not defined %}
        {% set setPath = field.definition.get('upload')|placeholders({'contenttype': record.contenttype}) %}
    {% endif %}
    {% set directory = path('bolt_async_upload', {'location': location|default('files'), 'path': setPath}) %}
    {% set directoryurl = path('bolt_async_upload_url', {'location': location|default('files'), 'path': setPath}) %}
    {% set filelist = path('bolt_async_filelisting', {'location': location|default('files'), 'type': 'images' }) %}
    {% set labels = {
        'button_upload': 'image.button_upload'|trans,
        'button_upload_options': 'image.button_upload_options'|trans,
        'button_from_library': 'image.button_from_library'|trans,
        'button_remove': 'image.button_remove'|trans,
        'placeholder_filename': 'image.placeholder_filename'|trans,
        'placeholder_alt_text': 'image.placeholder_alt_text'|trans,
        'button_edit_attributes': 'image.button_edit_attributes'|trans,
        'button_from_url': 'image.button_from_url'|trans,
        'image_preview': 'image.image_preview'|trans,
    }|json_encode %}

    <editor-image
        :id='{{ id|json_encode }}'
        :name='{{ name|json_encode }}'
        :filename='{{ field.get('filename')|json_encode }}'
        :media='{{ field.get('media')|json_encode }}'
        :directory='{{ directory|json_encode }}'
        :directoryurl='{{ directoryurl|json_encode }}'
        :filelist='{{ filelist|json_encode }}'
        :csrf-token='{{ csrf_token('upload')|json_encode }}'
        :labels='{{ labels }}'
        :extensions='{{ extensions|json_encode }}'
        :attributes-link='{{ path('bolt_media_new')|json_encode }}'
        :required='{{ required|json_encode }}'
        :readonly='{{ readonly|json_encode }}'
        :errormessage='{{ errormessage|json_encode }}'
        :pattern='{{ pattern|json_encode }}'
        :placeholder='{{ placeholder|json_encode }}'
        :alt='{{ field.get('alt')|json_encode }}'
        :include-alt='{{ field.includeAlt|json_encode }}'
    ></editor-image>
{% endblock %}
", "@bolt/_partials/fields/image.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/image.html.twig");
    }
}
