<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/date.html.twig */
class __TwigTemplate_dce3bbfd4fbdc17091ef755089f75fd1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_partials/fields/_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/date.html.twig"));

        // line 2
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/_partials/fields/date.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_partials/fields/_base.html.twig", "@bolt/_partials/fields/date.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 4
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 5
        yield "  ";
        // line 6
        yield "  ";
        if ( !array_key_exists("readonly", $context)) {
            // line 7
            yield "      ";
            $context["readonly"] = false;
            // line 8
            yield "  ";
        }
        // line 9
        yield "  ";
        // line 10
        yield "  ";
        if ( !array_key_exists("form", $context)) {
            // line 11
            yield "      ";
            $context["form"] = "";
            // line 12
            yield "  ";
        }
        // line 13
        yield "  ";
        // line 14
        yield "  ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["value"] ?? null), "timestamp", [], "any", true, true, false, 14)) {
            // line 15
            yield "      ";
            $context["value"] = $this->extensions['Bolt\Cache\SelectOptionsCacher']->getDate($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 15, $this->source); })()), "c");
            // line 16
            yield "  ";
        }
        // line 17
        yield "  ";
        // line 18
        yield "  ";
        if ( !array_key_exists("mode", $context)) {
            // line 19
            yield "      ";
            $context["mode"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 19), "mode", [], "any", true, true, false, 19)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 19), "mode", [], "any", false, false, false, 19), false)) : (false));
            // line 20
            yield "  ";
        }
        // line 21
        yield "  ";
        // line 22
        yield "  ";
        if ( !array_key_exists("valueonly", $context)) {
            // line 23
            yield "      ";
            $context["valueonly"] = false;
            // line 24
            yield "  ";
        }
        // line 25
        yield "
  ";
        // line 26
        if ( !(isset($context["valueonly"]) || array_key_exists("valueonly", $context) ? $context["valueonly"] : (function () { throw new RuntimeError('Variable "valueonly" does not exist.', 26, $this->source); })())) {
            // line 27
            yield "      ";
            // line 28
            yield "      ";
            $context["locale"] = Twig\Extension\CoreExtension::first($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 28, $this->source); })()), "user", [], "any", false, false, false, 28), "locale", [], "any", false, false, false, 28), "_"));
            // line 29
            yield "      ";
            if (CoreExtension::inFilter( !(isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 29, $this->source); })()), Twig\Extension\CoreExtension::split($this->env->getCharset(), "ar|at|az|be|bg|bn|bs|cs|cy|da|de|eo|es|et|fa|fi|fo|fr|ga|gr|he|hi|hr|hu|id|is|it|ja|ka|km|ko|kz|lt|lv|mk|mn|ms|my|nl|no|pa|pl|pt|ro|ru|si|sk|sl|sq|sr|sv|th|tr|uk|uz|vn|zh", "|"))) {
                // line 30
                yield "          ";
                $context["locale"] = "en";
                // line 31
                yield "      ";
            }
            // line 32
            yield "  <editor-date
    :value='";
            // line 33
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 33, $this->source); })())), "html", null, true);
            yield "'
    name='";
            // line 34
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 34, $this->source); })()), "html", null, true);
            yield "'
    :readonly='";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 35, $this->source); })())), "html", null, true);
            yield "'
    form='";
            // line 36
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 36, $this->source); })()), "html", null, true);
            yield "'
    mode='";
            // line 37
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["mode"]) || array_key_exists("mode", $context) ? $context["mode"] : (function () { throw new RuntimeError('Variable "mode" does not exist.', 37, $this->source); })()), "html", null, true);
            yield "'
    locale='";
            // line 38
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 38, $this->source); })()), "html", null, true);
            yield "'
    labels='";
            // line 39
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(["toggle" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("editor_date.toggle")]), "html", null, true);
            yield "'
    :required='";
            // line 40
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 40, $this->source); })())), "html", null, true);
            yield "'
    :errormessage='";
            // line 41
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["errormessage"]) || array_key_exists("errormessage", $context) ? $context["errormessage"] : (function () { throw new RuntimeError('Variable "errormessage" does not exist.', 41, $this->source); })())), "html", null, true);
            yield "'
  ></editor-date>
  ";
        } else {
            // line 44
            yield "    ";
            yield $this->extensions['Bolt\Twig\LocaleExtension']->localdate((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 44, $this->source); })()), ((array_key_exists("format", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new RuntimeError('Variable "format" does not exist.', 44, $this->source); })()), null)) : (null)), ((array_key_exists("locale", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["locale"]) || array_key_exists("locale", $context) ? $context["locale"] : (function () { throw new RuntimeError('Variable "locale" does not exist.', 44, $this->source); })()), null)) : (null)));
            yield "
      <small>(";
            // line 45
            yield CoreExtension::callMacro($macros["macro"], "macro_relative_datetime", [(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 45, $this->source); })())], 45, $context, $this->getSourceContext());
            yield ")</small>
  ";
        }
        // line 47
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/date.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  192 => 47,  187 => 45,  182 => 44,  176 => 41,  172 => 40,  168 => 39,  164 => 38,  160 => 37,  156 => 36,  152 => 35,  148 => 34,  144 => 33,  141 => 32,  138 => 31,  135 => 30,  132 => 29,  129 => 28,  127 => 27,  125 => 26,  122 => 25,  119 => 24,  116 => 23,  113 => 22,  111 => 21,  108 => 20,  105 => 19,  102 => 18,  100 => 17,  97 => 16,  94 => 15,  91 => 14,  89 => 13,  86 => 12,  83 => 11,  80 => 10,  78 => 9,  75 => 8,  72 => 7,  69 => 6,  67 => 5,  60 => 4,  52 => 1,  50 => 2,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_partials/fields/_base.html.twig' %}
{% import '@bolt/_macro/_macro.html.twig' as macro %}

{% block field %}
  {# check disabled #}
  {% if readonly is not defined %}
      {% set readonly = false %}
  {% endif %}
  {# Check form attribute #}
  {% if form is not defined %}
      {% set form = '' %}
  {% endif %}
  {# for timestamps, make sure it's formatted correctly #}
  {% if value.timestamp is defined %}
      {% set value = value|date(format='c') %}
  {% endif %}
  {# set mode #}
  {% if mode is not defined %}
      {% set mode = field.definition.mode|default(false) %}
  {% endif %}
  {# check if we only want the value: valueonly #}
  {% if valueonly is not defined %}
      {% set valueonly = false %}
  {% endif %}

  {% if not valueonly %}
      {# Ensure we use only locales bundled with Flatflicker, otherwise default to 'en' #}
      {% set locale = app.user.locale|split('_')|first %}
      {% if not locale in 'ar|at|az|be|bg|bn|bs|cs|cy|da|de|eo|es|et|fa|fi|fo|fr|ga|gr|he|hi|hr|hu|id|is|it|ja|ka|km|ko|kz|lt|lv|mk|mn|ms|my|nl|no|pa|pl|pt|ro|ru|si|sk|sl|sq|sr|sv|th|tr|uk|uz|vn|zh'|split('|') %}
          {% set locale = 'en' %}
      {% endif %}
  <editor-date
    :value='{{ value|json_encode }}'
    name='{{ name }}'
    :readonly='{{ readonly|json_encode }}'
    form='{{ form }}'
    mode='{{ mode }}'
    locale='{{locale}}'
    labels='{{ { 'toggle': 'editor_date.toggle'|trans }|json_encode }}'
    :required='{{ required|json_encode }}'
    :errormessage='{{ errormessage|json_encode }}'
  ></editor-date>
  {% else %}
    {{ value|localdate(format|default(null), locale|default(null)) }}
      <small>({{ macro.relative_datetime(value) }})</small>
  {% endif %}

{% endblock %}

", "@bolt/_partials/fields/date.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/date.html.twig");
    }
}
