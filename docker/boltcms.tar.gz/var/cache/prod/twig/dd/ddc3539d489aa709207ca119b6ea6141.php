<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/select.html.twig */
class __TwigTemplate_13b9ee6827f9ac59fa70e4a92756bd73 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_partials/fields/_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/select.html.twig"));

        // line 10
        if ( !array_key_exists("options", $context)) {
            // line 11
            $context["options"] = $this->extensions['Bolt\Cache\SelectOptionsCacher']->selectOptions((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 11, $this->source); })()));
        }
        // line 14
        if ( !array_key_exists("multiple", $context)) {
            // line 15
            $context["multiple"] = ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 15), "get", ["multiple"], "method", true, true, false, 15)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 15), "get", ["multiple"], "method", false, false, false, 15))) : (""))) ? ("true") : ("false"));
        }
        // line 18
        if ( !array_key_exists("autocomplete", $context)) {
            // line 19
            $context["autocomplete"] = ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 19), "get", ["autocomplete"], "method", true, true, false, 19)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 19), "get", ["autocomplete"], "method", false, false, false, 19))) : (""))) ? ("true") : ("false"));
        }
        // line 22
        if ( !array_key_exists("limit", $context)) {
            // line 23
            $context["limit"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 23), "get", ["limit"], "method", true, true, false, 23)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 23), "get", ["limit"], "method", false, false, false, 23), 2000)) : (2000));
        }
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_partials/fields/_base.html.twig", "@bolt/_partials/fields/select.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 26
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 27
        yield "    <editor-select
        :classname=\"";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(Twig\Extension\CoreExtension::join(["wide-options ", (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 28, $this->source); })())])), "html", null, true);
        yield "\"
        :value=\"";
        // line 29
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 29, $this->source); })())), "html", null, true);
        yield "\"
        :name='";
        // line 30
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 30, $this->source); })())), "html", null, true);
        yield "'
        :id='";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 31, $this->source); })())), "html", null, true);
        yield "'
        :options=\"";
        // line 32
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 32, $this->source); })())), "html", null, true);
        yield "\"
        :optionslimit=\"";
        // line 33
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["limit"]) || array_key_exists("limit", $context) ? $context["limit"] : (function () { throw new RuntimeError('Variable "limit" does not exist.', 33, $this->source); })()), "html", null, true);
        yield "\"
        :form='";
        // line 34
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })())), "html", null, true);
        yield "'
        :multiple=\"";
        // line 35
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["multiple"]) || array_key_exists("multiple", $context) ? $context["multiple"] : (function () { throw new RuntimeError('Variable "multiple" does not exist.', 35, $this->source); })()), "html", null, true);
        yield "\"
        :autocomplete=\"";
        // line 36
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["autocomplete"]) || array_key_exists("autocomplete", $context) ? $context["autocomplete"] : (function () { throw new RuntimeError('Variable "autocomplete" does not exist.', 36, $this->source); })()), "html", null, true);
        yield "\"
        :readonly=\"";
        // line 37
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 37, $this->source); })())), "html", null, true);
        yield "\"
        :errormessage='";
        // line 38
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["errormessage"]) || array_key_exists("errormessage", $context) ? $context["errormessage"] : (function () { throw new RuntimeError('Variable "errormessage" does not exist.', 38, $this->source); })())), "html", null, true);
        yield "'
    ></editor-select>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/select.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  128 => 38,  124 => 37,  120 => 36,  116 => 35,  112 => 34,  108 => 33,  104 => 32,  100 => 31,  96 => 30,  92 => 29,  88 => 28,  85 => 27,  78 => 26,  70 => 1,  67 => 23,  65 => 22,  62 => 19,  60 => 18,  57 => 15,  55 => 14,  52 => 11,  50 => 10,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_partials/fields/_base.html.twig' %}

{# On top of the attributes that get set/defined in `_base.html.twig`,
   The Select fields has three additional attributes:

     - options: The actual options that are available in the select
     - multiple: A boolean to set whether or not we allow multiple selections
 #}

{% if options is not defined %}
    {% set options = select_options(field) %}
{% endif %}

{% if multiple is not defined %}
    {% set multiple = field.definition.get('multiple')|default ? 'true' : 'false' %}
{% endif %}

{% if autocomplete is not defined %}
\t{% set autocomplete = field.definition.get('autocomplete')|default ? 'true' : 'false' %}
{% endif %}

{% if limit is not defined %}
\t{% set limit = field.definition.get('limit')|default(2000) %}
{% endif %}

{% block field %}
    <editor-select
        :classname=\"{{ ['wide-options ', class]|join|json_encode }}\"
        :value=\"{{ value|json_encode }}\"
        :name='{{ name|json_encode }}'
        :id='{{ id|json_encode }}'
        :options=\"{{ options|json_encode }}\"
        :optionslimit=\"{{ limit }}\"
        :form='{{ form|json_encode }}'
        :multiple=\"{{ multiple }}\"
        :autocomplete=\"{{ autocomplete }}\"
        :readonly=\"{{ readonly|json_encode }}\"
        :errormessage='{{ errormessage|json_encode }}'
    ></editor-select>
{% endblock %}
", "@bolt/_partials/fields/select.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/select.html.twig");
    }
}
