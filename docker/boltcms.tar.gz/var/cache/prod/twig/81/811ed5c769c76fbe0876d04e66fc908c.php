<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_base/layout.html.twig */
class __TwigTemplate_e0b42d3a520116c13a391ca1262d19ef extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'html_id' => [$this, 'block_html_id'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'shoulder' => [$this, 'block_shoulder'],
            'topsection' => [$this, 'block_topsection'],
            'vue_id' => [$this, 'block_vue_id'],
            'main' => [$this, 'block_main'],
            'aside' => [$this, 'block_aside'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_base/layout.html.twig"));

        // line 2
        $context["hasAside"] = (( !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(        $this->unwrap()->renderBlock("aside", $context, $blocks)))) ? (true) : (false));
        // line 3
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 4
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 4), "locale", [], "any", true, true, false, 4)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 4), "locale", [], "any", false, false, false, 4))) : ("")), "html", null, true);
        yield "\" ";
        if (        $this->unwrap()->renderBlock("html_id", $context, $blocks)) {
            yield "id=\"";
            yield from $this->unwrap()->yieldBlock('html_id', $context, $blocks);
            yield "\"";
        }
        yield ">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title>";
        // line 10
        yield Twig\Extension\CoreExtension::striptags(        $this->unwrap()->renderBlock("title", $context, $blocks));
        yield "</title>
    ";
        // line 11
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 16
        yield "    ";
        yield Twig\Extension\CoreExtension::include($this->env, $context, "_partials/favicon.html.twig");
        yield "
</head>

<body>
<div class=\"admin\">
    ";
        // line 21
        $context["admin_menu_json"] = json_encode($this->extensions['Bolt\Twig\BackendMenuExtension']->getAdminMenuArray());
        // line 22
        yield "
    <!-- Admin Toolbar -->
    <nav class=\"admin__toolbar\" id=\"toolbar\">
        ";
        // line 25
        $context["user_display_name"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 25), "displayName", [], "any", true, true, false, 25)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 25), "displayName", [], "any", false, false, false, 25), "Unknown user")) : ("Unknown user"));
        // line 26
        yield "
        ";
        // line 27
        if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 27), "avatar", [], "any", true, true, false, 27)) {
            // line 28
            yield "            ";
            $context["user_avatar"] = Twig\Extension\CoreExtension::default($this->extensions['Bolt\Twig\ImageExtension']->thumbnail(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 28, $this->source); })()), "user", [], "any", false, false, false, 28), "avatar", [], "any", false, false, false, 28), 25, 25, "crop"), null);
            // line 29
            yield "        ";
        }
        // line 30
        yield "
        ";
        // line 31
        if (( !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 31), "avatar", [], "any", true, true, false, 31) || (is_string($__internal_compile_0 = (isset($context["user_avatar"]) || array_key_exists("user_avatar", $context) ? $context["user_avatar"] : (function () { throw new RuntimeError('Variable "user_avatar" does not exist.', 31, $this->source); })())) && is_string($__internal_compile_1 = "placeholder.png") && str_ends_with($__internal_compile_0, $__internal_compile_1)))) {
            // line 32
            yield "            ";
            $context["user_avatar"] = null;
            // line 33
            yield "        ";
        }
        // line 34
        yield "
        ";
        // line 36
        yield "        ";
        $context["labels"] = json_encode(["about.bolt_documentation" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("about.bolt_documentation"), "action.view_site" => CoreExtension::getAttribute($this->env, $this->source,         // line 38
(isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 38, $this->source); })()), "get", ["general/sitename"], "method", false, false, false, 38), "general.greeting" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("general.greeting", ["%name%" =>         // line 39
(isset($context["user_display_name"]) || array_key_exists("user_display_name", $context) ? $context["user_display_name"] : (function () { throw new RuntimeError('Variable "user_display_name" does not exist.', 39, $this->source); })())]), "action.logout" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.logout"), "action.stop_impersonating" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.stop_impersonating"), "action.edit_profile" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.edit_profile"), "about.visit_bolt" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("about.visit_bolt"), "listing.button_search" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("general.phrase.search"), "listing.placeholder_search" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("listing.placeholder_search"), "general.label.search" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("general.label.search")]);
        // line 48
        yield "
        ";
        // line 49
        $context["url_paths"] = json_encode(["bolt_dashboard" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_dashboard"), "bolt_logout" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_logout"), "bolt_profile_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_profile_edit")]);
        // line 54
        yield "
        <admin-toolbar
            site-name=\"";
        // line 56
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 56, $this->source); })()), "get", ["general/sitename"], "method", false, false, false, 56), "html", null, true);
        yield "\"
            :menu=\"";
        // line 57
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["admin_menu_json"]) || array_key_exists("admin_menu_json", $context) ? $context["admin_menu_json"] : (function () { throw new RuntimeError('Variable "admin_menu_json" does not exist.', 57, $this->source); })()), "html", null, true);
        yield "\"
            :labels=\"";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["labels"]) || array_key_exists("labels", $context) ? $context["labels"] : (function () { throw new RuntimeError('Variable "labels" does not exist.', 58, $this->source); })()), "html", null, true);
        yield "\"
            :url-paths=\"";
        // line 59
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["url_paths"]) || array_key_exists("url_paths", $context) ? $context["url_paths"] : (function () { throw new RuntimeError('Variable "url_paths" does not exist.', 59, $this->source); })()), "html", null, true);
        yield "\"
            backend-prefix=\"";
        // line 60
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_dashboard");
        yield "\"
            :avatar=\"";
        // line 61
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["user_avatar"]) || array_key_exists("user_avatar", $context) ? $context["user_avatar"] : (function () { throw new RuntimeError('Variable "user_avatar" does not exist.', 61, $this->source); })())), "html", null, true);
        yield "\"
            :is-impersonator=\"";
        // line 62
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_IMPERSONATOR")), "html", null, true);
        yield "\"
            filter-value=\"";
        // line 63
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("filter_value", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["filter_value"]) || array_key_exists("filter_value", $context) ? $context["filter_value"] : (function () { throw new RuntimeError('Variable "filter_value" does not exist.', 63, $this->source); })()), "")) : ("")), "html", null, true);
        yield "\"
        ></admin-toolbar>
    </nav>
    <!-- End Admin Toolbar -->

    <!-- Admin Header -->
    <header class=\"admin__header\">
        <div class=\"admin__header--topbar\">

            <h1 class=\"admin__header--title\">
                ";
        // line 73
        if (        $this->unwrap()->renderBlock("shoulder", $context, $blocks)) {
            // line 74
            yield "                <span class=\"admin__header--title__prefix\">
                    ";
            // line 75
            yield from $this->unwrap()->yieldBlock('shoulder', $context, $blocks);
            yield " »
                </span>
                ";
        }
        // line 78
        yield "                ";
        yield from         $this->unwrap()->yieldBlock("title", $context, $blocks);
        yield "
            </h1>

            <button class=\"admin-sidebar-toggler btn btn-md\">
                <span class=\"admin-sidebar-toggler_icon\"></span>";
        // line 82
        yield $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("admin_sidebar_toggler.toggle");
        yield "
            </button>

        </div>
    </header>
    <!-- End Admin Header -->

    <!-- Admin Sidebar -->
    ";
        // line 90
        $context["labels"] = json_encode(["toggler" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("admin_sidebar.toggler"), "action.new" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.new"), "action.view" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.view")]);
        // line 95
        yield "    <div class=\"admin__sidebar\">
        <div class=\"sidebar sidebar--sticky\" id=\"bolt--sidebar\">
            <admin-sidebar
              :menu=\"";
        // line 98
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["admin_menu_json"]) || array_key_exists("admin_menu_json", $context) ? $context["admin_menu_json"] : (function () { throw new RuntimeError('Variable "admin_menu_json" does not exist.', 98, $this->source); })()), "html", null, true);
        yield "\"
              :version=\"'";
        // line 99
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace(Twig\Extension\CoreExtension::constant("Bolt\\Version::VERSION"), ["alpha" => "α", "beta" => "β"]), "html", null, true);
        yield "'\"
              :about-link=\"";
        // line 100
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_about")), "html", null, true);
        yield "\"
              :labels=\"";
        // line 101
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["labels"]) || array_key_exists("labels", $context) ? $context["labels"] : (function () { throw new RuntimeError('Variable "labels" does not exist.', 101, $this->source); })()), "html", null, true);
        yield "\"
            ></admin-sidebar >
        </div>
    </div>
    <!-- End Admin Sidebar -->

    <!-- Admin Main -->
    <div class=\"admin__body\">

        ";
        // line 110
        yield from $this->unwrap()->yieldBlock('topsection', $context, $blocks);
        // line 114
        yield "
        <div class=\"admin__body--container";
        // line 115
        if ((isset($context["hasAside"]) || array_key_exists("hasAside", $context) ? $context["hasAside"] : (function () { throw new RuntimeError('Variable "hasAside" does not exist.', 115, $this->source); })())) {
            yield " admin__body--container--has-sidebar";
        }
        yield "\"
             id=\"";
        // line 116
        yield from $this->unwrap()->yieldBlock('vue_id', $context, $blocks);
        yield "\">
            <main class=\"admin__body--main\">
                ";
        // line 118
        yield from $this->unwrap()->yieldBlock('main', $context, $blocks);
        // line 120
        yield "            </main>

            ";
        // line 122
        if ((isset($context["hasAside"]) || array_key_exists("hasAside", $context) ? $context["hasAside"] : (function () { throw new RuntimeError('Variable "hasAside" does not exist.', 122, $this->source); })())) {
            // line 123
            yield "            <aside class=\"admin__body--aside\">
                ";
            // line 124
            yield from $this->unwrap()->yieldBlock('aside', $context, $blocks);
            // line 126
            yield "            </aside>
            ";
        }
        // line 128
        yield "        </div>

        <div class=\"admin__notifications\">
            ";
        // line 131
        yield Twig\Extension\CoreExtension::include($this->env, $context, "@bolt/_partials/_flash_messages.html.twig");
        yield "
        </div>
    </div>
    <!-- End Admin Main -->

</div>

";
        // line 138
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 148
        yield "
</body>

</html>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 4
    public function block_html_id($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "html_id"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 11
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        yield "    ";
        $context["theme"] = ("theme-" . ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 12), "backendTheme", [], "any", true, true, false, 12)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, true, false, 12), "backendTheme", [], "any", false, false, false, 12), "default")) : ("default")));
        // line 13
        yield "    ";
        yield $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("bolt");
        yield "
    ";
        // line 14
        yield $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags((isset($context["theme"]) || array_key_exists("theme", $context) ? $context["theme"] : (function () { throw new RuntimeError('Variable "theme" does not exist.', 14, $this->source); })()));
        yield "
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 75
    public function block_shoulder($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "shoulder"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 110
    public function block_topsection($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "topsection"));

        // line 111
        yield "            ";
        // line 113
        yield "        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 116
    public function block_vue_id($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "vue_id"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 118
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 119
        yield "                ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 124
    public function block_aside($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "aside"));

        // line 125
        yield "                ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 138
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 139
        yield "    <script>
        var admin = document.querySelector('.admin');
        var slim = JSON.parse(localStorage.getItem('slim-sidebar'));
        if (slim){
          admin.classList.add('is-slim');
        }
    </script>
    ";
        // line 146
        yield $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("bolt");
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_base/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  427 => 146,  418 => 139,  411 => 138,  403 => 125,  396 => 124,  388 => 119,  381 => 118,  368 => 116,  360 => 113,  358 => 111,  351 => 110,  338 => 75,  328 => 14,  323 => 13,  320 => 12,  313 => 11,  300 => 4,  288 => 148,  286 => 138,  276 => 131,  271 => 128,  267 => 126,  265 => 124,  262 => 123,  260 => 122,  256 => 120,  254 => 118,  249 => 116,  243 => 115,  240 => 114,  238 => 110,  226 => 101,  222 => 100,  218 => 99,  214 => 98,  209 => 95,  207 => 90,  196 => 82,  188 => 78,  182 => 75,  179 => 74,  177 => 73,  164 => 63,  160 => 62,  156 => 61,  152 => 60,  148 => 59,  144 => 58,  140 => 57,  136 => 56,  132 => 54,  130 => 49,  127 => 48,  125 => 39,  124 => 38,  122 => 36,  119 => 34,  116 => 33,  113 => 32,  111 => 31,  108 => 30,  105 => 29,  102 => 28,  100 => 27,  97 => 26,  95 => 25,  90 => 22,  88 => 21,  79 => 16,  77 => 11,  73 => 10,  58 => 4,  55 => 3,  53 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{# Check if aside has value and set hasAside variable #}
{% set hasAside = block('aside')|trim is not empty ? true : false %}
<!DOCTYPE html>
<html lang=\"{{ app.user.locale|default() }}\" {% if block('html_id') %}id=\"{% block html_id %}{% endblock %}\"{% endif %}>

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title>{{ block('title')|striptags|raw }}</title>
    {% block stylesheets %}
    {% set theme = 'theme-' ~ app.user.backendTheme|default('default') %}
    {{ encore_entry_link_tags('bolt') }}
    {{ encore_entry_link_tags(theme) }}
    {% endblock %}
    {{ include('_partials/favicon.html.twig') }}
</head>

<body>
<div class=\"admin\">
    {% set admin_menu_json = admin_menu_array()|json_encode %}

    <!-- Admin Toolbar -->
    <nav class=\"admin__toolbar\" id=\"toolbar\">
        {% set user_display_name = app.user.displayName|default('Unknown user') %}

        {% if app.user.avatar is defined %}
            {% set user_avatar = app.user.avatar|thumbnail(25, 25, 'crop')|default(null) %}
        {% endif %}

        {% if app.user.avatar is not defined or user_avatar ends with 'placeholder.png' %}
            {% set user_avatar = null %}
        {% endif %}

        {# Setting the labels and their localisations that are used in the sidebar-menu. #}
        {% set labels = {
            'about.bolt_documentation': 'about.bolt_documentation'|trans,
            'action.view_site': config.get('general/sitename'),
            'general.greeting': 'general.greeting'|trans({'%name%': user_display_name}),
            'action.logout': 'action.logout'|trans,
            'action.stop_impersonating': 'action.stop_impersonating'|trans,
            'action.edit_profile': 'action.edit_profile'|trans,
            'about.visit_bolt': 'about.visit_bolt'|trans,
            'listing.button_search': 'general.phrase.search'|trans,
            'listing.placeholder_search': 'listing.placeholder_search'|trans,
            'general.label.search': 'general.label.search'|trans,
        }|json_encode %}

        {% set url_paths = {
            'bolt_dashboard': path('bolt_dashboard'),
            'bolt_logout': path('bolt_logout'),
            'bolt_profile_edit': path('bolt_profile_edit'),
        }|json_encode %}

        <admin-toolbar
            site-name=\"{{ config.get('general/sitename') }}\"
            :menu=\"{{ admin_menu_json }}\"
            :labels=\"{{ labels }}\"
            :url-paths=\"{{ url_paths }}\"
            backend-prefix=\"{{ path('bolt_dashboard') }}\"
            :avatar=\"{{ user_avatar|json_encode }}\"
            :is-impersonator=\"{{ is_granted('IS_IMPERSONATOR')|json_encode }}\"
            filter-value=\"{{ filter_value|default('') }}\"
        ></admin-toolbar>
    </nav>
    <!-- End Admin Toolbar -->

    <!-- Admin Header -->
    <header class=\"admin__header\">
        <div class=\"admin__header--topbar\">

            <h1 class=\"admin__header--title\">
                {% if block('shoulder') %}
                <span class=\"admin__header--title__prefix\">
                    {% block shoulder %}{% endblock shoulder %} »
                </span>
                {% endif %}
                {{ block('title') }}
            </h1>

            <button class=\"admin-sidebar-toggler btn btn-md\">
                <span class=\"admin-sidebar-toggler_icon\"></span>{{ 'admin_sidebar_toggler.toggle'|trans|raw }}
            </button>

        </div>
    </header>
    <!-- End Admin Header -->

    <!-- Admin Sidebar -->
    {% set labels = {
        'toggler': 'admin_sidebar.toggler'|trans,
        'action.new': 'action.new'|trans,
        'action.view': 'action.view'|trans,
    }|json_encode %}
    <div class=\"admin__sidebar\">
        <div class=\"sidebar sidebar--sticky\" id=\"bolt--sidebar\">
            <admin-sidebar
              :menu=\"{{ admin_menu_json }}\"
              :version=\"'{{ constant('Bolt\\\\Version::VERSION')|replace({'alpha': 'α', 'beta': 'β'}) }}'\"
              :about-link=\"{{ path('bolt_about')|json_encode }}\"
              :labels=\"{{ labels }}\"
            ></admin-sidebar >
        </div>
    </div>
    <!-- End Admin Sidebar -->

    <!-- Admin Main -->
    <div class=\"admin__body\">

        {% block topsection %}
            {# insert stuff here that should _not_ be part of the
                Vue components, like `{{ dump() }}` statements #}
        {% endblock %}

        <div class=\"admin__body--container{% if hasAside %} admin__body--container--has-sidebar{% endif%}\"
             id=\"{% block vue_id %}{% endblock %}\">
            <main class=\"admin__body--main\">
                {% block main %}
                {% endblock %}
            </main>

            {% if hasAside %}
            <aside class=\"admin__body--aside\">
                {% block aside %}
                {% endblock %}
            </aside>
            {% endif %}
        </div>

        <div class=\"admin__notifications\">
            {{ include('@bolt/_partials/_flash_messages.html.twig') }}
        </div>
    </div>
    <!-- End Admin Main -->

</div>

{% block javascripts %}
    <script>
        var admin = document.querySelector('.admin');
        var slim = JSON.parse(localStorage.getItem('slim-sidebar'));
        if (slim){
          admin.classList.add('is-slim');
        }
    </script>
    {{ encore_entry_script_tags('bolt') }}
{% endblock %}

</body>

</html>
", "@bolt/_base/layout.html.twig", "/var/www/html/vendor/bolt/core/templates/_base/layout.html.twig");
    }
}
