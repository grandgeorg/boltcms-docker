<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_taxonomies.html.twig */
class __TwigTemplate_36137e7140da6073054d419e825ed14f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_taxonomies.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("_macro/_macro.html.twig", "@bolt/content/_taxonomies.html.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 3, $this->source); })()), "definition", [], "any", false, false, false, 3), "taxonomy", [], "any", false, false, false, 3));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["taxonomy"]) {
            // line 4
            yield "
        ";
            // line 5
            $context["definition"] = CoreExtension::getAttribute($this->env, $this->source, (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new RuntimeError('Variable "config" does not exist.', 5, $this->source); })()), "get", [("taxonomies/" . $context["taxonomy"])], "method", false, false, false, 5);
            // line 6
            yield "        ";
            if ((isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 6, $this->source); })())) {
                // line 7
                yield "
            ";
                // line 8
                $context["options"] = $this->extensions['Bolt\Twig\ContentExtension']->taxonomyOptions((isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 8, $this->source); })()));
                // line 9
                yield "            ";
                $context["value"] = $this->extensions['Bolt\Twig\ContentExtension']->taxonomyValues(CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 9, $this->source); })()), "taxonomies", [], "any", false, false, false, 9), (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 9, $this->source); })()));
                // line 10
                yield "
            <div class=\"form-group is-normal\">

                ";
                // line 14
                yield "                ";
                if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, ($context["definition"] ?? null), "prefix", [], "array", true, true, false, 14)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["definition"] ?? null), "prefix", [], "array", false, false, false, 14))) : ("")))) {
                    // line 15
                    yield "                    ";
                    yield CoreExtension::callMacro($macros["macro"], "macro_generatePrefix", [CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 15, $this->source); })()), "prefix", [], "array", false, false, false, 15), $context["taxonomy"]], 15, $context, $this->getSourceContext());
                    yield "
                ";
                }
                // line 17
                yield "
                ";
                // line 18
                if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 18, $this->source); })()), "has_sortorder", [], "any", false, false, false, 18)) {
                    yield "<div class=\"row\"><div class=\"col-9\">";
                }
                // line 19
                yield "                    ";
                yield from                 $this->loadTemplate("@bolt/_partials/fields/_label.html.twig", "@bolt/content/_taxonomies.html.twig", 19)->unwrap()->yield(CoreExtension::merge($context, ["id" => ("taxonomy-" . CoreExtension::getAttribute($this->env, $this->source,                 // line 20
(isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 20, $this->source); })()), "slug", [], "any", false, false, false, 20)), "label" => CoreExtension::getAttribute($this->env, $this->source,                 // line 21
(isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 21, $this->source); })()), "name", [], "any", false, false, false, 21), "required" => CoreExtension::getAttribute($this->env, $this->source,                 // line 22
(isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 22, $this->source); })()), "required", [], "any", false, false, false, 22)]));
                // line 24
                yield "                ";
                if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 24, $this->source); })()), "has_sortorder", [], "any", false, false, false, 24)) {
                    // line 25
                    yield "                </div><div class=\"col-3\">
                   ";
                    // line 26
                    yield from                     $this->loadTemplate("@bolt/_partials/fields/_label.html.twig", "@bolt/content/_taxonomies.html.twig", 26)->unwrap()->yield(CoreExtension::merge($context, ["id" => (("taxonomy-" . CoreExtension::getAttribute($this->env, $this->source,                     // line 27
(isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 27, $this->source); })()), "slug", [], "any", false, false, false, 27)) . "-sortorder"), "label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Order"), "required" => false]));
                    // line 31
                    yield "                </div>
                </div>
                ";
                }
                // line 34
                yield "                ";
                if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 34, $this->source); })()), "has_sortorder", [], "any", false, false, false, 34)) {
                    yield "<div class=\"row\"><div class=\"col-9\">";
                } else {
                    yield "<div>";
                }
                // line 35
                yield "                    <editor-select
                            :value=\"";
                // line 36
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 36, $this->source); })()), 0, [], "any", false, false, false, 36), "html", null, true);
                yield "\"
                            :name=\"'taxonomy[";
                // line 37
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 37, $this->source); })()), "slug", [], "any", false, false, false, 37), "html", null, true);
                yield "]'\"
                            :id=\"'taxonomy-";
                // line 38
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 38, $this->source); })()), "slug", [], "any", false, false, false, 38), "html", null, true);
                yield "'\"
                            :options=\"";
                // line 39
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 39, $this->source); })()), "html", null, true);
                yield "\"
                            :multiple=\"";
                // line 40
                yield ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 40, $this->source); })()), "multiple", [], "any", false, false, false, 40)) ? ("true") : ("false"));
                yield "\"
                            :taggable=\"";
                // line 41
                yield (((CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 41, $this->source); })()), "behaves_like", [], "any", false, false, false, 41) == "tags")) ? ("true") : ("false"));
                yield "\"
                    ></editor-select>
                ";
                // line 43
                if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 43, $this->source); })()), "has_sortorder", [], "any", false, false, false, 43)) {
                    // line 44
                    yield "                    </div>
                    <div class=\"col-3\">
                        <editor-number
                            :id=\"'taxonomy-";
                    // line 47
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 47, $this->source); })()), "slug", [], "any", false, false, false, 47), "html", null, true);
                    yield "-sortorder'\"
                            :name=\"'taxonomy[";
                    // line 48
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 48, $this->source); })()), "slug", [], "any", false, false, false, 48), "html", null, true);
                    yield "-sortorder]'\"
                            value=\"";
                    // line 49
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 49, $this->source); })()), 1, [], "any", false, false, false, 49), "first", [], "method", false, false, false, 49), "html", null, true);
                    yield "\"
                            :step=\"1\"
                        ></editor-number>
                    </div>
                ";
                }
                // line 54
                yield "
                ";
                // line 56
                yield "                ";
                if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, ($context["definition"] ?? null), "postfix", [], "array", true, true, false, 56)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["definition"] ?? null), "postfix", [], "array", false, false, false, 56))) : ("")))) {
                    // line 57
                    yield "                    ";
                    yield CoreExtension::callMacro($macros["macro"], "macro_generatePostfix", [CoreExtension::getAttribute($this->env, $this->source, (isset($context["definition"]) || array_key_exists("definition", $context) ? $context["definition"] : (function () { throw new RuntimeError('Variable "definition" does not exist.', 57, $this->source); })()), "postfix", [], "array", false, false, false, 57), $context["taxonomy"]], 57, $context, $this->getSourceContext());
                    yield "
                ";
                }
                // line 59
                yield "
            </div>

        ";
            }
            // line 63
            yield "
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['taxonomy'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_taxonomies.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  200 => 63,  194 => 59,  188 => 57,  185 => 56,  182 => 54,  174 => 49,  170 => 48,  166 => 47,  161 => 44,  159 => 43,  154 => 41,  150 => 40,  146 => 39,  142 => 38,  138 => 37,  134 => 36,  131 => 35,  124 => 34,  119 => 31,  117 => 27,  116 => 26,  113 => 25,  110 => 24,  108 => 22,  107 => 21,  106 => 20,  104 => 19,  100 => 18,  97 => 17,  91 => 15,  88 => 14,  83 => 10,  80 => 9,  78 => 8,  75 => 7,  72 => 6,  70 => 5,  67 => 4,  50 => 3,  47 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_macro/_macro.html.twig' as macro %}

{% for taxonomy in record.definition.taxonomy %}

        {% set definition = config.get('taxonomies/' ~ taxonomy) %}
        {% if definition %}

            {% set options = taxonomy_options(definition) %}
            {% set value = taxonomy_values(record.taxonomies, definition) %}

            <div class=\"form-group is-normal\">

                {# Print prefix #}
                {% if definition['prefix']|default() is not empty %}
                    {{ macro.generatePrefix(definition['prefix'], taxonomy) }}
                {% endif %}

                {% if definition.has_sortorder %}<div class=\"row\"><div class=\"col-9\">{% endif %}
                    {% include '@bolt/_partials/fields/_label.html.twig' with {
                        'id': 'taxonomy-' ~ definition.slug,
                        'label': definition.name,
                        'required': definition.required
                    } %}
                {% if definition.has_sortorder %}
                </div><div class=\"col-3\">
                   {% include '@bolt/_partials/fields/_label.html.twig' with {
                    'id': 'taxonomy-' ~ definition.slug ~ '-sortorder',
                    'label': 'Order'|trans,
                    'required': false
                    } %}
                </div>
                </div>
                {% endif %}
                {% if definition.has_sortorder %}<div class=\"row\"><div class=\"col-9\">{% else %}<div>{% endif %}
                    <editor-select
                            :value=\"{{ value.0 }}\"
                            :name=\"'taxonomy[{{ definition.slug }}]'\"
                            :id=\"'taxonomy-{{ definition.slug }}'\"
                            :options=\"{{ options }}\"
                            :multiple=\"{{ definition.multiple ? 'true' : 'false' }}\"
                            :taggable=\"{{ (definition.behaves_like == 'tags') ? 'true' : 'false' }}\"
                    ></editor-select>
                {% if definition.has_sortorder %}
                    </div>
                    <div class=\"col-3\">
                        <editor-number
                            :id=\"'taxonomy-{{ definition.slug }}-sortorder'\"
                            :name=\"'taxonomy[{{ definition.slug }}-sortorder]'\"
                            value=\"{{ value.1.first() }}\"
                            :step=\"1\"
                        ></editor-number>
                    </div>
                {% endif %}

                {# Print postfix #}
                {% if definition['postfix']|default() is not empty %}
                    {{ macro.generatePostfix(definition['postfix'], taxonomy) }}
                {% endif %}

            </div>

        {% endif %}

{% endfor %}
", "@bolt/content/_taxonomies.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_taxonomies.html.twig");
    }
}
