<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_fields.html.twig */
class __TwigTemplate_f5412b0d90bc444da0368a34785e460f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_fields.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, (isset($context["groups"]) || array_key_exists("groups", $context) ? $context["groups"] : (function () { throw new RuntimeError('Variable "groups" does not exist.', 1, $this->source); })()), function ($__group__) use ($context, $macros) { $context["group"] = $__group__; return ($context["group"] != "Relations"); }));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 2
            yield "
    <div class=\"tab-pane ";
            // line 3
            if (CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 3)) {
                yield "show active";
            }
            yield "\" id=\"";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\TextExtension']->slug($context["group"]), "html", null, true);
            yield "\" role=\"tabpanel\"
         aria-labelledby=\"";
            // line 4
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\TextExtension']->slug($context["group"]), "html", null, true);
            yield "-tab\">
        ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 5, $this->source); })()), "definition", [], "any", false, false, false, 5), "fields", [], "any", false, false, false, 5), function ($__fielddefinition__) use ($context, $macros) { $context["fielddefinition"] = $__fielddefinition__; return (CoreExtension::getAttribute($this->env, $this->source, $context["fielddefinition"], "group", [], "any", false, false, false, 5) == $context["group"]); }));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["key"] => $context["fielddefinition"]) {
                // line 6
                yield "            ";
                if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 6, $this->source); })()), "hasField", [$context["key"]], "method", false, false, false, 6)) {
                    // line 7
                    yield "                ";
                    $context["field"] = CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 7, $this->source); })()), "getField", [$context["key"]], "method", false, false, false, 7);
                    // line 8
                    yield "                ";
                    if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 8, $this->source); })()), "isTranslatable", [], "any", false, false, false, 8)) {
                        // line 9
                        yield "                    ";
                        // line 10
                        yield "                    ";
                        $context["field"] = $this->extensions['Bolt\Twig\TranslatableExtension']->translate((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 10, $this->source); })()), (isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 10, $this->source); })()));
                        // line 11
                        yield "                ";
                    } else {
                        // line 12
                        yield "                    ";
                        // line 13
                        yield "                    ";
                        $context["field"] = $this->extensions['Bolt\Twig\TranslatableExtension']->translate((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "defaultLocale", [], "any", false, false, false, 13));
                        // line 14
                        yield "                ";
                    }
                    // line 15
                    yield "            ";
                } else {
                    // line 16
                    yield "                ";
                    $context["field"] = $this->extensions['Bolt\Cache\SelectOptionsCacher']->fieldFactory($context["key"], $context["fielddefinition"]);
                    // line 17
                    yield "            ";
                }
                // line 18
                yield "
            ";
                // line 19
                if ( !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 19, $this->source); })()), "definition", [], "any", false, false, false, 19), "hidden", [], "any", false, false, false, 19)) {
                    // line 20
                    yield "                ";
                    // line 22
                    yield "                ";
                    yield from                     $this->loadTemplate([((CoreExtension::getAttribute($this->env, $this->source,                     // line 23
$context["fielddefinition"], "template", [], "any", true, true, false, 23)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["fielddefinition"], "template", [], "any", false, false, false, 23), "")) : ("")), (("@bolt/_partials/fields/" . CoreExtension::getAttribute($this->env, $this->source,                     // line 24
$context["fielddefinition"], "type", [], "any", false, false, false, 24)) . ".html.twig"), (((("@" . CoreExtension::getAttribute($this->env, $this->source,                     // line 25
$context["fielddefinition"], "type", [], "any", false, false, false, 25)) . "/") . CoreExtension::getAttribute($this->env, $this->source, $context["fielddefinition"], "type", [], "any", false, false, false, 25)) . ".html.twig"), "@bolt/_partials/fields/generic.html.twig"], "@bolt/content/_fields.html.twig", 22)->unwrap()->yield(CoreExtension::merge($context, ["field" =>                     // line 27
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 27, $this->source); })())]));
                    // line 28
                    yield "            ";
                }
                // line 29
                yield "
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['key'], $context['fielddefinition'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            yield "    </div>
";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_fields.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  160 => 31,  145 => 29,  142 => 28,  140 => 27,  139 => 25,  138 => 24,  137 => 23,  135 => 22,  133 => 20,  131 => 19,  128 => 18,  125 => 17,  122 => 16,  119 => 15,  116 => 14,  113 => 13,  111 => 12,  108 => 11,  105 => 10,  103 => 9,  100 => 8,  97 => 7,  94 => 6,  77 => 5,  73 => 4,  65 => 3,  62 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% for group in groups|filter(group => group != 'Relations') %}

    <div class=\"tab-pane {% if loop.first %}show active{% endif %}\" id=\"{{ group|slug }}\" role=\"tabpanel\"
         aria-labelledby=\"{{ group|slug }}-tab\">
        {% for key, fielddefinition in record.definition.fields|filter(fielddefinition => fielddefinition.group == group) %}
            {% if record.hasField(key) %}
                {% set field = record.getField(key) %}
                {% if field.isTranslatable %}
                    {# If the field is translatable, we want the translated value in the current locale #}
                    {% set field = field|translate(currentlocale) %}
                {% else %}
                    {# Otherwise, we want the value in the default locale, explicitly in case it is something else #}
                    {% set field = field|translate(field.defaultLocale) %}
                {% endif %}
            {% else %}
                {% set field = field_factory(key, fielddefinition) %}
            {% endif %}

            {% if not field.definition.hidden %}
                {# Three-step include: first try a 'built-in' fieldtype, then a field added by
                an Extension, and fall back to 'generic' field type #}
                {% include [
                    fielddefinition.template|default(''),
                    '@bolt/_partials/fields/' ~ fielddefinition.type ~ '.html.twig',
                    '@' ~ fielddefinition.type ~ '/' ~ fielddefinition.type ~ '.html.twig',
                    '@bolt/_partials/fields/generic.html.twig'
                    ] with { 'field' : field } %}
            {% endif %}

        {% endfor %}
    </div>
{% endfor %}
", "@bolt/content/_fields.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_fields.html.twig");
    }
}
