<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/_base.html.twig */
class __TwigTemplate_7a28d2bb53ac1ba93bc2556ed9cff595 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'label' => [$this, 'block_label'],
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/_base.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("_macro/_macro.html.twig", "@bolt/_partials/fields/_base.html.twig", 1)->unwrap();
        // line 3
        $___internal_parse_0_ = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 24
            yield "
";
            // line 26
            $context["type"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "type", [], "any", true, true, false, 26)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "type", [], "any", false, false, false, 26))) : (""));
            // line 27
            yield "
";
            // line 29
            if ( !((array_key_exists("required", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 29, $this->source); })()))) : (""))) {
                // line 30
                yield "    ";
                $context["required"] = ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 30), "required", [], "any", true, true, false, 30)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 30), "required", [], "any", false, false, false, 30))) : (""))) ? (true) : (false));
            }
            // line 32
            yield "
";
            // line 34
            if ( !array_key_exists("readonly", $context)) {
                // line 35
                yield "    ";
                $context["readonly"] = ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 35), "readonly", [], "any", true, true, false, 35)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 35), "readonly", [], "any", false, false, false, 35))) : (""))) ? (true) : (false));
            }
            // line 37
            yield "
";
            // line 39
            $context["errormessage"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 39), "get", ["error"], "method", true, true, false, 39)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 39), "get", ["error"], "method", false, false, false, 39), false)) : (false));
            // line 40
            yield "
";
            // line 42
            $context["pattern"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 42), "get", ["pattern"], "method", true, true, false, 42)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 42), "get", ["pattern"], "method", false, false, false, 42), false)) : (false));
            // line 43
            yield "
";
            // line 45
            $context["maxlength"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 45), "get", ["maxlength"], "method", true, true, false, 45)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 45), "get", ["maxlength"], "method", false, false, false, 45), "")) : (""));
            // line 46
            yield "
";
            // line 47
            $context["type_collection"] = CoreExtension::inFilter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 47, $this->source); })()), ["collection"]);
            // line 48
            $context["type_card"] = CoreExtension::inFilter((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 48, $this->source); })()), ["imagelist", "filelist", "set"]);
            // line 49
            yield "
";
            // line 51
            if ( !((array_key_exists("variant", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 51, $this->source); })()))) : (""))) {
                // line 52
                yield "    ";
                $context["variant"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 52), "variant", [], "any", true, true, false, 52)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 52), "variant", [], "any", false, false, false, 52), "normal")) : ("normal"));
            }
            // line 54
            yield "
";
            // line 56
            if ( !((array_key_exists("name", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 56, $this->source); })()))) : (""))) {
                // line 57
                yield "    ";
                $context["name"] = (("fields[" . ((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", true, true, false, 57)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 57), "unnamed")) : ("unnamed"))) . "]");
            }
            // line 59
            yield "
";
            // line 61
            if ( !((array_key_exists("separator", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["separator"]) || array_key_exists("separator", $context) ? $context["separator"] : (function () { throw new RuntimeError('Variable "separator" does not exist.', 61, $this->source); })()))) : (""))) {
                // line 62
                yield "    ";
                if (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 62), "separator", [], "any", true, true, false, 62)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 62), "separator", [], "any", false, false, false, 62))) : (""))) {
                    // line 63
                    yield "        ";
                    $context["separator"] = "<hr>";
                    // line 64
                    yield "    ";
                } else {
                    // line 65
                    yield "        ";
                    $context["separator"] = "";
                    // line 66
                    yield "    ";
                }
            }
            // line 68
            yield "
";
            // line 70
            if ( !((array_key_exists("id", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 70, $this->source); })()))) : (""))) {
                // line 71
                yield "    ";
                $context["id"] = ("field-" . Twig\Extension\CoreExtension::default(((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", true, true, false, 71)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 71), (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 71, $this->source); })()))) : ((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 71, $this->source); })()))), "unnamed"));
            }
            // line 73
            yield "
";
            // line 75
            if ( !((array_key_exists("form", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 75, $this->source); })()))) : (""))) {
                // line 76
                yield "    ";
                $context["form"] = "editcontent";
            }
            // line 78
            yield "
";
            // line 80
            if (array_key_exists("field", $context)) {
                // line 81
                yield "    ";
                CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 81, $this->source); })()), "setUseDefaultLocale", [false], "method", false, false, false, 81);
            }
            // line 83
            yield "
";
            // line 85
            if ( !((array_key_exists("value", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 85, $this->source); })()))) : (""))) {
                // line 86
                yield "    ";
                $context["value"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "value", [], "any", true, true, false, 86)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "value", [], "any", false, false, false, 86), "")) : (""));
                // line 87
                yield "    ";
                if (((is_iterable((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 87, $this->source); })())) && ($this->extensions['Bolt\Cache\SelectOptionsCacher']->getType((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 87, $this->source); })())) != "select")) && ($this->extensions['Bolt\Cache\SelectOptionsCacher']->getType((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 87, $this->source); })())) != "collection"))) {
                    // line 88
                    yield "        ";
                    $context["value"] = Twig\Extension\CoreExtension::first($this->env->getCharset(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 88, $this->source); })()));
                    // line 89
                    yield "    ";
                }
                // line 90
                yield "
    ";
                // line 92
                yield "    ";
                if ((true === \is_string((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 92, $this->source); })())))) {
                    // line 93
                    yield "        ";
                    $context["value"] = Twig\Extension\CoreExtension::replace((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 93, $this->source); })()), ["{{" => "{​{", "}}" => "}​}"]);
                    // line 94
                    yield "    ";
                }
                // line 95
                yield "
    ";
                // line 97
                yield "    ";
                if (( !((CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "id", [], "any", true, true, false, 97)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "id", [], "any", false, false, false, 97))) : ("")) &&  !(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 97, $this->source); })()))) {
                    // line 98
                    yield "        ";
                    $context["value"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 98, $this->source); })()), "request", [], "any", false, false, false, 98), "get", [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 98, $this->source); })())], "method", false, false, false, 98);
                    // line 99
                    yield "    ";
                }
            }
            // line 101
            yield "
";
            // line 103
            if ( !((array_key_exists("class", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 103, $this->source); })()))) : (""))) {
                // line 104
                yield "    ";
                $context["class"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 104), "class", [], "any", true, true, false, 104)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 104), "class", [], "any", false, false, false, 104))) : (""));
            }
            // line 106
            yield "
";
            // line 108
            if ( !((array_key_exists("label", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 108, $this->source); })()))) : (""))) {
                // line 109
                yield "    ";
                $context["label"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 109), "label", [], "any", true, true, false, 109)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 109), "label", [], "any", false, false, false, 109), $this->extensions['Bolt\Twig\TextExtension']->ucwords(((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", true, true, false, 109)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 109), "unnamed")) : ("unnamed"))))) : ($this->extensions['Bolt\Twig\TextExtension']->ucwords(((CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", true, true, false, 109)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 109), "unnamed")) : ("unnamed")))));
            }
            // line 111
            yield "
";
            // line 113
            if ( !((array_key_exists("info", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["info"]) || array_key_exists("info", $context) ? $context["info"] : (function () { throw new RuntimeError('Variable "info" does not exist.', 113, $this->source); })()))) : (""))) {
                // line 114
                yield "    ";
                $context["info"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 114), "info", [], "any", true, true, false, 114)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 114), "info", [], "any", false, false, false, 114))) : (""));
            }
            // line 116
            yield "
";
            // line 118
            if ( !((array_key_exists("placeholder", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["placeholder"]) || array_key_exists("placeholder", $context) ? $context["placeholder"] : (function () { throw new RuntimeError('Variable "placeholder" does not exist.', 118, $this->source); })()))) : (""))) {
                // line 119
                yield "    ";
                $context["placeholder"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 119), "placeholder", [], "any", true, true, false, 119)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 119), "placeholder", [], "any", false, false, false, 119), "")) : (""));
            }
            // line 121
            yield "
";
            // line 123
            $context["localize"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 123), "localize", [], "any", true, true, false, 123)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 123), "localize", [], "any", false, false, false, 123))) : (""));
            return; yield '';
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 3
        yield Twig\Extension\CoreExtension::spaceless($___internal_parse_0_);
        // line 127
        yield "<!-- field \"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 127, $this->source); })()), "html", null, true);
        yield "\" (type: ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new RuntimeError('Variable "type" does not exist.', 127, $this->source); })()), "html", null, true);
        if (((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 127, $this->source); })()) != "normal")) {
            yield ", variant: ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 127, $this->source); })()), "html", null, true);
        }
        yield ") -->
<div
    class=\"form-group ";
        // line 129
        yield (((isset($context["type_card"]) || array_key_exists("type_card", $context) ? $context["type_card"] : (function () { throw new RuntimeError('Variable "type_card" does not exist.', 129, $this->source); })())) ? ("form-card") : (""));
        yield " ";
        yield (((isset($context["type_collection"]) || array_key_exists("type_collection", $context) ? $context["type_collection"] : (function () { throw new RuntimeError('Variable "type_collection" does not exist.', 129, $this->source); })())) ? ("form-collection") : (""));
        yield " ";
        yield ((((array_key_exists("in_compound", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["in_compound"]) || array_key_exists("in_compound", $context) ? $context["in_compound"] : (function () { throw new RuntimeError('Variable "in_compound" does not exist.', 129, $this->source); })()))) : (""))) ? ("in-compound") : (""));
        yield " is-";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 129, $this->source); })()), "html", null, true);
        yield "\"
    id=\"field--";
        // line 130
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 130, $this->source); })()), "html", null, true);
        yield "\"
>

";
        // line 134
        if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 134), "prefix", [], "array", true, true, false, 134)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 134), "prefix", [], "array", false, false, false, 134))) : ("")))) {
            // line 135
            yield "    ";
            yield CoreExtension::callMacro($macros["macro"], "macro_generatePrefix", [((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 135), "prefix", [], "array", true, true, false, 135)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 135), "prefix", [], "array", false, false, false, 135))) : ("")), (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 135, $this->source); })())], 135, $context, $this->getSourceContext());
            yield "
";
        }
        // line 137
        yield "
";
        // line 138
        if (((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 138, $this->source); })()) == "inline")) {
            yield "<div class=\"row\"><div class=\"col-3\">";
        }
        // line 139
        yield "
";
        // line 140
        yield from $this->unwrap()->yieldBlock('label', $context, $blocks);
        // line 143
        yield "
";
        // line 144
        if (((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 144, $this->source); })()) == "inline")) {
            yield "</div><div class=\"col-9\">";
        }
        // line 145
        yield "
";
        // line 146
        yield from $this->unwrap()->yieldBlock('field', $context, $blocks);
        // line 149
        if (array_key_exists("include_id", $context)) {
            // line 150
            yield "    ";
            yield from             $this->loadTemplate("@bolt/_partials/fields/_hidden_id_field.html.twig", "@bolt/_partials/fields/_base.html.twig", 150)->unwrap()->yield($context);
        }
        // line 152
        yield "
";
        // line 153
        if (((isset($context["variant"]) || array_key_exists("variant", $context) ? $context["variant"] : (function () { throw new RuntimeError('Variable "variant" does not exist.', 153, $this->source); })()) == "inline")) {
            yield "</div></div>";
        }
        // line 154
        yield "
";
        // line 156
        if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 156), "postfix", [], "array", true, true, false, 156)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 156), "postfix", [], "array", false, false, false, 156))) : ("")))) {
            // line 157
            yield "    ";
            yield CoreExtension::callMacro($macros["macro"], "macro_generatePostfix", [((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 157), "postfix", [], "array", true, true, false, 157)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "definition", [], "any", false, true, false, 157), "postfix", [], "array", false, false, false, 157))) : ("")), (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 157, $this->source); })())], 157, $context, $this->getSourceContext());
            yield "
";
        }
        // line 159
        yield "
";
        // line 160
        yield (isset($context["separator"]) || array_key_exists("separator", $context) ? $context["separator"] : (function () { throw new RuntimeError('Variable "separator" does not exist.', 160, $this->source); })());
        yield "
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 140
    public function block_label($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "label"));

        // line 141
        yield "    ";
        yield from         $this->loadTemplate("@bolt/_partials/fields/_label.html.twig", "@bolt/_partials/fields/_base.html.twig", 141)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 146
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 147
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/_base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  371 => 147,  364 => 146,  355 => 141,  348 => 140,  336 => 160,  333 => 159,  327 => 157,  325 => 156,  322 => 154,  318 => 153,  315 => 152,  311 => 150,  309 => 149,  307 => 146,  304 => 145,  300 => 144,  297 => 143,  295 => 140,  292 => 139,  288 => 138,  285 => 137,  279 => 135,  277 => 134,  271 => 130,  261 => 129,  249 => 127,  247 => 3,  243 => 123,  240 => 121,  236 => 119,  234 => 118,  231 => 116,  227 => 114,  225 => 113,  222 => 111,  218 => 109,  216 => 108,  213 => 106,  209 => 104,  207 => 103,  204 => 101,  200 => 99,  197 => 98,  194 => 97,  191 => 95,  188 => 94,  185 => 93,  182 => 92,  179 => 90,  176 => 89,  173 => 88,  170 => 87,  167 => 86,  165 => 85,  162 => 83,  158 => 81,  156 => 80,  153 => 78,  149 => 76,  147 => 75,  144 => 73,  140 => 71,  138 => 70,  135 => 68,  131 => 66,  128 => 65,  125 => 64,  122 => 63,  119 => 62,  117 => 61,  114 => 59,  110 => 57,  108 => 56,  105 => 54,  101 => 52,  99 => 51,  96 => 49,  94 => 48,  92 => 47,  89 => 46,  87 => 45,  84 => 43,  82 => 42,  79 => 40,  77 => 39,  74 => 37,  70 => 35,  68 => 34,  65 => 32,  61 => 30,  59 => 29,  56 => 27,  54 => 26,  51 => 24,  49 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_macro/_macro.html.twig' as macro %}

{%- apply spaceless -%}

{# This template fragment is used to \"extend\" the different fields, used in
   Bolt's backend. Most of the values get passed in, either through a `Field`,
   or otherwise through parameters.

   The used variables are: (\"P\" is parameter, \"F\" comes from a `Field`)

   - type: P - The type of the field
   - variant: F - the \"variant\" of the field, if applicable
   - name: P+F - The `name` attribute of the <input> field
   - id: P+F - The `id` attribute of the <input> field
   - class: P+F - The `class` attribute of the <input> field
   - form: P - The `form` attribute of the <input>, defaults to 'editcontent'
   - value: P+F - The default value if the <input> field
   - label: P+F - Label used as visible anchor to the <input> field
   - placeholder: P+F - Placeholder text to use in the <input>
   - prefix: P+F - Short text to display as a prefix before a field
   - postfix: P+F - Short text to display as a postfix after a field

#}

{# Set type #}
{% set type = field.type|default %}

{# Set required #}
{% if not required|default %}
    {% set required = (field.definition.required|default) ? true : false %}
{% endif %}

{# Set readonly based on field definition if not set already #}
{% if readonly is not defined %}
    {% set readonly = (field.definition.readonly|default) ? true : false %}
{% endif %}

{# Set error validation message #}
{% set errormessage = field.definition.get('error')|default(false) %}

{# Set pattern #}
{% set pattern = field.definition.get('pattern')|default(false) %}

{# Set maxlength #}
{% set maxlength = field.definition.get('maxlength')|default('') %}

{% set type_collection = (type in ['collection']) %}
{% set type_card = (type in ['imagelist', 'filelist', 'set']) %}

{# Set variant #}
{% if not variant|default %}
    {% set variant = field.definition.variant|default('normal') %}
{% endif %}

{# Set the name #}
{% if not name|default %}
    {%  set name = 'fields[' ~ field.name|default('unnamed') ~ ']' %}
{% endif %}

{# Set the separator #}
{% if not separator|default %}
    {% if field.definition.separator|default %}
        {% set separator = \"<hr>\" %}
    {% else %}
        {% set separator = \"\" %}
    {% endif %}
{% endif %}

{# Set the id #}
{% if not id|default %}
    {% set id = 'field-' ~ field.name|default(name)|default('unnamed') %}
{% endif %}

{# Set the form #}
{% if not form|default %}
    {% set form = 'editcontent' %}
{% endif %}

{# Do not fallback to a default value in the Editor. #}
{% if field is defined %}
    {% do field.setUseDefaultLocale(false)%}
{% endif %}

{# Set the value #}
{% if not value|default %}
    {% set value = field.value|default('') %}
    {% if value is iterable and field|type != \"select\" and field|type != \"collection\" %}
        {% set value = value|first %}
    {% endif %}

    {# We're adding zero width spaces (`\\xE2\\x80\\x8B`) in `{{` and `}}`, to ensure Vue doesn't get its grubby paws on it. #}
    {% if value is string %}
        {% set value = value|replace({'{{': \"{\\xE2\\x80\\x8B{\", '}}': \"}\\xE2\\x80\\x8B}\" }) %}
    {% endif %}

    {# Set a default, for example when an extension requests `/bolt/new/entries?field-title=Foo+Bar #}
    {% if not record.id|default() and not value %}
        {% set value = app.request.get(id) %}
    {% endif %}
{% endif %}

{# Set the class #}
{% if not class|default %}
    {% set class = field.definition.class|default %}
{% endif %}

{# Set the label #}
{% if not label|default %}
    {% set label = field.definition.label|default(field.name|default('unnamed')|ucwords) %}
{% endif %}

{# Set the info #}
{% if not info|default %}
    {% set info = field.definition.info|default %}
{% endif %}

{# Set the placeholder #}
{% if not placeholder|default %}
    {% set placeholder = field.definition.placeholder|default('') %}
{% endif %}

{# Set the locale #}
{% set localize = field.definition.localize|default %}

{%- endapply -%}

<!-- field \"{{ label }}\" (type: {{ type }}{% if variant != 'normal' %}, variant: {{ variant }}{% endif %}) -->
<div
    class=\"form-group {{ type_card ? 'form-card' }} {{ type_collection ? 'form-collection' }} {{ in_compound|default ? 'in-compound'}} is-{{ variant }}\"
    id=\"field--{{ id }}\"
>

{# Print prefix #}
{% if field.definition['prefix']|default() is not empty %}
    {{ macro.generatePrefix(field.definition['prefix']|default(), id) }}
{% endif %}

{% if variant == 'inline' %}<div class=\"row\"><div class=\"col-3\">{% endif %}

{% block label %}
    {% include '@bolt/_partials/fields/_label.html.twig' %}
{% endblock %}

{% if variant == 'inline' %}</div><div class=\"col-9\">{% endif %}

{% block field %}

{% endblock %}
{% if include_id is defined %}
    {% include '@bolt/_partials/fields/_hidden_id_field.html.twig' %}
{% endif %}

{% if variant == 'inline' %}</div></div>{% endif %}

{# Print postfix #}
{% if field.definition['postfix']|default() is not empty %}
    {{ macro.generatePostfix(field.definition['postfix']|default(), id) }}
{% endif %}

{{ separator|raw }}
</div>

", "@bolt/_partials/fields/_base.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/_base.html.twig");
    }
}
