<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/edit.html.twig */
class __TwigTemplate_62243106daf9373ca6e38eeaa61feb9b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'shoulder' => [$this, 'block_shoulder'],
            'title' => [$this, 'block_title'],
            'vue_id' => [$this, 'block_vue_id'],
            'topsection' => [$this, 'block_topsection'],
            'main' => [$this, 'block_main'],
            'aside' => [$this, 'block_aside'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_base/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/edit.html.twig"));

        // line 2
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/content/edit.html.twig", 2)->unwrap();
        // line 4
        $context["alltypes"] = ["select"];
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 5, $this->source); })()), "definition", [], "any", false, false, false, 5), "fields", [], "any", false, false, false, 5));
        foreach ($context['_seq'] as $context["key"] => $context["fielddefinition"]) {
            // line 6
            $context["alltypes"] = Twig\Extension\CoreExtension::merge((isset($context["alltypes"]) || array_key_exists("alltypes", $context) ? $context["alltypes"] : (function () { throw new RuntimeError('Variable "alltypes" does not exist.', 6, $this->source); })()), [CoreExtension::getAttribute($this->env, $this->source, $context["fielddefinition"], "type", [], "any", false, false, false, 6)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['fielddefinition'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 10
        if ($this->extensions['Bolt\Twig\ContentExtension']->getTitle((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 10, $this->source); })()), (isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 10, $this->source); })()))) {
            // line 11
            $context["displayTitle"] = $this->extensions['Bolt\Twig\ContentExtension']->getTitle((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 11, $this->source); })()), (isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 11, $this->source); })()));
        } elseif (CoreExtension::getAttribute($this->env, $this->source,         // line 12
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 12, $this->source); })()), "id", [], "any", false, false, false, 12)) {
            // line 13
            $context["displayTitle"] = $this->extensions['Bolt\Twig\LocaleExtension']->translate("caption.untitled_contenttype", ["%contenttype%" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 13, $this->source); })()), "definition", [], "any", false, false, false, 13), "singular_name", [], "any", false, false, false, 13)]);
        } elseif (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 14
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 14, $this->source); })()), "definition", [], "any", false, false, false, 14), "singleton", [], "any", false, false, false, 14)) {
            // line 15
            $context["displayTitle"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 15, $this->source); })()), "definition", [], "any", false, false, false, 15), "singular_name", [], "any", false, false, false, 15);
        } else {
            // line 17
            $context["displayTitle"] = $this->extensions['Bolt\Twig\LocaleExtension']->translate("caption.new_contenttype", ["%contenttype%" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 17, $this->source); })()), "definition", [], "any", false, false, false, 17), "singular_name", [], "any", false, false, false, 17)]);
        }
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_base/layout.html.twig", "@bolt/content/edit.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 21
    public function block_shoulder($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "shoulder"));

        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 22, $this->source); })()), "request", [], "any", false, false, false, 22), "get", ["_route"], "method", false, false, false, 22) == "bolt_content_duplicate")) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("caption.duplicate")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("caption.edit"))), "html", null, true);
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 22, $this->source); })()), "definition", [], "any", false, false, false, 22), "singular_name", [], "any", false, false, false, 22), "html", null, true);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 25
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 26
        yield "    ";
        yield $this->extensions['Bolt\Twig\ContentExtension']->icon((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 26, $this->source); })()));
        yield "
    ";
        // line 27
        yield $this->extensions['Bolt\Twig\ContentExtension']->getExcerpt((isset($context["displayTitle"]) || array_key_exists("displayTitle", $context) ? $context["displayTitle"] : (function () { throw new RuntimeError('Variable "displayTitle" does not exist.', 27, $this->source); })()), 50);
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_vue_id($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "vue_id"));

        yield "editor";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 33
    public function block_topsection($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "topsection"));

        // line 34
        yield "
";
        // line 36
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 39
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 40
        yield "
    ";
        // line 41
        if (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "definition", [], "any", false, true, false, 41), "virtual", [], "any", true, true, false, 41)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "definition", [], "any", false, true, false, 41), "virtual", [], "any", false, false, false, 41), false)) : (false))) {
            // line 42
            yield "        <div class=\"alert alert-danger\" role=\"alert\">
            ";
            // line 43
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("content.edit_missing_definition", ["%contenttype%" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 43, $this->source); })()), "definition", [], "any", false, false, false, 43), "name", [], "any", false, false, false, 43)]), "html", null, true);
            yield "
        </div>
    ";
        }
        // line 46
        yield "
    ";
        // line 47
        if (array_key_exists("errors", $context)) {
            // line 48
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable((isset($context["errors"]) || array_key_exists("errors", $context) ? $context["errors"] : (function () { throw new RuntimeError('Variable "errors" does not exist.', 48, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 49
                yield "            <div class=\"alert alert-danger\" role=\"alert\">
                ";
                // line 50
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["error"], "propertyPath", [], "any", false, false, false, 50), "html", null, true);
                yield ": ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 50), "html", null, true);
                yield "
            </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 53
            yield "    ";
        }
        // line 54
        yield "
    <form method=\"post\" id=\"editcontent\">
        ";
        // line 56
        yield $this->extensions['Bolt\Twig\WidgetExtension']->renderWidgetsForTarget("editcontent_below_header");
        yield "

        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 58
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("editrecord"), "html", null, true);
        yield "\">
        <input type=\"hidden\" name=\"_edit_locale\" value=\"";
        // line 59
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 59, $this->source); })()), "html", null, true);
        yield "\">
        ";
        // line 62
        yield "        <input type=\"submit\" form=\"editcontent\" style=\"display: none;\" value=\"__('action.save')\">

        ";
        // line 64
        $context["groups"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "definition", [], "any", false, true, false, 64), "groups", [], "any", true, true, false, 64)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "definition", [], "any", false, true, false, 64), "groups", [], "any", false, false, false, 64), [])) : ([]));
        // line 65
        yield "
        ";
        // line 66
        yield from         $this->loadTemplate("@bolt/content/_tabs.html.twig", "@bolt/content/edit.html.twig", 66)->unwrap()->yield($context);
        // line 67
        yield "
        <div class=\"tab-content\" id=\"nav-tabContent\">

            ";
        // line 70
        yield from         $this->loadTemplate("@bolt/content/_fields.html.twig", "@bolt/content/edit.html.twig", 70)->unwrap()->yield($context);
        // line 71
        yield "
            ";
        // line 74
        yield "            <div class=\"tab-pane\" id=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\TextExtension']->slug("Relations"), "html", null, true);
        yield "\" role=\"tabpanel\" aria-labelledby=\"relations-tab\">

                ";
        // line 76
        yield from         $this->loadTemplate("@bolt/content/_relationships.html.twig", "@bolt/content/edit.html.twig", 76)->unwrap()->yield($context);
        // line 77
        yield "
                ";
        // line 78
        yield from         $this->loadTemplate("@bolt/content/_taxonomies.html.twig", "@bolt/content/edit.html.twig", 78)->unwrap()->yield($context);
        // line 79
        yield "            </div>

        </div>
        ";
        // line 82
        yield $this->extensions['Bolt\Twig\WidgetExtension']->renderWidgetsForTarget("editcontent_bottom");
        yield "

        <hr>
        ";
        // line 85
        yield from         $this->loadTemplate("@bolt/content/_buttons.html.twig", "@bolt/content/edit.html.twig", 85)->unwrap()->yield(CoreExtension::merge($context, ["hide_on_mobile" => true]));
        // line 86
        yield "
    </form>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 91
    public function block_aside($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "aside"));

        // line 92
        yield "    <div id=\"metadata\">
        <form class=\"ui form\">
            ";
        // line 94
        yield $this->extensions['Bolt\Twig\WidgetExtension']->renderWidgetsForTarget("editcontent_aside_top");
        yield "

            <div class=\"card mb-3\">
                <div class=\"card-header\">
                    ";
        // line 98
        yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["star"], 98, $context, $this->getSourceContext());
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("title.primary_actions"), "html", null, true);
        yield "
                </div>
                <div class=\"card-body\">
                    ";
        // line 101
        yield from         $this->loadTemplate("@bolt/content/_buttons.html.twig", "@bolt/content/edit.html.twig", 101)->unwrap()->yield(CoreExtension::merge($context, ["status" => true]));
        // line 102
        yield "                </div>
            </div>

            ";
        // line 105
        yield from         $this->loadTemplate("@bolt/content/_localeswitcher.html.twig", "@bolt/content/edit.html.twig", 105)->unwrap()->yield($context);
        // line 106
        yield "            ";
        yield $this->extensions['Bolt\Twig\WidgetExtension']->renderWidgetsForTarget("editcontent_aside_middle");
        yield "

            <div class=\"card\">
                <div class=\"card-header\">
                    ";
        // line 110
        yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["sliders-h"], 110, $context, $this->getSourceContext());
        yield " ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("title.options"), "html", null, true);
        yield "
                </div>
                <div class=\"card-body\">
                    ";
        // line 113
        yield from         $this->loadTemplate("@bolt/content/_fields_aside.html.twig", "@bolt/content/edit.html.twig", 113)->unwrap()->yield($context);
        // line 114
        yield "                    ";
        yield from         $this->loadTemplate("@bolt/content/_fields_aside_summary.html.twig", "@bolt/content/edit.html.twig", 114)->unwrap()->yield($context);
        // line 115
        yield "                </div>
            </div>

            ";
        // line 118
        yield $this->extensions['Bolt\Twig\WidgetExtension']->renderWidgetsForTarget("editcontent_aside_bottom");
        yield "
        </form>
    </div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  349 => 118,  344 => 115,  341 => 114,  339 => 113,  331 => 110,  323 => 106,  321 => 105,  316 => 102,  314 => 101,  306 => 98,  299 => 94,  295 => 92,  288 => 91,  277 => 86,  275 => 85,  269 => 82,  264 => 79,  262 => 78,  259 => 77,  257 => 76,  251 => 74,  248 => 71,  246 => 70,  241 => 67,  239 => 66,  236 => 65,  234 => 64,  230 => 62,  226 => 59,  222 => 58,  217 => 56,  213 => 54,  210 => 53,  199 => 50,  196 => 49,  191 => 48,  189 => 47,  186 => 46,  180 => 43,  177 => 42,  175 => 41,  172 => 40,  165 => 39,  156 => 36,  153 => 34,  146 => 33,  132 => 30,  122 => 27,  117 => 26,  110 => 25,  100 => 22,  93 => 21,  85 => 1,  82 => 17,  79 => 15,  77 => 14,  75 => 13,  73 => 12,  71 => 11,  69 => 10,  63 => 6,  59 => 5,  57 => 4,  55 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_base/layout.html.twig' %}
{% import '@bolt/_macro/_macro.html.twig' as macro %}

{% set alltypes = ['select'] %}
{% for key, fielddefinition in record.definition.fields %}
    {% set alltypes = alltypes|merge([fielddefinition.type]) %}
{% endfor %}

{# Set the displayTitle, according to the record being new or not, whether it has a title set and if it's a singleton #}
{% if record|title(currentlocale) %}
    {% set displayTitle = record|title(currentlocale) %}
{% elseif record.id %}
    {% set displayTitle = __('caption.untitled_contenttype', {'%contenttype%': record.definition.singular_name}) %}
{% elseif record.definition.singleton %}
    {% set displayTitle = record.definition.singular_name %}
{% else %}
    {% set displayTitle = __('caption.new_contenttype', {'%contenttype%': record.definition.singular_name}) %}
{% endif %}

{# The 'title' and 'shoulder' blocks are the main heading of the page. #}
{% block shoulder %}
    {{- (app.request.get('_route') == 'bolt_content_duplicate') ? 'caption.duplicate'|trans : 'caption.edit'|trans }} {{ record.definition.singular_name -}}
{% endblock shoulder %}

{% block title %}
    {{ icon(record) }}
    {{ displayTitle|excerpt(50) }}
{% endblock %}

{% block vue_id 'editor' %}

{# This 'topsection' gets output _before_ the main form, allowing `dump()`, without breaking Vue #}
{% block topsection %}

{#    {{ dump(record) }}#}

{% endblock %}

{% block main %}

    {% if record.definition.virtual|default(false) %}
        <div class=\"alert alert-danger\" role=\"alert\">
            {{ 'content.edit_missing_definition'|trans({'%contenttype%': record.definition.name}) }}
        </div>
    {% endif %}

    {% if errors is defined %}
        {%for error in errors %}
            <div class=\"alert alert-danger\" role=\"alert\">
                {{ error.propertyPath }}: {{error.message}}
            </div>
        {%endfor%}
    {% endif %}

    <form method=\"post\" id=\"editcontent\">
        {{ widgets('editcontent_below_header') }}

        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('editrecord') }}\">
        <input type=\"hidden\" name=\"_edit_locale\" value=\"{{ currentlocale }}\">
        {# To prevent confusion in browsers about which submit to use when pressing 'enter', we
        provide this _input_ here. All browsers will use this as a default. See #454 on Github. #}
        <input type=\"submit\" form=\"editcontent\" style=\"display: none;\" value=\"__('action.save')\">

        {% set groups = record.definition.groups|default([]) %}

        {% include '@bolt/content/_tabs.html.twig' %}

        <div class=\"tab-content\" id=\"nav-tabContent\">

            {% include '@bolt/content/_fields.html.twig' %}

            {# Note: the `|slug` below should be entirely unnecesary, but is added here for consistency, if a certain
            locale / slugify config insist on keeping uppercase letters. See: https://github.com/bolt/core/pull/2907 #}
            <div class=\"tab-pane\" id=\"{{ \"Relations\"|slug }}\" role=\"tabpanel\" aria-labelledby=\"relations-tab\">

                {% include '@bolt/content/_relationships.html.twig' %}

                {% include '@bolt/content/_taxonomies.html.twig' %}
            </div>

        </div>
        {{ widgets('editcontent_bottom') }}

        <hr>
        {% include '@bolt/content/_buttons.html.twig' with {'hide_on_mobile': true} %}

    </form>

{% endblock %}

{% block aside %}
    <div id=\"metadata\">
        <form class=\"ui form\">
            {{ widgets('editcontent_aside_top') }}

            <div class=\"card mb-3\">
                <div class=\"card-header\">
                    {{ macro.icon('star') }} {{ 'title.primary_actions'|trans }}
                </div>
                <div class=\"card-body\">
                    {% include '@bolt/content/_buttons.html.twig' with {'status': true} %}
                </div>
            </div>

            {% include '@bolt/content/_localeswitcher.html.twig' %}
            {{ widgets('editcontent_aside_middle') }}

            <div class=\"card\">
                <div class=\"card-header\">
                    {{ macro.icon('sliders-h') }} {{ 'title.options'|trans }}
                </div>
                <div class=\"card-body\">
                    {% include '@bolt/content/_fields_aside.html.twig' %}
                    {% include '@bolt/content/_fields_aside_summary.html.twig' %}
                </div>
            </div>

            {{ widgets('editcontent_aside_bottom') }}
        </form>
    </div>
{% endblock aside %}
", "@bolt/content/edit.html.twig", "/var/www/html/vendor/bolt/core/templates/content/edit.html.twig");
    }
}
