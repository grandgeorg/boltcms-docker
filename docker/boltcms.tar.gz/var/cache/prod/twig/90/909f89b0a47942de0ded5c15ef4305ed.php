<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_relationships.html.twig */
class __TwigTemplate_f5e2ee54e059fcadba8c1309bacb6557 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_relationships.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("_macro/_macro.html.twig", "@bolt/content/_relationships.html.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 3, $this->source); })()), "definition", [], "any", false, false, false, 3), "relations", [], "any", false, false, false, 3));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["contentType"] => $context["relation"]) {
            // line 4
            yield "
    ";
            // line 5
            $context["options"] = $this->extensions['Bolt\Twig\RelatedExtension']->getRelatedOptions($context["contentType"], ((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "order", [], "any", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "order", [], "any", false, false, false, 5))) : ("")), ((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "format", [], "any", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "format", [], "any", false, false, false, 5))) : ("")), CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "required", [], "any", false, false, false, 5), CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "allow_empty", [], "any", false, false, false, 5));
            // line 6
            yield "
    ";
            // line 7
            $context["value"] = $this->extensions['Bolt\Twig\RelatedExtension']->getRelatedValues((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 7, $this->source); })()), $context["contentType"]);
            // line 8
            yield "
    <div class=\"form-group is-normal\">

        ";
            // line 12
            yield "        ";
            if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "prefix", [], "array", true, true, false, 12)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "prefix", [], "array", false, false, false, 12))) : ("")))) {
                // line 13
                yield "            ";
                yield CoreExtension::callMacro($macros["macro"], "macro_generatePrefix", [((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "prefix", [], "array", true, true, false, 13)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "prefix", [], "array", false, false, false, 13))) : ("")), $context["contentType"]], 13, $context, $this->getSourceContext());
                yield "
        ";
            }
            // line 15
            yield "
        ";
            // line 16
            yield from             $this->loadTemplate("@bolt/_partials/fields/_label.html.twig", "@bolt/content/_relationships.html.twig", 16)->unwrap()->yield(CoreExtension::merge($context, ["id" => ("relationship-" .             // line 17
$context["contentType"]), "label" => CoreExtension::getAttribute($this->env, $this->source,             // line 18
$context["relation"], "label", [], "any", false, false, false, 18), "required" => CoreExtension::getAttribute($this->env, $this->source,             // line 19
$context["relation"], "required", [], "any", false, false, false, 19)]));
            // line 21
            yield "
        <div>
            <editor-select
                    :value=\"";
            // line 24
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 24, $this->source); })()), "html", null, true);
            yield "\"
                    :name=\"'relationship[";
            // line 25
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["contentType"], "html", null, true);
            yield "]'\"
                    :id=\"'relationship-";
            // line 26
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["contentType"], "html", null, true);
            yield "'\"
                    :options=\"";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["options"]) || array_key_exists("options", $context) ? $context["options"] : (function () { throw new RuntimeError('Variable "options" does not exist.', 27, $this->source); })()), "html", null, true);
            yield "\"
                    :multiple=\"";
            // line 28
            yield ((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "multiple", [], "any", false, false, false, 28)) ? ("true") : ("false"));
            yield "\"
                    :taggable=false
                    :autocomplete=true
            ></editor-select>
        </div>

        ";
            // line 35
            yield "        ";
            if ( !Twig\Extension\CoreExtension::testEmpty(((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "postfix", [], "array", true, true, false, 35)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "postfix", [], "array", false, false, false, 35))) : ("")))) {
                // line 36
                yield "            ";
                yield CoreExtension::callMacro($macros["macro"], "macro_generatePostfix", [((CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "postfix", [], "array", true, true, false, 36)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["relation"], "postfix", [], "array", false, false, false, 36))) : ("")), $context["contentType"]], 36, $context, $this->getSourceContext());
                yield "
        ";
            }
            // line 38
            yield "
    </div>

";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['contentType'], $context['relation'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_relationships.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  155 => 42,  138 => 38,  132 => 36,  129 => 35,  120 => 28,  116 => 27,  112 => 26,  108 => 25,  104 => 24,  99 => 21,  97 => 19,  96 => 18,  95 => 17,  94 => 16,  91 => 15,  85 => 13,  82 => 12,  77 => 8,  75 => 7,  72 => 6,  70 => 5,  67 => 4,  50 => 3,  47 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '_macro/_macro.html.twig' as macro %}

{% for contentType, relation in record.definition.relations %}

    {% set options = related_options(contentType, relation.order|default(), relation.format|default(), relation.required, relation.allow_empty) %}

    {% set value = record|related_values(contentType) %}

    <div class=\"form-group is-normal\">

        {# Print prefix #}
        {% if relation['prefix']|default() is not empty %}
            {{ macro.generatePrefix(relation['prefix']|default, contentType) }}
        {% endif %}

        {% include '@bolt/_partials/fields/_label.html.twig' with {
            'id': 'relationship-' ~ contentType,
            'label': relation.label,
            'required': relation.required
        } %}

        <div>
            <editor-select
                    :value=\"{{ value }}\"
                    :name=\"'relationship[{{ contentType }}]'\"
                    :id=\"'relationship-{{ contentType }}'\"
                    :options=\"{{ options }}\"
                    :multiple=\"{{ relation.multiple ? 'true' : 'false' }}\"
                    :taggable=false
                    :autocomplete=true
            ></editor-select>
        </div>

        {# Print postfix #}
        {% if relation['postfix']|default() is not empty %}
            {{ macro.generatePostfix(relation['postfix']|default, contentType) }}
        {% endif %}

    </div>

{% endfor %}

", "@bolt/content/_relationships.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_relationships.html.twig");
    }
}
