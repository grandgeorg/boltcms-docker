<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_fields_aside_summary.html.twig */
class __TwigTemplate_aed2525bcb4741dc9afaabd7c615d977 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_fields_aside_summary.html.twig"));

        // line 1
        yield "<hr>
<div class=\"form-fieldsgroup form-fieldsgroup__summary-fields\">
    <ul class=\"summary-fields\">
        <li>
        ";
        // line 5
        yield from         $this->loadTemplate("@bolt/_partials/fields/date.html.twig", "@bolt/content/_fields_aside_summary.html.twig", 5)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.createdAt"), "name" => "createdAt", "value" => CoreExtension::getAttribute($this->env, $this->source,         // line 8
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 8, $this->source); })()), "createdAt", [], "any", false, false, false, 8), "valueonly" => true, "locale" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 10
(isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 10, $this->source); })()), "user", [], "any", false, false, false, 10), "locale", [], "any", false, false, false, 10)]));
        // line 12
        yield "        </li>

        <li>
        ";
        // line 15
        yield from         $this->loadTemplate("@bolt/_partials/fields/date.html.twig", "@bolt/content/_fields_aside_summary.html.twig", 15)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.modifiedAt"), "name" => "modifiedAt", "value" => CoreExtension::getAttribute($this->env, $this->source,         // line 18
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 18, $this->source); })()), "modifiedAt", [], "any", false, false, false, 18), "valueonly" => true, "locale" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 20
(isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 20, $this->source); })()), "user", [], "any", false, false, false, 20), "locale", [], "any", false, false, false, 20)]));
        // line 22
        yield "        </li>

        <li>
        ";
        // line 25
        yield from         $this->loadTemplate("@bolt/_partials/fields/text.html.twig", "@bolt/content/_fields_aside_summary.html.twig", 25)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.id"), "name" => "id", "value" => CoreExtension::getAttribute($this->env, $this->source,         // line 28
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 28, $this->source); })()), "id", [], "any", false, false, false, 28), "valueonly" => true, "locale" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 30
(isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 30, $this->source); })()), "user", [], "any", false, false, false, 30), "locale", [], "any", false, false, false, 30)]));
        // line 32
        yield "        </li>
    </ul>
</div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_fields_aside_summary.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  73 => 32,  71 => 30,  70 => 28,  69 => 25,  64 => 22,  62 => 20,  61 => 18,  60 => 15,  55 => 12,  53 => 10,  52 => 8,  51 => 5,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<hr>
<div class=\"form-fieldsgroup form-fieldsgroup__summary-fields\">
    <ul class=\"summary-fields\">
        <li>
        {% include '@bolt/_partials/fields/date.html.twig' with {
            'label' : 'field.createdAt'|trans,
            'name' : 'createdAt',
            'value' : record.createdAt,
            'valueonly' : true,
            'locale': app.user.locale
        } %}
        </li>

        <li>
        {% include '@bolt/_partials/fields/date.html.twig' with {
            'label' : 'field.modifiedAt'|trans,
            'name' : 'modifiedAt',
            'value' : record.modifiedAt,
            'valueonly' : true,
            'locale': app.user.locale
        } %}
        </li>

        <li>
        {% include '@bolt/_partials/fields/text.html.twig' with {
            'label' : 'field.id'|trans,
            'name' : 'id',
            'value' : record.id,
            'valueonly' : true,
            'locale': app.user.locale
        } %}
        </li>
    </ul>
</div>
", "@bolt/content/_fields_aside_summary.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_fields_aside_summary.html.twig");
    }
}
