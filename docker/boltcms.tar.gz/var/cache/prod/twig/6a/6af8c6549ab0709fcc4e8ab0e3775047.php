<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/text.html.twig */
class __TwigTemplate_95b97f939f5ff1409c193a48944d4169 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_partials/fields/_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/text.html.twig"));

        // line 4
        if ( !array_key_exists("disabled", $context)) {
            // line 5
            $context["disabled"] = false;
        }
        // line 9
        if ( !array_key_exists("valueonly", $context)) {
            // line 10
            $context["valueonly"] = false;
        }
        // line 14
        if ( !array_key_exists("autofocus", $context)) {
            // line 15
            $context["autofocus"] = false;
        }
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_partials/fields/_base.html.twig", "@bolt/_partials/fields/text.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 18
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 19
        yield "    ";
        if ( !(isset($context["valueonly"]) || array_key_exists("valueonly", $context) ? $context["valueonly"] : (function () { throw new RuntimeError('Variable "valueonly" does not exist.', 19, $this->source); })())) {
            // line 20
            yield "        <editor-text
            :id='";
            // line 21
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 21, $this->source); })())), "html", null, true);
            yield "'
            :value=\"";
            // line 22
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 22, $this->source); })())), "html", null, true);
            yield "\"
            :name='";
            // line 23
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 23, $this->source); })())), "html", null, true);
            yield "'
            :type='";
            // line 24
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 24, $this->source); })())), "html", null, true);
            yield "'
            :disabled='";
            // line 25
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 25, $this->source); })())), "html", null, true);
            yield "'
            :required='";
            // line 26
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 26, $this->source); })())), "html", null, true);
            yield "'
            :readonly='";
            // line 27
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 27, $this->source); })())), "html", null, true);
            yield "'
            :errormessage='";
            // line 28
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["errormessage"]) || array_key_exists("errormessage", $context) ? $context["errormessage"] : (function () { throw new RuntimeError('Variable "errormessage" does not exist.', 28, $this->source); })())), "html", null, true);
            yield "'
            :pattern='";
            // line 29
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["pattern"]) || array_key_exists("pattern", $context) ? $context["pattern"] : (function () { throw new RuntimeError('Variable "pattern" does not exist.', 29, $this->source); })())), "html", null, true);
            yield "'
            :placeholder='";
            // line 30
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["placeholder"]) || array_key_exists("placeholder", $context) ? $context["placeholder"] : (function () { throw new RuntimeError('Variable "placeholder" does not exist.', 30, $this->source); })())), "html", null, true);
            yield "'
            :autofocus='";
            // line 31
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["autofocus"]) || array_key_exists("autofocus", $context) ? $context["autofocus"] : (function () { throw new RuntimeError('Variable "autofocus" does not exist.', 31, $this->source); })())), "html", null, true);
            yield "'
        ></editor-text>
    ";
        } else {
            // line 34
            yield "        <span
            :id='";
            // line 35
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 35, $this->source); })())), "html", null, true);
            yield "'
            :name='";
            // line 36
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 36, $this->source); })())), "html", null, true);
            yield "'
            class=\"\"
            ";
            // line 38
            if ((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 38, $this->source); })())) {
                yield " required ";
            }
            // line 39
            yield "            ";
            if ((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 39, $this->source); })())) {
                yield " readonly ";
            }
            // line 40
            yield "        >";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 40, $this->source); })())), "html", null, true);
            yield "</span>
    ";
        }
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/text.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  153 => 40,  148 => 39,  144 => 38,  139 => 36,  135 => 35,  132 => 34,  126 => 31,  122 => 30,  118 => 29,  114 => 28,  110 => 27,  106 => 26,  102 => 25,  98 => 24,  94 => 23,  90 => 22,  86 => 21,  83 => 20,  80 => 19,  73 => 18,  65 => 1,  62 => 15,  60 => 14,  57 => 10,  55 => 9,  52 => 5,  50 => 4,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_partials/fields/_base.html.twig' %}

{# check disabled #}
{% if disabled is not defined %}
    {% set disabled = false %}
{% endif %}

{# check if we only want the value: valueonly #}
{% if valueonly is not defined %}
    {% set valueonly = false %}
{% endif %}

{# check autofocus #}
{% if autofocus is not defined %}
    {% set autofocus = false %}
{% endif %}

{% block field %}
    {% if not valueonly %}
        <editor-text
            :id='{{ id|json_encode }}'
            :value=\"{{ value|json_encode }}\"
            :name='{{ name|json_encode }}'
            :type='{{ class|json_encode }}'
            :disabled='{{ disabled|json_encode }}'
            :required='{{ required|json_encode }}'
            :readonly='{{ readonly|json_encode }}'
            :errormessage='{{ errormessage|json_encode }}'
            :pattern='{{ pattern|json_encode }}'
            :placeholder='{{ placeholder|json_encode }}'
            :autofocus='{{ autofocus|json_encode }}'
        ></editor-text>
    {% else %}
        <span
            :id='{{ id|json_encode }}'
            :name='{{ name|json_encode }}'
            class=\"\"
            {% if required %} required {% endif %}
            {% if readonly %} readonly {% endif %}
        >{{ value|json_encode }}</span>
    {% endif %}
{% endblock %}
", "@bolt/_partials/fields/text.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/text.html.twig");
    }
}
