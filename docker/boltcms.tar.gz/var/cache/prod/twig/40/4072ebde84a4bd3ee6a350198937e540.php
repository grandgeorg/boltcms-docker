<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/_partials/fields/slug.html.twig */
class __TwigTemplate_ab4edf67466f0fcaa8182c3c47cae5f4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'field' => [$this, 'block_field'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_partials/fields/_base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/_partials/fields/slug.html.twig"));

        $this->parent = $this->loadTemplate("@bolt/_partials/fields/_base.html.twig", "@bolt/_partials/fields/slug.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_field($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "field"));

        // line 4
        $context["prefix"] = (("/" . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 4, $this->source); })()), "definition", [], "any", false, false, false, 4), "singular_slug", [], "any", false, false, false, 4)) . "/");
        // line 5
        yield "    ";
        $context["isnew"] = (CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "new", [], "any", false, false, false, 5) || (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 5, $this->source); })()), "content", [], "any", false, false, false, 5), "id", [], "any", false, false, false, 5) === 0));
        // line 6
        yield "    <editor-slug
        :value='";
        // line 7
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 7, $this->source); })())), "html", null, true);
        yield "'
        :name='";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 8, $this->source); })())), "html", null, true);
        yield "'
        :prefix='";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["prefix"]) || array_key_exists("prefix", $context) ? $context["prefix"] : (function () { throw new RuntimeError('Variable "prefix" does not exist.', 9, $this->source); })())), "html", null, true);
        yield "'
        :field-class='";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new RuntimeError('Variable "class" does not exist.', 10, $this->source); })())), "html", null, true);
        yield "'
        :required='";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["required"]) || array_key_exists("required", $context) ? $context["required"] : (function () { throw new RuntimeError('Variable "required" does not exist.', 11, $this->source); })())), "html", null, true);
        yield "'
        :readonly='";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["readonly"]) || array_key_exists("readonly", $context) ? $context["readonly"] : (function () { throw new RuntimeError('Variable "readonly" does not exist.', 12, $this->source); })())), "html", null, true);
        yield "'
        :generate='";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(Twig\Extension\CoreExtension::join(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 13, $this->source); })()), "definition", [], "any", false, false, false, 13), "uses", [], "any", false, false, false, 13), ",")), "html", null, true);
        yield "'
        :errormessage='";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["errormessage"]) || array_key_exists("errormessage", $context) ? $context["errormessage"] : (function () { throw new RuntimeError('Variable "errormessage" does not exist.', 14, $this->source); })())), "html", null, true);
        yield "'
        :pattern='";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["pattern"]) || array_key_exists("pattern", $context) ? $context["pattern"] : (function () { throw new RuntimeError('Variable "pattern" does not exist.', 15, $this->source); })())), "html", null, true);
        yield "'
        :labels='";
        // line 16
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(["button_unlocked" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("slug.button_unlocked"), "button_locked" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("slug.button_locked"), "button_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("slug.button_edit"), "generate_from" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("slug.generate_from")]), "html", null, true);
        // line 21
        yield "'
        :localize='";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 22, $this->source); })()), "definition", [], "any", false, false, false, 22), "localize", [], "any", false, false, false, 22)), "html", null, true);
        yield "'
        :is-new='";
        // line 23
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode((isset($context["isnew"]) || array_key_exists("isnew", $context) ? $context["isnew"] : (function () { throw new RuntimeError('Variable "isnew" does not exist.', 23, $this->source); })())), "html", null, true);
        yield "'
    ></editor-slug>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/_partials/fields/slug.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  117 => 23,  113 => 22,  110 => 21,  108 => 16,  104 => 15,  100 => 14,  96 => 13,  92 => 12,  88 => 11,  84 => 10,  80 => 9,  76 => 8,  72 => 7,  69 => 6,  66 => 5,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_partials/fields/_base.html.twig' %}

{% block field %}
{% set prefix = '/' ~ record.definition.singular_slug ~ '/' %}
    {% set isnew = field.new or field.content.id === 0 %}
    <editor-slug
        :value='{{ value|json_encode }}'
        :name='{{ name|json_encode }}'
        :prefix='{{ prefix|json_encode }}'
        :field-class='{{ class|json_encode }}'
        :required='{{ required|json_encode }}'
        :readonly='{{ readonly|json_encode }}'
        :generate='{{ field.definition.uses|join(',')|json_encode }}'
        :errormessage='{{ errormessage|json_encode }}'
        :pattern='{{ pattern|json_encode }}'
        :labels='{{ {
            'button_unlocked': 'slug.button_unlocked'|trans,
            'button_locked': 'slug.button_locked'|trans,
            'button_edit': 'slug.button_edit'|trans,
            'generate_from': 'slug.generate_from'|trans,
        }|json_encode }}'
        :localize='{{ field.definition.localize|json_encode }}'
        :is-new='{{ isnew|json_encode }}'
    ></editor-slug>
{% endblock %}
", "@bolt/_partials/fields/slug.html.twig", "/var/www/html/vendor/bolt/core/templates/_partials/fields/slug.html.twig");
    }
}
