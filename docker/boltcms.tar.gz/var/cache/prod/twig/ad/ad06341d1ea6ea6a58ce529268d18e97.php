<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_fields_aside.html.twig */
class __TwigTemplate_96916a51c463f0a4766a13687f9e8428 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_fields_aside.html.twig"));

        // line 1
        yield "<div class=\"form-fieldsgroup form-fieldsgroup__editable-fields\">

    ";
        // line 3
        $context["disableStatusChanges"] =  !$this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("change-status", (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 3, $this->source); })()));
        // line 4
        yield "    ";
        yield from         $this->loadTemplate("@bolt/_partials/fields/select.html.twig", "@bolt/content/_fields_aside.html.twig", 4)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.status"), "name" => "status", "value" => [CoreExtension::getAttribute($this->env, $this->source,         // line 7
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 7, $this->source); })()), "status", [], "any", false, false, false, 7)], "options" => $this->extensions['Bolt\Twig\ContentExtension']->statusOptions(        // line 8
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 8, $this->source); })())), "form" => "editcontent", "required" => true, "readonly" =>         // line 11
(isset($context["disableStatusChanges"]) || array_key_exists("disableStatusChanges", $context) ? $context["disableStatusChanges"] : (function () { throw new RuntimeError('Variable "disableStatusChanges" does not exist.', 11, $this->source); })())]));
        // line 13
        yield "
    ";
        // line 14
        yield from         $this->loadTemplate("@bolt/_partials/fields/date.html.twig", "@bolt/content/_fields_aside.html.twig", 14)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.publishedAt"), "name" => "publishedAt", "value" => CoreExtension::getAttribute($this->env, $this->source,         // line 17
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 17, $this->source); })()), "publishedAt", [], "any", false, false, false, 17), "mode" => "datetime", "form" => "editcontent", "readonly" =>         // line 20
(isset($context["disableStatusChanges"]) || array_key_exists("disableStatusChanges", $context) ? $context["disableStatusChanges"] : (function () { throw new RuntimeError('Variable "disableStatusChanges" does not exist.', 20, $this->source); })())]));
        // line 22
        yield "
    ";
        // line 23
        yield from         $this->loadTemplate("@bolt/_partials/fields/date.html.twig", "@bolt/content/_fields_aside.html.twig", 23)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.depublishedAt"), "name" => "depublishedAt", "value" => CoreExtension::getAttribute($this->env, $this->source,         // line 26
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 26, $this->source); })()), "depublishedAt", [], "any", false, false, false, 26), "mode" => "datetime", "form" => "editcontent", "readonly" =>         // line 29
(isset($context["disableStatusChanges"]) || array_key_exists("disableStatusChanges", $context) ? $context["disableStatusChanges"] : (function () { throw new RuntimeError('Variable "disableStatusChanges" does not exist.', 29, $this->source); })())]));
        // line 31
        yield "
    ";
        // line 32
        yield from         $this->loadTemplate("@bolt/_partials/fields/text.html.twig", "@bolt/content/_fields_aside.html.twig", 32)->unwrap()->yield(CoreExtension::merge($context, ["label" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.author"), "name" => "author", "value" => ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,         // line 35
($context["record"] ?? null), "author", [], "any", false, true, false, 35), "displayName", [], "any", true, true, false, 35)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "author", [], "any", false, true, false, 35), "displayName", [], "any", false, false, false, 35), "undefined")) : ("undefined")), "disabled" => true]));
        // line 38
        yield "
</div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_fields_aside.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  77 => 38,  75 => 35,  74 => 32,  71 => 31,  69 => 29,  68 => 26,  67 => 23,  64 => 22,  62 => 20,  61 => 17,  60 => 14,  57 => 13,  55 => 11,  54 => 8,  53 => 7,  51 => 4,  49 => 3,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"form-fieldsgroup form-fieldsgroup__editable-fields\">

    {% set disableStatusChanges = not is_granted('change-status', record) %}
    {% include '@bolt/_partials/fields/select.html.twig' with {
        'label' : 'field.status'|trans,
        'name' : 'status',
        'value' : [record.status],
        'options' : record|status_options,
        'form' : 'editcontent',
        'required' : true,
        'readonly' : disableStatusChanges
    } %}

    {% include '@bolt/_partials/fields/date.html.twig' with {
        'label' : 'field.publishedAt'|trans,
        'name' : 'publishedAt',
        'value' : record.publishedAt,
        'mode' : 'datetime',
        'form' : 'editcontent',
        'readonly' : disableStatusChanges
    } %}

    {% include '@bolt/_partials/fields/date.html.twig' with {
        'label' : 'field.depublishedAt'|trans,
        'name' : 'depublishedAt',
        'value' : record.depublishedAt,
        'mode' : 'datetime',
        'form' : 'editcontent',
        'readonly' : disableStatusChanges
    } %}

    {% include '@bolt/_partials/fields/text.html.twig' with {
        'label' : 'field.author'|trans,
        'name' : 'author',
        'value' : record.author.displayName|default('undefined'),
        'disabled' : true
    } %}

</div>
", "@bolt/content/_fields_aside.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_fields_aside.html.twig");
    }
}
