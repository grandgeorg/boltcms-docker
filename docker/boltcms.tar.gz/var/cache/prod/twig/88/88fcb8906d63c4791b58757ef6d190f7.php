<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/finder/editfile.html.twig */
class __TwigTemplate_282681762585a8230cb8d1841b0c73da extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'shoulder' => [$this, 'block_shoulder'],
            'title' => [$this, 'block_title'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@bolt/_base/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/finder/editfile.html.twig"));

        // line 2
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/finder/editfile.html.twig", 2)->unwrap();
        // line 4
        $context["extension"] = Twig\Extension\CoreExtension::last($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new RuntimeError('Variable "file" does not exist.', 4, $this->source); })()), "."));
        // line 5
        $context["modes"] = ["md" => "markdown", "markdown" => "markdown", "htm" => "html", "html" => "html", "yml" => "yaml", "yaml" => "yaml", "twig" => "twig", "css" => "css", "js" => "javascript", "php" => "php"];
        // line 17
        $context["mode"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["modes"] ?? null), (isset($context["extension"]) || array_key_exists("extension", $context) ? $context["extension"] : (function () { throw new RuntimeError('Variable "extension" does not exist.', 17, $this->source); })()), [], "array", true, true, false, 17)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["modes"] ?? null), (isset($context["extension"]) || array_key_exists("extension", $context) ? $context["extension"] : (function () { throw new RuntimeError('Variable "extension" does not exist.', 17, $this->source); })()), [], "array", false, false, false, 17), "")) : (""));
        // line 1
        $this->parent = $this->loadTemplate("@bolt/_base/layout.html.twig", "@bolt/finder/editfile.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 20
    public function block_shoulder($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "shoulder"));

        // line 21
        yield "    ";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("caption.edit_file"), "html", null, true);
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 24
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 25
        yield "    ";
        yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["file-code"], 25, $context, $this->getSourceContext());
        yield "
    ";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("caption.path"), "html", null, true);
        yield ": <code>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new RuntimeError('Variable "location" does not exist.', 26, $this->source); })()), "html", null, true);
        yield "/<strong>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::last($this->env->getCharset(), Twig\Extension\CoreExtension::split($this->env->getCharset(), (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new RuntimeError('Variable "file" does not exist.', 26, $this->source); })()), "/")), "html", null, true);
        yield "</strong></code>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 29
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 30
        yield "    <form method=\"post\">
        <input type=\"hidden\" name=\"file\" value=\"";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new RuntimeError('Variable "file" does not exist.', 31, $this->source); })()), "html", null, true);
        yield "\">
        <input type=\"hidden\" name=\"location\" value=\"";
        // line 32
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new RuntimeError('Variable "location" does not exist.', 32, $this->source); })()), "html", null, true);
        yield "\">
        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 33
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("editfile"), "html", null, true);
        yield "\">
        <div class=\"form-group\">
            <textarea title=\"undefined\" name=\"editfile\" id=\"editfile_textarea\">";
        // line 35
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["contents"]) || array_key_exists("contents", $context) ? $context["contents"] : (function () { throw new RuntimeError('Variable "contents" does not exist.', 35, $this->source); })()), "html", null, true);
        yield "</textarea>
        </div>
        <div class=\"form-group\">
            <button class=\"btn btn-primary\" name=\"save\" type=\"submit\" ";
        // line 38
        if ( !(isset($context["writable"]) || array_key_exists("writable", $context) ? $context["writable"] : (function () { throw new RuntimeError('Variable "writable" does not exist.', 38, $this->source); })())) {
            yield "disabled";
        }
        yield ">";
        yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["save"], 38, $context, $this->getSourceContext());
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
        yield "</button>
            ";
        // line 39
        if ( !(isset($context["writable"]) || array_key_exists("writable", $context) ? $context["writable"] : (function () { throw new RuntimeError('Variable "writable" does not exist.', 39, $this->source); })())) {
            yield $this->extensions['Bolt\Twig\LocaleExtension']->translate("editfile.target_not_writable");
        }
        // line 40
        yield "        </div>
    </form>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 44
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 45
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
<script>
    var editfile_textarea = document.getElementById('editfile_textarea');
    var myCodeMirror = CodeMirror.fromTextArea(editfile_textarea, {
        lineNumbers: true,
        mode: '";
        // line 50
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["mode"]) || array_key_exists("mode", $context) ? $context["mode"] : (function () { throw new RuntimeError('Variable "mode" does not exist.', 50, $this->source); })()), "html", null, true);
        yield "'
    });
</script>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/finder/editfile.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  180 => 50,  172 => 45,  165 => 44,  155 => 40,  151 => 39,  142 => 38,  136 => 35,  131 => 33,  127 => 32,  123 => 31,  120 => 30,  113 => 29,  99 => 26,  94 => 25,  87 => 24,  76 => 21,  69 => 20,  61 => 1,  59 => 17,  57 => 5,  55 => 4,  53 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% extends '@bolt/_base/layout.html.twig' %}
{% import '@bolt/_macro/_macro.html.twig' as macro %}

{% set extension = file|split('.')|last %}
{% set modes = {
    'md': 'markdown',
    'markdown': 'markdown',
    'htm': 'html',
    'html': 'html',
    'yml': 'yaml',
    'yaml': 'yaml',
    'twig': 'twig',
    'css': 'css',
    'js': 'javascript',
    'php': 'php'
} %}
{% set mode = modes[extension]|default('') %}

{# The 'title' and 'shoulder' blocks are the main heading of the page. #}
{% block shoulder %}
    {{ 'caption.edit_file'|trans }}
{% endblock shoulder %}

{% block title %}
    {{ macro.icon('file-code') }}
    {{ 'caption.path'|trans }}: <code>{{ location }}/<strong>{{ file|split('/')|last}}</strong></code>
{% endblock %}

{% block main %}
    <form method=\"post\">
        <input type=\"hidden\" name=\"file\" value=\"{{ file }}\">
        <input type=\"hidden\" name=\"location\" value=\"{{ location }}\">
        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('editfile') }}\">
        <div class=\"form-group\">
            <textarea title=\"undefined\" name=\"editfile\" id=\"editfile_textarea\">{{ contents }}</textarea>
        </div>
        <div class=\"form-group\">
            <button class=\"btn btn-primary\" name=\"save\" type=\"submit\" {% if not writable %}disabled{% endif %}>{{ macro.icon('save') }}{{ 'action.save'|trans }}</button>
            {% if not writable %}{{ __('editfile.target_not_writable') }}{% endif %}
        </div>
    </form>
{% endblock %}

{% block javascripts %}
{{ parent() }}
<script>
    var editfile_textarea = document.getElementById('editfile_textarea');
    var myCodeMirror = CodeMirror.fromTextArea(editfile_textarea, {
        lineNumbers: true,
        mode: '{{ mode }}'
    });
</script>
{% endblock %}
", "@bolt/finder/editfile.html.twig", "/var/www/html/vendor/bolt/core/templates/finder/editfile.html.twig");
    }
}
