<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_localeswitcher.html.twig */
class __TwigTemplate_02e2b11fcb39c65fbfb1fdb876c8c5b5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_localeswitcher.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/content/_localeswitcher.html.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        if (((CoreExtension::getAttribute($this->env, $this->source, (isset($context["locales"]) || array_key_exists("locales", $context) ? $context["locales"] : (function () { throw new RuntimeError('Variable "locales" does not exist.', 3, $this->source); })()), "count", [], "any", false, false, false, 3) > 1) || ((isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 3, $this->source); })()) !== (isset($context["defaultlocale"]) || array_key_exists("defaultlocale", $context) ? $context["defaultlocale"] : (function () { throw new RuntimeError('Variable "defaultlocale" does not exist.', 3, $this->source); })())))) {
            // line 4
            yield "    <div class=\"card mb-3\">
        <div class=\"card-header\">
            ";
            // line 6
            yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["language"], 6, $context, $this->getSourceContext());
            yield "
            ";
            // line 7
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.current_locale"), "html", null, true);
            yield ":
            ";
            // line 8
            yield $this->extensions['Bolt\Twig\LocaleExtension']->flag((isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 8, $this->source); })()));
            yield "<b>";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 8, $this->source); })()), "html", null, true);
            yield "</b>
        </div>

        ";
            // line 11
            if (((CoreExtension::getAttribute($this->env, $this->source, (isset($context["locales"]) || array_key_exists("locales", $context) ? $context["locales"] : (function () { throw new RuntimeError('Variable "locales" does not exist.', 11, $this->source); })()), "count", [], "any", false, false, false, 11) > 1) && CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 11, $this->source); })()), "id", [], "any", false, false, false, 11))) {
                // line 12
                yield "        <div class=\"card-body\">
            <general-language
                    label=\"";
                // line 14
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.switch_to_locale"), "html", null, true);
                yield ":\"
                    current=\"";
                // line 15
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 15, $this->source); })()), "html", null, true);
                yield "\"
                    :locales=\"";
                // line 16
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\LocaleExtension']->getLocales($this->env, (isset($context["locales"]) || array_key_exists("locales", $context) ? $context["locales"] : (function () { throw new RuntimeError('Variable "locales" does not exist.', 16, $this->source); })())), "html", null, true);
                yield "\"
            ></general-language>

            ";
                // line 19
                yield CoreExtension::callMacro($macros["macro"], "macro_buttonlink", ["localeswitcher.button_info", $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_content_edit_locales", ["id" => CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 19, $this->source); })()), "id", [], "any", false, false, false, 19)]), "info-circle", "tertiary btn-sm"], 19, $context, $this->getSourceContext());
                yield "
        </div>
        ";
            }
            // line 22
            yield "    </div>
";
        }
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_localeswitcher.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  98 => 22,  92 => 19,  86 => 16,  82 => 15,  78 => 14,  74 => 12,  72 => 11,  64 => 8,  60 => 7,  56 => 6,  52 => 4,  50 => 3,  47 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '@bolt/_macro/_macro.html.twig' as macro %}

{% if locales.count > 1 or currentlocale !== defaultlocale %}
    <div class=\"card mb-3\">
        <div class=\"card-header\">
            {{ macro.icon('language') }}
            {{ 'field.current_locale'|trans }}:
            {{ flag(currentlocale) }}<b>{{ currentlocale }}</b>
        </div>

        {% if locales.count > 1 and record.id %}
        <div class=\"card-body\">
            <general-language
                    label=\"{{ 'field.switch_to_locale'|trans }}:\"
                    current=\"{{ currentlocale }}\"
                    :locales=\"{{ locales(locales) }}\"
            ></general-language>

            {{ macro.buttonlink('localeswitcher.button_info', path('bolt_content_edit_locales', {'id': record.id}),  'info-circle', 'tertiary btn-sm') }}
        </div>
        {% endif %}
    </div>
{% endif %}
", "@bolt/content/_localeswitcher.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_localeswitcher.html.twig");
    }
}
