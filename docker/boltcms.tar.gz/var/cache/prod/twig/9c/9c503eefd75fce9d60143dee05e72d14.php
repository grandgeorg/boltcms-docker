<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @redactor/injector.html.twig */
class __TwigTemplate_f3d73d448102e2be6bdb951e5f314056 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@redactor/injector.html.twig"));

        // line 1
        yield "<script src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\AssetsExtension']->getAssetUrl("assets/redactor/redactor.min.js", "public"), "html", null, true);
        yield "\"></script>
<link rel=\"stylesheet\" href=\"";
        // line 2
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\AssetsExtension']->getAssetUrl("assets/redactor/redactor.min.css", "public"), "html", null, true);
        yield "\">
";
        // line 3
        yield $this->extensions['Bolt\Redactor\TwigExtension']->redactorIncludes();
        yield "
<script>
    \$R.options = {
        callbacks: {
            image: {
                uploadError: function(response)
                {
                    alert(response.message);
                }
            },
            file: {
                uploadError: function(response)
                {
                    alert(response.message);
                }
            }
        }
    };

    function initRedactors() {
        \$('.redactor-field').removeClass('d-none');
        \$R('.redactor-field', ";
        // line 24
        yield $this->extensions['Bolt\Redactor\TwigExtension']->redactorSettings();
        yield ");
    }

    \$(document).on('DOMNodeInserted', function(e) {
        if ( \$(e.target).hasClass('collection-item') ) {
            initRedactors();
        }
    });

    initRedactors();
</script>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@redactor/injector.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  78 => 24,  54 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<script src=\"{{ asset('assets/redactor/redactor.min.js', 'public') }}\"></script>
<link rel=\"stylesheet\" href=\"{{ asset('assets/redactor/redactor.min.css', 'public') }}\">
{{ redactor_includes() }}
<script>
    \$R.options = {
        callbacks: {
            image: {
                uploadError: function(response)
                {
                    alert(response.message);
                }
            },
            file: {
                uploadError: function(response)
                {
                    alert(response.message);
                }
            }
        }
    };

    function initRedactors() {
        \$('.redactor-field').removeClass('d-none');
        \$R('.redactor-field', {{ redactor_settings() }});
    }

    \$(document).on('DOMNodeInserted', function(e) {
        if ( \$(e.target).hasClass('collection-item') ) {
            initRedactors();
        }
    });

    initRedactors();
</script>

", "@redactor/injector.html.twig", "/var/www/html/vendor/bolt/redactor/templates/injector.html.twig");
    }
}
