<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @bolt/content/_buttons.html.twig */
class __TwigTemplate_91c599ee043d72ade854fd7ba08d9b57 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "@bolt/content/_buttons.html.twig"));

        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->loadTemplate("@bolt/_macro/_macro.html.twig", "@bolt/content/_buttons.html.twig", 1)->unwrap();
        // line 2
        yield "
<div class=\"record-actions ";
        // line 3
        if (((array_key_exists("hide_on_mobile", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["hide_on_mobile"]) || array_key_exists("hide_on_mobile", $context) ? $context["hide_on_mobile"] : (function () { throw new RuntimeError('Variable "hide_on_mobile" does not exist.', 3, $this->source); })()), false)) : (false))) {
            yield "d-none d-xl-block";
        }
        yield "\">
    ";
        // line 4
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 4, $this->source); })()))) {
            // line 5
            yield "        ";
            yield CoreExtension::callMacro($macros["macro"], "macro_button", ["action.save", "fa-save", "success mb-0", ["type" => "submit", "form" => "editcontent", "data-patience" => "virtue", "name" => "save"]], 5, $context, $this->getSourceContext());
            yield "
    ";
        }
        // line 7
        yield "
    ";
        // line 8
        if (CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 8, $this->source); })()), "id", [], "any", false, false, false, 8)) {
            // line 9
            yield "        ";
            if ((($this->extensions['Bolt\Twig\ContentExtension']->getSpecialFeature((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 9, $this->source); })())) == "homepage") ||  !CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 9, $this->source); })()), "definition", [], "any", false, false, false, 9), "get", ["viewless"], "method", false, false, false, 9))) {
                // line 10
                yield "            <div class=\"btn-group\">
                ";
                // line 11
                yield CoreExtension::callMacro($macros["macro"], "macro_button", ["action.preview", "fa-external-link-square-alt", "primary mb-0", ["id" => "button-preview", "type" => "submit", "form" => "editcontent", "formtarget" => "_blank", "formaction" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bolt_content_edit_preview", ["id" => ((CoreExtension::getAttribute($this->env, $this->source,                 // line 19
($context["record"] ?? null), "id", [], "any", true, true, false, 19)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "id", [], "any", false, false, false, 19), 0)) : (0))])]], 11, $context, $this->getSourceContext());
                // line 20
                yield "

                <button name=\"bttn_name\" type=\"button\" class=\"btn btn-primary dropdown-toggle dropdown-toggle-split\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    <span class=\"sr-only\">Toggle Dropdown</span>
                </button>
                <div class=\"dropdown-menu\">
                    ";
                // line 26
                yield CoreExtension::callMacro($macros["macro"], "macro_buttonlink", [$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.preview_secure_share"), $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,                 // line 28
(isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 28, $this->source); })()), "definition", [], "any", false, false, false, 28), "get", ["record_route"], "method", false, false, false, 28), ["slugOrId" => CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 28, $this->source); })()), "id", [], "any", false, false, false, 28), "contentTypeSlug" => CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 28, $this->source); })()), "contenttype", [], "any", false, false, false, 28), "secret" => $this->extensions['Bolt\Twig\CommonExtension']->generateSecret(CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 28, $this->source); })()), "id", [], "any", false, false, false, 28))]), "fa-user-secret", "btn- dropdown-button mb-0", ["target" => "_blank"]], 26, $context, $this->getSourceContext());
                // line 32
                yield "
                </div>
            </div>
        ";
            }
            // line 36
            yield "
        ";
            // line 37
            if (((array_key_exists("status", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["status"]) || array_key_exists("status", $context) ? $context["status"] : (function () { throw new RuntimeError('Variable "status" does not exist.', 37, $this->source); })()))) : (""))) {
                // line 38
                yield "        <p class=\"mt-3\">
            <strong>";
                // line 39
                yield $this->extensions['Bolt\Twig\LocaleExtension']->translate("label.current_status");
                yield ":</strong>
            <span class=\"status mx-1 is-";
                // line 40
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 40, $this->source); })()), "status", [], "any", false, false, false, 40), "html", null, true);
                yield " mr-2\"></span>";
                yield $this->extensions['Bolt\Twig\LocaleExtension']->translate(("status." . CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 40, $this->source); })()), "status", [], "any", false, false, false, 40)));
                yield "<br>
            ";
                // line 41
                if ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 41, $this->source); })()), "status", [], "any", false, false, false, 41) == "published")) {
                    // line 42
                    yield "                <small>
                    (";
                    // line 43
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("field.modifiedAt"), "html", null, true);
                    yield ": ";
                    yield CoreExtension::callMacro($macros["macro"], "macro_relative_datetime", [CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 43, $this->source); })()), "modifiedAt", [], "any", false, false, false, 43)], 43, $context, $this->getSourceContext());
                    yield "                    )
                </small>
            ";
                }
                // line 46
                yield "        </p>

        <hr>
        <div class=\"form-fieldsgroup__summary-fields\">
            ";
                // line 50
                if (((CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 50, $this->source); })()), "status", [], "any", false, false, false, 50) == "published") && $this->extensions['Bolt\Twig\ContentExtension']->getLink((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 50, $this->source); })()), true))) {
                    // line 51
                    yield "                <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Bolt\Twig\ContentExtension']->getLink((isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 51, $this->source); })()), true, (isset($context["currentlocale"]) || array_key_exists("currentlocale", $context) ? $context["currentlocale"] : (function () { throw new RuntimeError('Variable "currentlocale" does not exist.', 51, $this->source); })())), "html", null, true);
                    yield "\" class=\"btn btn-tertiary btn-sm\" target=\"_blank\">";
                    yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["fa-sign-out-alt"], 51, $context, $this->getSourceContext());
                    yield " ";
                    yield $this->extensions['Bolt\Twig\LocaleExtension']->translate("action.view_saved");
                    yield "</a>
            ";
                }
                // line 53
                yield "            ";
                if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["record"] ?? null), "extras", [], "any", false, true, false, 53), "deleteLink", [], "any", true, true, false, 53)) {
                    // line 54
                    yield "            <a href=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, (isset($context["record"]) || array_key_exists("record", $context) ? $context["record"] : (function () { throw new RuntimeError('Variable "record" does not exist.', 54, $this->source); })()), "extras", [], "any", false, false, false, 54), "deleteLink", [], "any", false, false, false, 54), "html", null, true);
                    yield "\" class='action-remove-collection-item btn btn-sm btn-hidden-danger' data-confirmation=\"";
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.confirm_delete"), "html", null, true);
                    yield "\">
                ";
                    // line 55
                    yield CoreExtension::callMacro($macros["macro"], "macro_icon", ["trash"], 55, $context, $this->getSourceContext());
                    yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.delete"), "html", null, true);
                    yield "
            </a>
            ";
                }
                // line 58
                yield "        </div>
        ";
            }
            // line 60
            yield "
    ";
        }
        // line 62
        yield "
</div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@bolt/content/_buttons.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  169 => 62,  165 => 60,  161 => 58,  154 => 55,  147 => 54,  144 => 53,  134 => 51,  132 => 50,  126 => 46,  118 => 43,  115 => 42,  113 => 41,  107 => 40,  103 => 39,  100 => 38,  98 => 37,  95 => 36,  89 => 32,  87 => 28,  86 => 26,  78 => 20,  76 => 19,  75 => 11,  72 => 10,  69 => 9,  67 => 8,  64 => 7,  58 => 5,  56 => 4,  50 => 3,  47 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("{% import '@bolt/_macro/_macro.html.twig' as macro %}

<div class=\"record-actions {% if hide_on_mobile|default(false) %}d-none d-xl-block{% endif %}\">
    {% if is_granted('edit', record) %}
        {{ macro.button('action.save', 'fa-save', 'success mb-0', {'type': 'submit', 'form': 'editcontent', 'data-patience': 'virtue', 'name': 'save'}) }}
    {% endif %}

    {% if record.id %}
        {% if record|feature == 'homepage' or not record.definition.get('viewless') %}
            <div class=\"btn-group\">
                {{ macro.button(
                    'action.preview',
                    'fa-external-link-square-alt',
                    'primary mb-0',
                    {   'id': 'button-preview',
                        'type': 'submit',
                        'form': 'editcontent',
                        'formtarget': '_blank',
                        'formaction': path('bolt_content_edit_preview', {'id': record.id|default(0) })
                    }) }}

                <button name=\"bttn_name\" type=\"button\" class=\"btn btn-primary dropdown-toggle dropdown-toggle-split\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                    <span class=\"sr-only\">Toggle Dropdown</span>
                </button>
                <div class=\"dropdown-menu\">
                    {{ macro.buttonlink(
                        'action.preview_secure_share'|trans,
                        path(record.definition.get('record_route'), {'slugOrId': record.id, 'contentTypeSlug': record.contenttype,'secret': secret(record.id)}),
                        'fa-user-secret',
                        'btn- dropdown-button mb-0',
                        { 'target': '_blank' }
                    ) }}
                </div>
            </div>
        {% endif %}

        {% if status|default() %}
        <p class=\"mt-3\">
            <strong>{{ __('label.current_status') }}:</strong>
            <span class=\"status mx-1 is-{{ record.status}} mr-2\"></span>{{ __('status.' ~ record.status) }}<br>
            {% if record.status == 'published' %}
                <small>
                    ({{ 'field.modifiedAt'|trans }}: {{ macro.relative_datetime(record.modifiedAt) }}                    )
                </small>
            {% endif %}
        </p>

        <hr>
        <div class=\"form-fieldsgroup__summary-fields\">
            {% if record.status == \"published\" and record|link(true) %}
                <a href=\"{{ record|link(true, currentlocale) }}\" class=\"btn btn-tertiary btn-sm\" target=\"_blank\">{{ macro.icon('fa-sign-out-alt') }} {{ __('action.view_saved') }}</a>
            {% endif %}
            {% if record.extras.deleteLink is defined %}
            <a href=\"{{ record.extras.deleteLink }}\" class='action-remove-collection-item btn btn-sm btn-hidden-danger' data-confirmation=\"{{ 'action.confirm_delete'|trans }}\">
                {{ macro.icon('trash') }}{{ 'action.delete'|trans }}
            </a>
            {% endif %}
        </div>
        {% endif %}

    {% endif %}

</div>
", "@bolt/content/_buttons.html.twig", "/var/www/html/vendor/bolt/core/templates/content/_buttons.html.twig");
    }
}
